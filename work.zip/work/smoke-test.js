const path = require("path");
const { chromium } = require("playwright");

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const filePath = path.resolve(__dirname, "index.html").replace(/\\/g, "/");

  await page.goto(`file:///${filePath}`);
  await page.locator("#loginForm button[type='submit']").click();
  await page.locator("#dashboardView.view.active").waitFor();

  const meetingCount = await page.locator(".dashboard-meeting-card").count();
  if (meetingCount !== 2) {
    throw new Error(`Expected 2 meeting cards, found ${meetingCount}`);
  }

  await page.locator("[data-priority-index='0']").click();
  await page.locator("#detailModal:not(.hidden)").waitFor();
  if (!(await page.locator("#detailModalBody").innerText()).includes("What needs attention")) {
    throw new Error("Priority details modal did not render expected copy");
  }
  await page.locator("#detailModalClose").click();

  await page.locator("[data-market-index='0']").click();
  await page.locator("#detailModal:not(.hidden)").waitFor();
  if (!(await page.locator("#detailModalBody").innerText()).includes("AI recommended actions")) {
    throw new Error("Market details modal did not render expected copy");
  }
  await page.locator("#detailModalClose").click();

  await page.locator("[data-dashboard-period='mtd']").click();
  const revenueText = await page.locator("#kpiRevenueContribution").innerText();
  if (revenueText !== "RM4.8m") {
    throw new Error(`Expected MTD revenue RM4.8m, found ${revenueText}`);
  }

  const analyticsCount = await page.locator(".varied-analytics-row > .analytics-card").count();
  if (analyticsCount !== 4) {
    throw new Error(`Expected 4 analytics cards, found ${analyticsCount}`);
  }

  await browser.close();
  console.log("Dashboard smoke test passed");
})().catch(async error => {
  console.error(error);
  process.exit(1);
});
