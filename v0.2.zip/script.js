const loginScreen = document.getElementById("loginScreen");
const loginForm = document.getElementById("loginForm");
const ssoBtn = document.getElementById("ssoBtn");

const app = document.getElementById('app');
const logoutBtn = document.getElementById('logoutBtn');

const navItems = document.querySelectorAll('.nav-item');
const navGroupToggles = document.querySelectorAll('.nav-group-toggle');
const views = document.querySelectorAll('.view');

const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');
const greetingText = document.getElementById('greetingText');
const summaryDate = document.getElementById('summaryDate');
const lastUpdated = document.getElementById('lastUpdated');

const toast = document.getElementById('toast');
const scanOverlay = document.getElementById('scanOverlay');
const scanText = document.getElementById('scanText');
const progressBar = document.getElementById('progressBar');

const globalSearchInput = document.getElementById('globalSearchInput');
const globalSearchResults = document.getElementById('globalSearchResults');

const notificationBtn = document.getElementById('notificationBtn');
const notificationPanel = document.getElementById('notificationPanel');
const notificationList = document.getElementById('notificationList');
const notificationCount = document.getElementById('notificationCount');
const clearNotificationsBtn = document.getElementById('clearNotificationsBtn');

const customers = [
  {
    id: 'abc',
    name: 'ABC Manufacturing Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Manufacturing',
    relationshipValue: 'High',
    riskRating: 'Good / Stable',
    revenue: 'RM 95m',
    revenueValue: 95,
    ebitda: 'RM 14.8m',
    exposure: 'RM 25.0m',
    exposureValue: 25,
    deposits: 'RM 12.0m',
    depositValue: 12,
    lastContact: 'Yesterday',
    health: 86,
    status: 'Healthy',
    companyProfile: 'Manufacturer of industrial components with import-heavy raw material sourcing.',
    groupStructure: 'Parent company with 3 operating subsidiaries.',
    ubo: 'Lim Wei Kiat, 62% effective ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / KYC refreshed May 2026',
    internalRating: 'CRR 4 - Acceptable',
    products: [
      ['Facilities', 'RM25.0m approved; RM17.8m utilized'],
      ['Deposits', 'RM12.0m average balance'],
      ['CASA', 'Operating account active'],
      ['Trade Finance', 'Import LC and BG potential'],
      ['Treasury', 'Low penetration'],
      ['FX', 'Recurring USD supplier payments']
    ],
    financials: [74, 80, 86, 95],
    repayment: [98, 96, 97, 98, 97, 99],
    ratios: [['Current Ratio', '1.42x'], ['Debt / EBITDA', '2.1x'], ['DSCR', '1.35x'], ['Gross Margin', '22%']],
    creditInfo: [
      ['Credit Limits', 'RM25.0m approved limit'],
      ['Utilisation', '71% current utilization'],
      ['Collateral', 'Factory charge + director guarantee'],
      ['Repayment History', 'No late repayments in 12 months']
    ],
    aiSummary: [
      ['Customer revenue grew 18% YoY', 'Expansion driven by higher export and domestic orders.'],
      ['Deposit balances declined over last 3 months', 'Funds are moving quickly to overseas suppliers after collections.'],
      ['FX opportunity identified', 'Recurring USD payments indicate hedging need.'],
      ['Payment behaviour remains healthy', 'No overdue instalments and stable collection pattern.']
    ],
    nextAction: 'Visit ABC Manufacturing and offer Treasury FX package.',
    aiSignal: 'Declining deposits + recurring USD payments',
    ews: ['Declining deposits', 'Reduced retained balances'],
    churn: 'Low',
    opportunities: ['Working Capital', 'Trade Finance', 'Cash Management', 'Treasury FX']
  },
  {
    id: 'def',
    name: 'DEF Retail Trading Sdn. Bhd.',
    segment: 'SME Commercial',
    industry: 'Retail Trading',
    relationshipValue: 'Medium',
    riskRating: 'Watchlist / Moderate',
    revenue: 'RM 58m',
    revenueValue: 58,
    ebitda: 'RM 6.2m',
    exposure: 'RM 9.4m',
    exposureValue: 9.4,
    deposits: 'RM 6.8m',
    depositValue: 6.8,
    lastContact: '5 days ago',
    health: 71,
    status: 'Monitor',
    companyProfile: 'Retail trading group with seasonal inventory build-up and merchant settlements.',
    groupStructure: 'Single operating company with 8 retail branches.',
    ubo: 'Tan Mei Ling, 70% direct ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / Annual KYC due Sep 2026',
    internalRating: 'CRR 6 - Monitor',
    products: [
      ['Facilities', 'RM9.4m approved; RM7.9m utilized'],
      ['Deposits', 'RM6.8m average balance'],
      ['CASA', 'Merchant settlement account'],
      ['Trade Finance', 'Not active'],
      ['Treasury', 'Not active'],
      ['FX', 'Limited']
    ],
    financials: [49, 52, 55, 58],
    repayment: [95, 92, 91, 94, 90, 92],
    ratios: [['Current Ratio', '1.18x'], ['Debt / EBITDA', '2.8x'], ['DSCR', '1.12x'], ['Gross Margin', '17%']],
    creditInfo: [
      ['Credit Limits', 'RM9.4m approved limit'],
      ['Utilisation', '84% current utilization'],
      ['Collateral', 'Inventory assignment + guarantee'],
      ['Repayment History', '2 minor delays in last 6 months']
    ],
    aiSummary: [
      ['Inventory financing need detected', 'Sales spikes before campaign periods require short-term funding.'],
      ['Limit utilisation nearing threshold', 'Current usage is above 80%.'],
      ['Deposit balance stable', 'Merchant collections remain healthy.'],
      ['Early warning: minor repayment delays', 'Monitor cash-flow before next campaign cycle.']
    ],
    nextAction: 'Offer inventory financing before campaign season.',
    aiSignal: 'High limit utilisation + campaign sales spike',
    ews: ['Limit utilisation >90% risk', 'Late repayments'],
    churn: 'Medium',
    opportunities: ['Working Capital', 'Cash Management']
  },
  {
    id: 'ghi',
    name: 'GHI Exporters Berhad',
    segment: 'Mid Corporate',
    industry: 'Export Manufacturing',
    relationshipValue: 'High',
    riskRating: 'Good / Stable',
    revenue: 'RM 165m',
    revenueValue: 165,
    ebitda: 'RM 21.0m',
    exposure: 'RM 42.0m',
    exposureValue: 42,
    deposits: 'RM 18.5m',
    depositValue: 18.5,
    lastContact: '2 days ago',
    health: 82,
    status: 'Healthy',
    companyProfile: 'Exporter with USD receivables and regional customer concentration.',
    groupStructure: 'Listed holding company with 2 export subsidiaries.',
    ubo: 'Public shareholders; founder family retains 28%',
    rm: 'Qian Tong, Mid Corporate RM',
    onboarding: 'Completed / Beneficial ownership verified',
    internalRating: 'CRR 4 - Acceptable',
    products: [
      ['Facilities', 'RM42.0m approved; RM26.4m utilized'],
      ['Deposits', 'RM18.5m average balance'],
      ['CASA', 'Active multi-currency account'],
      ['Trade Finance', 'Export bills and invoice financing'],
      ['Treasury', 'Ad hoc FX conversion'],
      ['FX', 'High USD receipt volume']
    ],
    financials: [130, 141, 152, 165],
    repayment: [99, 99, 98, 99, 98, 99],
    ratios: [['Current Ratio', '1.58x'], ['Debt / EBITDA', '1.9x'], ['DSCR', '1.52x'], ['Gross Margin', '24%']],
    creditInfo: [
      ['Credit Limits', 'RM42.0m approved limit'],
      ['Utilisation', '63% current utilization'],
      ['Collateral', 'Receivables assignment + debenture'],
      ['Repayment History', 'Excellent repayment record']
    ],
    aiSummary: [
      ['Treasury opportunity identified', 'Large USD conversions happen close to month-end.'],
      ['Receivables financing fit is strong', 'Export settlement cycle creates funding gap.'],
      ['Revenue growth remains strong', 'Customer revenue increased 9% YoY.'],
      ['Payment behaviour remains healthy', 'No overdue payments detected.']
    ],
    nextAction: 'Prepare FX scenario brief for CFO.',
    aiSignal: 'Large USD receipts + ad hoc conversions',
    ews: ['FX volatility exposure'],
    churn: 'Low',
    opportunities: ['Treasury FX', 'Receivables Financing', 'Trade Finance']
  },
  {
    id: 'jkl',
    name: 'JKL Food Processing Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Food Processing',
    relationshipValue: 'Medium',
    riskRating: 'Watchlist / Moderate',
    revenue: 'RM 72m',
    revenueValue: 72,
    ebitda: 'RM 8.1m',
    exposure: 'RM 15.2m',
    exposureValue: 15.2,
    deposits: 'RM 4.9m',
    depositValue: 4.9,
    lastContact: '12 days ago',
    health: 64,
    status: 'At Risk',
    companyProfile: 'Food processor exposed to commodity input costs and supplier concentration.',
    groupStructure: 'Parent company with 1 logistics subsidiary.',
    ubo: 'Ng Soon Huat, 55% effective ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / Financial statements due',
    internalRating: 'CRR 7 - Watchlist',
    products: [
      ['Facilities', 'RM15.2m approved; RM13.9m utilized'],
      ['Deposits', 'RM4.9m average balance'],
      ['CASA', 'Operating account active'],
      ['Trade Finance', 'Limited supplier support'],
      ['Treasury', 'Not active'],
      ['FX', 'Occasional payments']
    ],
    financials: [71, 75, 74, 72],
    repayment: [93, 90, 89, 87, 88, 86],
    ratios: [['Current Ratio', '1.03x'], ['Debt / EBITDA', '3.3x'], ['DSCR', '1.05x'], ['Gross Margin', '13%']],
    creditInfo: [
      ['Credit Limits', 'RM15.2m approved limit'],
      ['Utilisation', '91% current utilization'],
      ['Collateral', 'Plant and machinery + guarantee'],
      ['Repayment History', 'Several small delays detected']
    ],
    aiSummary: [
      ['Limit utilisation exceeds 90%', 'Facility usage is near full capacity.'],
      ['Financial statements overdue', 'Annual review cannot proceed without updated accounts.'],
      ['Supplier concentration detected', 'Payments concentrated to three major suppliers.'],
      ['Risk increased', 'Reduced transaction volume and delayed repayments detected.']
    ],
    nextAction: 'Collect financial statements and review facility limit.',
    aiSignal: 'Utilisation >90% + overdue financial statements',
    ews: ['Limit utilisation >90%', 'Financial statement overdue', 'Late repayments'],
    churn: 'Medium',
    opportunities: ['Facility Review', 'Supply Chain Advisory']
  },
  {
    id: 'mno',
    name: 'MNO Construction Group Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Construction',
    relationshipValue: 'Medium',
    riskRating: 'High Risk',
    revenue: 'RM 88m',
    revenueValue: 88,
    ebitda: 'RM 5.5m',
    exposure: 'RM 31.0m',
    exposureValue: 31,
    deposits: 'RM 3.1m',
    depositValue: 3.1,
    lastContact: '21 days ago',
    health: 48,
    status: 'High Risk',
    companyProfile: 'Construction contractor with project-based cash flow and high limit usage.',
    groupStructure: 'Holding company with 4 project SPVs.',
    ubo: 'Chong Kar Ming, 51% direct ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Enhanced due diligence required',
    internalRating: 'CRR 8 - High Risk',
    products: [
      ['Facilities', 'RM31.0m approved; RM30.2m utilized'],
      ['Deposits', 'RM3.1m average balance'],
      ['CASA', 'Project collection accounts'],
      ['Trade Finance', 'Guarantees and performance bonds'],
      ['Treasury', 'Not active'],
      ['FX', 'Not active']
    ],
    financials: [96, 101, 94, 88],
    repayment: [88, 84, 82, 79, 78, 75],
    ratios: [['Current Ratio', '0.92x'], ['Debt / EBITDA', '4.9x'], ['DSCR', '0.91x'], ['Gross Margin', '9%']],
    creditInfo: [
      ['Credit Limits', 'RM31.0m approved limit'],
      ['Utilisation', '97% current utilization'],
      ['Collateral', 'Project proceeds assignment'],
      ['Repayment History', 'Overdue and restructuring watch']
    ],
    aiSummary: [
      ['Portfolio risk alert', 'Limit utilisation is above 90% and deposit balances are declining.'],
      ['Churn / exit risk elevated', 'Reduced transaction volume and high utilization indicate stress.'],
      ['Credit overdue detected', 'Immediate RM follow-up is required.'],
      ['Covenant review required', 'DSCR has fallen below internal threshold.']
    ],
    nextAction: 'Arrange urgent site visit and credit review.',
    aiSignal: 'Credit overdue + reduced transaction volume',
    ews: ['Credit overdue', 'Covenant breach', 'Large withdrawal', 'Dormant project account'],
    churn: 'High',
    opportunities: ['Restructuring Review', 'Cash Management']
  }
];

const creditDeals = [
  { status: 'Draft', customer: 'ABC Manufacturing', product: 'Working Capital', value: 'RM 8.0m', date: '12 Jul 2026', probability: 35 },
  { status: 'Submitted', customer: 'DEF Retail Trading', product: 'Inventory Financing', value: 'RM 3.5m', date: '15 Jul 2026', probability: 50 },
  { status: 'Credit Review', customer: 'GHI Exporters', product: 'Receivables Financing', value: 'RM 12.0m', date: '18 Jul 2026', probability: 68 },
  { status: 'Additional Information Required', customer: 'JKL Food Processing', product: 'Limit Renewal', value: 'RM 15.2m', date: '22 Jul 2026', probability: 42 },
  { status: 'Approved', customer: 'ABC Manufacturing', product: 'Trade Facility', value: 'RM 5.0m', date: '10 Jul 2026', probability: 90 },
  { status: 'Rejected', customer: 'MNO Construction', product: 'Term Loan', value: 'RM 10.0m', date: '28 Jun 2026', probability: 0 },
  { status: 'Disbursed', customer: 'GHI Exporters', product: 'Export Bills', value: 'RM 7.5m', date: '02 Jul 2026', probability: 100 }
];

const salesOpps = [
  { stage: 'Prospect', customer: 'ABC Manufacturing', product: 'Treasury FX Package', value: 'RM 120k', revenue: 'RM 38k', probability: 25 },
  { stage: 'Qualified', customer: 'DEF Retail Trading', product: 'Cash Management', value: 'RM 80k', revenue: 'RM 24k', probability: 40 },
  { stage: 'Proposal', customer: 'GHI Exporters', product: 'FX Forward', value: 'RM 180k', revenue: 'RM 60k', probability: 65 },
  { stage: 'Negotiation', customer: 'ABC Manufacturing', product: 'Trade Finance', value: 'RM 220k', revenue: 'RM 72k', probability: 78 },
  { stage: 'Won', customer: 'GHI Exporters', product: 'Receivables Financing', value: 'RM 300k', revenue: 'RM 95k', probability: 100 },
  { stage: 'Lost', customer: 'JKL Food Processing', product: 'Treasury Advisory', value: 'RM 40k', revenue: 'RM 12k', probability: 0 }
];

const tasks = [
  ['Call', 'Call CFO of ABC Manufacturing', 'Today, 10:00 AM', 'High'],
  ['Site Visit', 'MNO Construction project site visit', 'Today, 2:30 PM', 'High'],
  ['Meeting', 'GHI Exporters FX scenario review', 'Tomorrow, 11:00 AM', 'Medium'],
  ['Follow-up', 'DEF Retail inventory financing proposal', 'Tomorrow, 4:00 PM', 'Medium'],
  ['Annual Review', 'JKL Food Processing annual review', 'Fri, 9:30 AM', 'High'],
  ['Financial Statement Collection', 'Collect audited FS from JKL', 'Fri, 12:00 PM', 'High']
];

let alerts = [
  ['Large withdrawal', 'ABC Manufacturing transferred RM4.8m to overseas supplier yesterday.', 'warning'],
  ['Credit overdue', 'MNO Construction has overdue repayment requiring follow-up.', 'critical'],
  ['Limit utilisation >90%', 'JKL Food Processing utilisation is now 91%.', 'critical'],
  ['Financial statement overdue', 'JKL Food Processing latest audited financial statements pending.', 'warning'],
  ['Facility expiring', 'ABC Manufacturing trade facility expires in 45 days.', 'info'],
  ['Covenant breach', 'MNO Construction DSCR below internal threshold.', 'critical'],
  ['AML alert', 'Unusual transaction pattern requires review for MNO Construction.', 'warning'],
  ['Dormant account', 'MNO Construction project account inactive for 60 days.', 'info']
];

const documents = [
  ['FY2025 Audited Financial Statements.pdf', 'ABC Manufacturing', 'Financial Statements', 'Current', '28 Jun 2026', 'RM Team'],
  ['Credit Paper - Working Capital.docx', 'ABC Manufacturing', 'Credit Papers', 'Draft', '01 Jul 2026', 'Qian Tong'],
  ['Board Resolution.pdf', 'GHI Exporters', 'Board Resolution', 'Approved', '22 Jun 2026', 'Credit Admin'],
  ['KYC Refresh Form.pdf', 'DEF Retail Trading', 'KYC', 'Due Sep 2026', 'Compliance'],
  ['Company Profile.pdf', 'JKL Food Processing', 'Company Profile', 'Current', '11 Jun 2026', 'RM Team'],
  ['Facility Letter.pdf', 'GHI Exporters', 'Facility Letters', 'Executed', '02 Jul 2026', 'Legal'],
  ['Collateral Valuation.pdf', 'MNO Construction', 'Collateral Documents', 'Review Required', '18 May 2026', 'Credit Risk']
];

const activities = [
  ['Today', 'Call', 'Called ABC CFO to discuss upcoming USD supplier payment.'],
  ['Yesterday', 'Email', 'Sent FX hedging illustration to GHI Exporters.'],
  ['2 days ago', 'Meeting', 'Reviewed merchant settlement trend with DEF Retail.'],
  ['Last week', 'Site Visit', 'Visited JKL production facility and discussed input cost pressure.'],
  ['Last week', 'Notes', 'MNO Construction requested temporary repayment support.']
];

const pageMeta = {
  dashboardView: ['Dashboard', 'Executive overview with KPIs, alerts and AI-generated highlights.'],
  portfolioView: ['Customer Portfolio', 'Search, segment and prioritize customers in the RM portfolio.'],
  customer360View: ['Customer 360', 'Consolidated customer profile, facilities, financials and AI summary.'],
  creditPipelineView: ['Credit Pipeline', 'End-to-end financing workflow and approval status.'],
  salesPipelineView: ['Sales Opportunities', 'Sales CRM pipeline across prospect, proposal, negotiation and outcome stages.'],
  tasksView: ['Tasks & Calendar', 'Daily RM priorities, customer meetings, follow-ups and annual reviews.'],
  alertsView: ['Alerts', 'Real-time alerts for risk, facility, covenant, AML and account events.'],
  copilotView: ['Ask CIMBrain', 'Conversational AI for summaries, annual reviews, cross-sell and credit memo drafting.']
};

let selectedCustomerId = 'abc';
let currentUsername = 'Qian Tong';

let dashboardPeriod = "today";
let dashboardPriorityDetails = [];
let marketSignalDetails = [];

const dashboardPeriodMetrics = {
  today: {
    label: "Today",
    customers: ["86", "▲ +4.8%"],
    exposure: ["RM438m", "▲ +6.2%"],
    deposits: ["RM212m", "▼ -3.0%"],
    health: ["🟢 Stable", "82 / 100"],
    revenue: ["RM0.18m", "▲ +2.1%"]
  },
  mtd: {
    label: "MTD",
    customers: ["89", "▲ +3 customers"],
    exposure: ["RM446m", "▲ +1.8%"],
    deposits: ["RM218m", "▲ +2.8%"],
    health: ["🟢 Stable", "84 / 100"],
    revenue: ["RM2.4m", "▲ +7.6%"]
  },
  ytd: {
    label: "YTD",
    customers: ["86", "▲ +4.8%"],
    exposure: ["RM438m", "▲ +6.2%"],
    deposits: ["RM212m", "▼ -3.0%"],
    health: ["🟢 Stable", "82 / 100"],
    revenue: ["RM18.7m", "▲ +8.5%"]
  }
};

function selectedCustomer() {
  return customers.find(customer => customer.id === selectedCustomerId) || customers[0];
}

function formatDate(date) {
  return date.toLocaleDateString('en-MY', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatDateTime(date) {
  return date.toLocaleString('en-MY', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getGreeting() {
  const hour = new Date().getHours();

  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function nameFromEmail(value) {
  if (!value) return "Relationship Manager";

  const cleanValue = value.trim();

  if (!cleanValue.includes("@")) {
    return cleanValue;
  }

  return cleanValue
    .split("@")[0]
    .split(/[._-]/)
    .filter(Boolean)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function updateHeaderTime() {
  const now = new Date();

  if (greetingText) {
    greetingText.textContent = `${getGreeting()}, ${currentUsername.toUpperCase()}`;
  }

  if (summaryDate) {
    summaryDate.textContent = "";
  }

  if (lastUpdated) {
    lastUpdated.textContent = `Last updated on: ${formatDateTime(now)}`;
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');

  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2800);
}

function badgeClass(customer) {
  if (customer.health >= 80) return 'good';
  if (customer.health >= 60) return 'medium';
  return 'bad';
}

function rotateSearchPlaceholder() {
  const prompts = [
    "Ask CIMBrain anything...",
    "Search customer",
    "Who needs attention today?",
    "Generate meeting brief",
    "Show expiring facilities",
    "Summarise ABC Berhad",
    "Prepare annual review"
  ];

  let index = 0;

  setInterval(() => {
    if (!globalSearchInput) return;
    if (document.activeElement === globalSearchInput) return;

    index = (index + 1) % prompts.length;
    globalSearchInput.placeholder = prompts[index];
  }, 2200);
}

function showView(viewId) {
  views.forEach(view => view.classList.toggle('active', view.id === viewId));
  navItems.forEach(item => item.classList.toggle('active', item.dataset.view === viewId));

  const meta = pageMeta[viewId] || pageMeta.dashboardView;

  pageTitle.textContent = meta[0];
  pageSubtitle.textContent = meta[1];

  if (viewId === 'customer360View') setTimeout(drawCustomerCharts, 80);
  if (viewId === 'reportsView') setTimeout(drawReportCharts, 80);

  globalSearchResults.classList.add('hidden');
}

function openCustomer(customerId) {
  selectedCustomerId = customerId;
  renderAll();
  showView('customer360View');
}

function updateDashboardPeriodMetrics() {
  const data = dashboardPeriodMetrics[dashboardPeriod] || dashboardPeriodMetrics.today;
  const cards = document.querySelectorAll("#dashboardView .clean-kpi-grid .kpi-card");

  const values = [data.customers, data.exposure, data.deposits, data.health, data.revenue];

  cards.forEach((card, index) => {
    const mainValue = card.querySelector("strong");
    const trendValue = card.querySelector(".kpi-bottom small");

    if (mainValue && values[index]) mainValue.textContent = values[index][0];
    if (trendValue && values[index]) trendValue.textContent = values[index][1];
  });

  const label = document.getElementById("dashboardPeriodLabel");
  if (label) label.textContent = data.label;

  document.querySelectorAll(".period-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.period === dashboardPeriod);
  });
}

function openDashboardModal(kicker, title, html) {
  const modal = document.getElementById("dashboardModal");
  const modalKicker = document.getElementById("dashboardModalKicker");
  const modalTitle = document.getElementById("dashboardModalTitle");
  const modalBody = document.getElementById("dashboardModalBody");

  if (!modal || !modalKicker || !modalTitle || !modalBody) return;

  modalKicker.textContent = kicker;
  modalTitle.textContent = title;
  modalBody.innerHTML = html;
  modal.classList.remove("hidden");
}

function closeDashboardModal() {
  const modal = document.getElementById("dashboardModal");
  if (modal) modal.classList.add("hidden");
}

function renderDashboard() {
  updateDashboardPeriodMetrics();

  const getRiskBadge = customer => {
    if (customer.health >= 80) return `<span class="risk-dot-badge good">● Healthy</span>`;
    if (customer.health >= 60) return `<span class="risk-dot-badge warn">● Watchlist</span>`;
    return `<span class="risk-dot-badge risk">● High Risk</span>`;
  };

  const getConfidenceChip = customer => {
    if (customer.health >= 80) return `<span class="ai-confidence-subtle">AI Confidence • 94%</span>`;
    if (customer.health >= 60) return `<span class="ai-confidence-subtle warn">AI Confidence • 76%</span>`;
    return `<span class="ai-confidence-subtle risk">AI Confidence • 58%</span>`;
  };

  const dashboardRows = [...customers]
    .sort((a, b) => a.health - b.health)
    .map(customer => `
      <tr data-customer-id="${customer.id}">
        <td>
          <button class="customer-button" data-customer-id="${customer.id}">
            <div class="customer-name-block">
              <strong>${customer.name}</strong>
              <small>${customer.industry}</small>
            </div>
          </button>
        </td>
        <td>${customer.exposure}</td>
        <td>${getRiskBadge(customer)}</td>
        <td>
          <div class="next-action-clean">
            <strong>${customer.nextAction}</strong>
            ${getConfidenceChip(customer)}
          </div>
        </td>
      </tr>
    `)
    .join("");

  document.getElementById("dashboardCustomerRows").innerHTML = dashboardRows;

  dashboardPriorityDetails = [
    {
      rank: "01",
      level: "critical",
      icon: "🔥",
      title: "Follow up high-risk customers",
      count: "2 customers",
      impact: "High Impact",
      confidence: "AI Confidence • 92%",
      details: `
        <div class="modal-detail-grid">
          <div><span>What needs attention</span><strong>MNO Construction and JKL Food Processing require immediate RM follow-up.</strong></div>
          <div><span>Reason</span><strong>High utilisation, delayed repayment pattern, and overdue documentation detected.</strong></div>
          <div><span>Affected Clients</span><strong>MNO Construction, JKL Food Processing</strong></div>
          <div><span>Recommended Action</span><strong>Call client, schedule site visit, collect financial statements, and review facility exposure.</strong></div>
        </div>
      `
    },
    {
      rank: "02",
      level: "urgent",
      icon: "⏳",
      title: "Renew expiring facilities",
      count: "11 facilities",
      impact: "Retention Priority",
      confidence: "AI Confidence • 88%",
      details: `
        <div class="modal-detail-grid">
          <div><span>What needs attention</span><strong>11 facilities expire within the next 60 days.</strong></div>
          <div><span>Reason</span><strong>Early renewal prevents documentation delays and customer disruption.</strong></div>
          <div><span>Affected Clients</span><strong>ABC Manufacturing, JKL Food Processing, DEF Retail Trading</strong></div>
          <div><span>Recommended Action</span><strong>Prepare annual review checklist and request updated financials this week.</strong></div>
        </div>
      `
    },
    {
      rank: "03",
      level: "opportunity",
      icon: "💰",
      title: "Offer Treasury FX package",
      count: "ABC Manufacturing",
      impact: "Revenue Opportunity",
      confidence: "AI Confidence • 94%",
      details: `
        <div class="modal-detail-grid">
          <div><span>What needs attention</span><strong>ABC Manufacturing has recurring USD supplier payments.</strong></div>
          <div><span>Reason</span><strong>Deposit balances decline after overseas payments, suggesting FX and cash-flow advisory opportunity.</strong></div>
          <div><span>Affected Clients</span><strong>ABC Manufacturing, GHI Exporters</strong></div>
          <div><span>Recommended Action</span><strong>Generate FX scenario brief and discuss hedging package with CFO.</strong></div>
        </div>
      `
    },
    {
      rank: "04",
      level: "normal",
      icon: "📝",
      title: "Accelerate credit reviews",
      count: "9 applications",
      impact: "Pipeline Priority",
      confidence: "AI Confidence • 76%",
      details: `
        <div class="modal-detail-grid">
          <div><span>What needs attention</span><strong>9 credit applications are still pending in the approval workflow.</strong></div>
          <div><span>Reason</span><strong>Delayed review may reduce conversion and slow customer facility drawdown.</strong></div>
          <div><span>Affected Clients</span><strong>DEF Retail Trading, GHI Exporters, ABC Manufacturing</strong></div>
          <div><span>Recommended Action</span><strong>Prioritise applications with higher conversion probability and chase missing documents.</strong></div>
        </div>
      `
    }
  ];

  document.getElementById("dashboardInsights").innerHTML = dashboardPriorityDetails
    .map((item, index) => `
      <div class="ai-priority-card priority-${item.level}" data-priority-index="${index}" role="button" tabindex="0">
        <span class="attention-bubble">What needs attention</span>

        <div class="priority-rank">${item.rank}</div>
        <div class="ai-priority-icon">${item.icon}</div>

        <div>
          <h4>${item.title}</h4>
          <p>${item.count}</p>
        </div>

        <div class="priority-card-footer">
          <span class="priority-chip impact">${item.impact}</span>
          <span class="ai-confidence-subtle">${item.confidence}</span>
        </div>
      </div>
    `)
    .join("");

  marketSignalDetails = [
    {
      icon: "🌴",
      industry: "Food Processing",
      title: "Palm oil prices rise",
      text: "May increase working capital needs for food processing customers.",
      source: "MPOB",
      url: "https://bepi.mpob.gov.my/",
      summary: "Palm oil input prices are trending upward, which may increase production cost for food processors.",
      clients: "JKL Food Processing",
      impact: "Higher raw material costs may pressure margins and increase short-term working capital utilisation.",
      action: "Discuss inventory financing, review utilisation level, and request updated financial statements."
    },
    {
      icon: "🌍",
      industry: "Export Manufacturing",
      title: "USD remains firm",
      text: "Exporters may need renewed FX hedging discussions this week.",
      source: "BNM",
      url: "https://www.bnm.gov.my/",
      summary: "A firm USD may affect clients with foreign currency receivables or supplier payments.",
      clients: "ABC Manufacturing, GHI Exporters",
      impact: "Clients may face FX volatility, timing mismatch, or higher settlement cost.",
      action: "Prepare FX scenario brief and offer Treasury FX package."
    },
    {
      icon: "🏗️",
      industry: "Construction",
      title: "Construction material costs rise",
      text: "Could pressure margins for construction-related borrowers.",
      source: "CIDB",
      url: "https://www.cidb.gov.my/",
      summary: "Construction material inflation can affect project profitability and repayment capacity.",
      clients: "MNO Construction Group",
      impact: "Margin compression may increase covenant and repayment risk.",
      action: "Arrange site visit and review project cash-flow assumptions."
    },
    {
      icon: "🛒",
      industry: "Retail Trading",
      title: "Consumer spending uneven",
      text: "Inventory financing and cashflow cycles may need closer monitoring.",
      source: "DOSM",
      url: "https://www.dosm.gov.my/",
      summary: "Uneven spending recovery may affect retail sales conversion and inventory turnover.",
      clients: "DEF Retail Trading",
      impact: "Slower sell-through may increase inventory holding period and working capital need.",
      action: "Review campaign season financing and monitor repayment behaviour."
    },
    {
      icon: "🚢",
      industry: "Trade Finance",
      title: "Shipping delays reported",
      text: "Trade finance clients may face slower inventory turnover.",
      source: "MATRADE",
      url: "https://www.matrade.gov.my/",
      summary: "Shipping disruption may delay stock arrival and slow trade settlement cycles.",
      clients: "ABC Manufacturing, GHI Exporters",
      impact: "May increase financing tenor needs and affect import/export cash conversion cycle.",
      action: "Review LC, BG, and receivables financing requirements."
    }
  ];

  document.getElementById("recentActivities").innerHTML = marketSignalDetails
    .map((item, index) => `
      <div class="market-signal-item">
        <div class="market-signal-industry">
          <span>${item.icon}</span>
          <strong>${item.industry}</strong>
        </div>

        <div class="market-signal-body">
          <strong>${item.title}</strong>
          <p>${item.text}</p>
        </div>

        <div class="market-signal-actions">
          <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="market-source-link">${item.source} ↗</a>
          <button class="market-detail-btn" data-signal-index="${index}">Details</button>
        </div>
      </div>
    `)
    .join("");

  renderDashboardAnalytics();
}

function renderDashboardAnalytics() {
  const analyticsData = {
    today: {
      portfolioMix: [["Manufacturing", 34], ["Construction", 20], ["Retail", 18], ["Services", 15], ["Others", 13]],
      productExposure: [["Working Capital", 38], ["Term Loan", 24], ["Trade Finance", 20], ["Guarantees", 11], ["Treasury", 7]],
      dealMovement: [["Prospects", 24], ["Proposal", 18], ["Review", 11], ["Negotiation", 9], ["Approved", 7], ["Won", 5], ["Lost", 2], ["Disbursed", 4]],
      rmPerformance: [["Meetings completed", "4"], ["Pipeline conversion", "41%"], ["Revenue achieved", "RM0.18m"], ["Annual reviews completed", "3"]]
    },
    mtd: {
      portfolioMix: [["Manufacturing", 32], ["Construction", 22], ["Retail", 19], ["Services", 15], ["Others", 12]],
      productExposure: [["Working Capital", 40], ["Term Loan", 22], ["Trade Finance", 21], ["Guarantees", 10], ["Treasury", 7]],
      dealMovement: [["Prospects", 42], ["Proposal", 31], ["Review", 22], ["Negotiation", 16], ["Approved", 13], ["Won", 9], ["Lost", 4], ["Disbursed", 7]],
      rmPerformance: [["Meetings completed", "24"], ["Pipeline conversion", "44%"], ["Revenue achieved", "RM2.4m"], ["Annual reviews completed", "18"]]
    },
    ytd: {
      portfolioMix: [["Manufacturing", 34], ["Construction", 20], ["Retail", 18], ["Services", 15], ["Others", 13]],
      productExposure: [["Working Capital", 38], ["Term Loan", 24], ["Trade Finance", 20], ["Guarantees", 11], ["Treasury", 7]],
      dealMovement: [["Prospects", 118], ["Proposal", 84], ["Review", 63], ["Negotiation", 41], ["Approved", 35], ["Won", 27], ["Lost", 8], ["Disbursed", 22]],
      rmPerformance: [["Meetings completed", "164"], ["Pipeline conversion", "47%"], ["Revenue achieved", "RM18.7m"], ["Annual reviews completed", "76%"]]
    }
  };

  const data = analyticsData[dashboardPeriod] || analyticsData.today;
  const maxDealValue = Math.max(...data.dealMovement.map(item => item[1]));

  const renderBars = items => items
    .map(([label, value]) => `
      <div class="pink-bar-row">
        <div class="pink-bar-head">
          <strong>${label}</strong>
          <span>${value}%</span>
        </div>
        <div class="pink-bar-track">
          <div class="pink-bar-fill" style="width:${value}%"></div>
        </div>
      </div>
    `)
    .join("");

  const portfolioMixEl = document.getElementById("dashboardPortfolioMix");
  if (portfolioMixEl) portfolioMixEl.innerHTML = renderBars(data.portfolioMix);

  const productExposureEl = document.getElementById("dashboardProductExposure");
  if (productExposureEl) productExposureEl.innerHTML = renderBars(data.productExposure);

  const dealMovementEl = document.getElementById("dashboardDealMovement");
  if (dealMovementEl) {
    dealMovementEl.innerHTML = data.dealMovement
      .map(([label, value]) => `
        <div class="pink-bar-row compact-bar-row">
          <div class="pink-bar-head">
            <strong>${label}</strong>
            <span>${value}</span>
          </div>
          <div class="pink-bar-track">
            <div class="pink-bar-fill soft" style="width:${(value / maxDealValue) * 100}%"></div>
          </div>
        </div>
      `)
      .join("");
  }

  const rmPerformanceEl = document.getElementById("dashboardRMPerformance");
  if (rmPerformanceEl) {
    rmPerformanceEl.innerHTML = data.rmPerformance
      .map(([label, value]) => `
        <div class="rm-performance-item">
          <span>${label}</span>
          <strong>${value}</strong>
        </div>
      `)
      .join("");
  }
}

function renderPortfolio() {
  const search = document.getElementById('customerSearch').value.toLowerCase();
  const segment = document.getElementById('segmentFilter').value;
  const industryValue = document.getElementById('industryFilter').value;

  const filtered = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(search) || customer.industry.toLowerCase().includes(search);
    const matchesSegment = segment === 'All' || customer.segment === segment;
    const matchesIndustry = industryValue === 'All' || customer.industry === industryValue;

    return matchesSearch && matchesSegment && matchesIndustry;
  });

  document.getElementById('portfolioRows').innerHTML = filtered.map(customer => `
    <tr data-customer-id="${customer.id}">
      <td><button class="customer-button" data-customer-id="${customer.id}">${customer.name}</button></td>
      <td>${customer.segment}</td>
      <td>${customer.industry}</td>
      <td>${customer.relationshipValue}</td>
      <td>${customer.riskRating}</td>
      <td>${customer.revenue}</td>
      <td>${customer.exposure}</td>
      <td>${customer.deposits}</td>
      <td>${customer.lastContact}</td>
      <td><span class="badge ${badgeClass(customer)}">${customer.health}</span></td>
    </tr>
  `).join('');
}

function renderCustomerSelectors() {
  const options = customers
    .map(customer => `<option value="${customer.id}">${customer.name}</option>`)
    .join("");

  const customerSelect = document.getElementById("customerSelect");

  if (customerSelect) {
    customerSelect.innerHTML = options;
    customerSelect.value = selectedCustomerId;
  }
}

function renderCustomer360() {
  const customer = selectedCustomer();

  document.getElementById('customerName').textContent = customer.name;
  document.getElementById('customerHealthBadge').textContent = `${customer.status} · ${customer.health}`;
  document.getElementById('customerHealthBadge').className = `badge ${badgeClass(customer)}`;

  document.getElementById('companyProfile').textContent = customer.companyProfile;
  document.getElementById('groupStructure').textContent = customer.groupStructure;
  document.getElementById('ubo').textContent = customer.ubo;
  document.getElementById('relationshipManager').textContent = customer.rm;
  document.getElementById('onboardingStatus').textContent = customer.onboarding;
  document.getElementById('internalRating').textContent = customer.internalRating;

  document.getElementById('aiSummaryList').innerHTML = customer.aiSummary
    .map(([title, text]) => `<div class="insight-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  document.getElementById('bankingProducts').innerHTML = customer.products
    .map(([title, text]) => `<div class="product-card"><strong>${title}</strong><span>${text}</span></div>`)
    .join('');

  document.getElementById('creditInfo').innerHTML = customer.creditInfo
    .map(([title, text]) => `<div class="metric-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  document.getElementById('ratioCards').innerHTML = customer.ratios
    .map(([title, value]) => `<div><strong>${value}</strong><span>${title}</span></div>`)
    .join('');

  document.getElementById('customerSelect').value = selectedCustomerId;

  renderCustomerInteractions();
  renderCustomerDocuments();
}

function getCustomerShortName(customer) {
  return customer.name
    .replace(" Sdn. Bhd.", "")
    .replace(" Berhad", "")
    .replace(" Group", "")
    .trim();
}

function renderCustomerInteractions() {
  const customer = selectedCustomer();

  const interactionMap = {
    abc: [
      ["09:32 AM", "🟢", "Call", "Discussed upcoming USD supplier payment with CFO."],
      ["Yesterday", "📧", "Email Sent", "Sent indicative FX hedging proposal."],
      ["2 days ago", "📄", "Credit Memo", "Working capital memo prepared for internal review."],
      ["Last week", "💰", "Deposit Movement", "RM4.8m supplier payment detected."]
    ],
    def: [
      ["10:20 AM", "📧", "Email Sent", "Followed up on inventory financing documents."],
      ["Yesterday", "🤝", "Meeting", "Discussed campaign season working capital needs."],
      ["5 days ago", "🟡", "Risk Note", "Minor repayment delay flagged for monitoring."]
    ],
    ghi: [
      ["11:48 AM", "📧", "Email Sent", "Sent FX hedging illustration to CFO."],
      ["Yesterday", "💰", "Treasury", "Large USD conversion identified near month-end."],
      ["2 days ago", "🤝", "Meeting", "Reviewed export receivables financing opportunity."]
    ],
    jkl: [
      ["02:20 PM", "🏢", "Site Visit", "Reviewed input cost pressure and facility usage."],
      ["Yesterday", "📄", "Document Request", "Requested latest audited financial statements."],
      ["Last week", "🟡", "Watchlist", "High utilisation and delayed repayment noted."]
    ],
    mno: [
      ["09:10 AM", "🚨", "Risk Alert", "Moved into high-risk monitoring."],
      ["Yesterday", "🏢", "Site Visit", "Project site visit arranged for credit review."],
      ["Last week", "📄", "Covenant Review", "DSCR below internal threshold."]
    ]
  };

  const target = document.getElementById("customerInteractionList");
  if (!target) return;

  const interactions = interactionMap[customer.id] || [];

  target.innerHTML = interactions
    .map(([time, icon, title, text]) => `
      <div class="customer-interaction-item">
        <div class="customer-interaction-icon">${icon}</div>
        <div class="customer-interaction-content">
          <small>${time}</small>
          <strong>${title}</strong>
          <p>${text}</p>
        </div>
      </div>
    `)
    .join("");
}

function renderCustomerDocuments() {
  const customer = selectedCustomer();
  const shortName = getCustomerShortName(customer);

  const customerDocs = documents.filter(doc => {
    const docCustomer = doc[1];
    return shortName.includes(docCustomer) || docCustomer.includes(shortName);
  });

  const target = document.getElementById("customerDocumentsList");
  if (!target) return;

  target.innerHTML = customerDocs.length
    ? customerDocs
        .map(([fileName, customerName, category, status, date, owner]) => `
          <div class="customer-document-card">
            <small>${category}</small>
            <strong>${fileName}</strong>
            <p>${customerName}</p>

            <div class="customer-document-meta">
              <span class="status">${status}</span>
              <span>${date}</span>
              <span>${owner}</span>
            </div>
          </div>
        `)
        .join("")
    : `
      <div class="customer-document-card">
        <strong>No documents found</strong>
        <p>No repository items are currently tagged to this customer.</p>
      </div>
    `;
}

function getCustomerShortName(customer) {
  return customer.name
    .replace(" Sdn. Bhd.", "")
    .replace(" Berhad", "")
    .replace(" Group", "")
    .trim();
}

function renderCustomerInteractions() {
  const customer = selectedCustomer();

  const interactionMap = {
    abc: [
      ["09:32 AM", "🟢", "Call", "Discussed upcoming USD supplier payment with CFO."],
      ["Yesterday", "📧", "Email Sent", "Sent indicative FX hedging proposal."],
      ["2 days ago", "📄", "Credit Memo", "Working capital memo prepared for internal review."],
      ["Last week", "💰", "Deposit Movement", "RM4.8m supplier payment detected."]
    ],
    def: [
      ["10:20 AM", "📧", "Email Sent", "Followed up on inventory financing documents."],
      ["Yesterday", "🤝", "Meeting", "Discussed campaign season working capital needs."],
      ["5 days ago", "🟡", "Risk Note", "Minor repayment delay flagged for monitoring."]
    ],
    ghi: [
      ["11:48 AM", "📧", "Email Sent", "Sent FX hedging illustration to CFO."],
      ["Yesterday", "💰", "Treasury", "Large USD conversion identified near month-end."],
      ["2 days ago", "🤝", "Meeting", "Reviewed export receivables financing opportunity."]
    ],
    jkl: [
      ["02:20 PM", "🏢", "Site Visit", "Reviewed input cost pressure and facility usage."],
      ["Yesterday", "📄", "Document Request", "Requested latest audited financial statements."],
      ["Last week", "🟡", "Watchlist", "High utilisation and delayed repayment noted."]
    ],
    mno: [
      ["09:10 AM", "🚨", "Risk Alert", "Moved into high-risk monitoring."],
      ["Yesterday", "🏢", "Site Visit", "Project site visit arranged for credit review."],
      ["Last week", "📄", "Covenant Review", "DSCR below internal threshold."]
    ]
  };

  const interactions = interactionMap[customer.id] || [];

  const target = document.getElementById("customerInteractionList");
  if (!target) return;

  target.innerHTML = interactions
    .map(([time, icon, title, text]) => `
      <div class="customer-interaction-item">
        <div class="customer-interaction-icon">${icon}</div>
        <div class="customer-interaction-content">
          <small>${time}</small>
          <strong>${title}</strong>
          <p>${text}</p>
        </div>
      </div>
    `)
    .join("");
}

function renderCustomerDocuments() {
  const customer = selectedCustomer();
  const shortName = getCustomerShortName(customer);

  const customerDocs = documents.filter(doc => {
    const docCustomer = doc[1];
    return shortName.includes(docCustomer) || docCustomer.includes(shortName);
  });

  const target = document.getElementById("customerDocumentsList");
  if (!target) return;

  target.innerHTML = customerDocs.length
    ? customerDocs
        .map(([fileName, customerName, category, status, date, owner]) => `
          <div class="customer-document-card">
            <small>${category}</small>
            <strong>${fileName}</strong>
            <p>${customerName}</p>

            <div class="customer-document-meta">
              <span class="status">${status}</span>
              <span>${date}</span>
              <span>${owner}</span>
            </div>
          </div>
        `)
        .join("")
    : `
      <div class="customer-document-card">
        <strong>No documents found</strong>
        <p>No repository items are currently tagged to this customer.</p>
      </div>
    `;
}

function renderCreditPipeline() {
  const statuses = ['Draft', 'Submitted', 'Credit Review', 'Additional Information Required', 'Approved', 'Rejected', 'Disbursed'];

  document.getElementById('creditPipeline').innerHTML = statuses.map(status => {
    const cards = creditDeals
      .filter(deal => deal.status === status)
      .map(deal => `
        <div class="pipeline-card">
          <strong>${deal.customer}</strong>
          <span>Product: ${deal.product}</span>
          <span>Deal Value: ${deal.value}</span>
          <span>Expected Approval: ${deal.date}</span>
          <span>Probability: ${deal.probability}%</span>
          <div class="probability"><div style="width:${deal.probability}%"></div></div>
        </div>
      `)
      .join('') || '<p class="table-note">No deals</p>';

    return `<div class="pipeline-column"><h4>${status}</h4>${cards}</div>`;
  }).join('');
}

function renderSalesPipeline() {
  const stages = ['Prospect', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];

  document.getElementById('salesPipeline').innerHTML = stages.map(stage => {
    const cards = salesOpps
      .filter(opp => opp.stage === stage)
      .map(opp => `
        <div class="opportunity-card">
          <strong>${opp.customer}</strong>
          <span>Product: ${opp.product}</span>
          <span>Opportunity Value: ${opp.value}</span>
          <span>Expected Revenue: ${opp.revenue}</span>
          <span>Probability: ${opp.probability}%</span>
          <div class="probability"><div style="width:${opp.probability}%"></div></div>
        </div>
      `)
      .join('') || '<p class="table-note">No opportunities</p>';

    return `<div class="kanban-column"><h4>${stage}</h4>${cards}</div>`;
  }).join('');
}

function renderAIInsights() {
  document.getElementById('portfolioRiskCards').innerHTML = customers
    .filter(customer => customer.health < 75)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>${customer.aiSignal}. Health score: ${customer.health}.</p></div>`)
    .join('');

  document.getElementById('growthCards').innerHTML = customers
    .filter(customer => customer.opportunities.length > 2)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>Eligible for: ${customer.opportunities.join(', ')}.</p></div>`)
    .join('');

  document.getElementById('nextBestActionCards').innerHTML = customers
    .slice(0, 4)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>${customer.nextAction}</p></div>`)
    .join('');

  document.getElementById('churnCards').innerHTML = customers
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>Churn prediction: ${customer.churn}. Main signal: ${customer.aiSignal}.</p></div>`)
    .join('');

  document.getElementById('ewsCards').innerHTML = alerts
    .map(([title, text, severity]) => `
      <div class="warning-card">
        <strong>${title}</strong>
        <p>${text}</p>
        <span class="badge ${severity === 'critical' ? 'bad' : severity === 'warning' ? 'medium' : 'neutral'}">${severity}</span>
      </div>
    `)
    .join('');
}

function renderTasks() {
  document.getElementById('taskList').innerHTML = tasks.map(([type, title, time, priority]) => `
    <div class="task-item">
      <strong>${type}: ${title}</strong>
      <p>${time} · Priority: ${priority}</p>
    </div>
  `).join('');

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

  document.getElementById('calendarGrid').innerHTML = days.map((day, index) => {
    const dayTasks = tasks.filter((_, taskIndex) => taskIndex % 5 === index);

    return `
      <div class="calendar-day">
        <h4>${day}</h4>
        ${dayTasks.map(task => `<div class="calendar-event"><strong>${task[0]}</strong><br>${task[1]}</div>`).join('')}
      </div>
    `;
  }).join('');
}

function renderAlerts() {
  document.getElementById('alertsList').innerHTML = alerts.map(([title, text, severity]) => `
    <div class="alert-item ${severity}">
      <strong>${title}</strong>
      <p>${text}</p>
    </div>
  `).join('');
}

function renderNotifications() {
  const notificationSummary = [
    ["🚨", "2 High Risk Customers", "Immediate RM attention required"],
    ["📝", "4 Applications Awaiting Approval", "Pending credit decision"],
    ["🎂", "1 Customer Birthday", "Relationship engagement opportunity"],
    ["⏳", "1 Credit Limit Expiring", "Facility review due soon"]
  ];

  notificationCount.textContent = "8";

  notificationList.innerHTML = notificationSummary
    .map(([icon, title, text]) => `
      <div class="notification-summary-item">
        <b>${icon}</b>
        <div>
          <strong>${title}</strong>
          <span>${text}</span>
        </div>
      </div>
    `)
    .join("");
}

function renderDocuments() {
  document.getElementById('documentRows').innerHTML = documents.map(doc => `
    <tr>
      <td><strong>${doc[0]}</strong></td>
      <td>${doc[1]}</td>
      <td>${doc[2]}</td>
      <td>${doc[3]}</td>
      <td>${doc[4]}</td>
      <td>${doc[5]}</td>
    </tr>
  `).join('');
}

function renderEngagement() {
  document.getElementById('engagementCustomerSelect').value = selectedCustomerId;

  document.getElementById('engagementTimeline').innerHTML = activities.map(([date, type, text]) => `
    <div class="timeline-item">
      <div class="timeline-date">${date}</div>
      <div class="timeline-content"><strong>${type}</strong><p>${text}</p></div>
    </div>
  `).join('');
}

function renderReports() {
  renderBarChart('industryChart', [
    ['Manufacturing', 32],
    ['Retail', 18],
    ['Export', 24],
    ['Food', 14],
    ['Construction', 12]
  ]);

  renderBarChart('loanMixChart', [
    ['Working Capital', 38],
    ['Term Loan', 24],
    ['Trade Finance', 20],
    ['Guarantees', 11],
    ['Treasury', 7]
  ]);

  renderBarChart('stageChart', [
    ['Prospect', 12],
    ['Qualified', 18],
    ['Proposal', 30],
    ['Negotiation', 21],
    ['Won', 14],
    ['Lost', 5]
  ]);

  document.getElementById('rmPerformance').innerHTML = [
    ['Meetings completed', '24 this month'],
    ['Pipeline conversion', '41% win rate'],
    ['Revenue achieved', 'RM18.7m YTD'],
    ['Annual reviews completed', '76% completed']
  ]
    .map(([title, text]) => `<div class="metric-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');
}

function renderBarChart(targetId, rows) {
  document.getElementById(targetId).innerHTML = rows.map(([label, value]) => `
    <div class="bar-row">
      <strong>${label}</strong>
      <div class="bar-track"><div class="bar-fill" style="width:${value}%"></div></div>
      <span>${value}%</span>
    </div>
  `).join('');
}

function drawLineChart(canvasId, values, title) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const padding = 42;

  const max = Math.max(...values) + 10;
  const min = Math.min(...values) - 10;

  ctx.clearRect(0, 0, width, height);

  ctx.fillStyle = '#fffef7';
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = '#e4e4dc';
  ctx.lineWidth = 1;

  for (let i = 0; i <= 4; i += 1) {
    const y = padding + ((height - padding * 2) / 4) * i;

    ctx.beginPath();
    ctx.moveTo(padding, y);
    ctx.lineTo(width - padding, y);
    ctx.stroke();
  }

  const points = values.map((value, index) => ({
    x: padding + ((width - padding * 2) / (values.length - 1)) * index,
    y: padding + (height - padding * 2) - ((value - min) / (max - min)) * (height - padding * 2)
  }));

  ctx.beginPath();

  points.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });

  ctx.strokeStyle = '#202020';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke();

  points.forEach((point, index) => {
    ctx.beginPath();
    ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
    ctx.fillStyle = index === points.length - 1 ? '#ffe600' : '#202020';
    ctx.fill();
  });

  ctx.fillStyle = '#202020';
  ctx.font = 'bold 14px Arial';
  ctx.fillText(title, padding, 25);
}

function drawCustomerCharts() {
  const customer = selectedCustomer();

  drawLineChart('financialChart', customer.financials, 'Revenue trend: FY2023 to FY2026');
  drawLineChart('repaymentChart', customer.repayment, 'Repayment behaviour score: last 6 months');
}

function drawReportCharts() {
  drawLineChart('revenueTrendChart', [11.2, 12.8, 14.3, 15.7, 16.9, 18.7], 'Revenue trend: Jan to Jun');
  drawLineChart('depositTrendChart', [230, 225, 221, 218, 215, 212], 'Deposit trend: Jan to Jun');
}

function buildSearchIndex() {
  const customerResults = customers.map(customer => ({
    title: customer.name,
    category: 'Customer',
    detail: `${customer.industry} · ${customer.segment} · Health ${customer.health}`,
    view: 'customer360View',
    customerId: customer.id,
    keywords: `${customer.name} ${customer.industry} ${customer.segment} ${customer.riskRating} ${customer.aiSignal}`
  }));

  const alertResults = alerts.map(([title, text, severity]) => ({
    title,
    category: 'Alert',
    detail: `${severity} · ${text}`,
    view: 'alertsView',
    keywords: `${title} ${text} ${severity}`
  }));

  const documentResults = documents.map(doc => ({
    title: doc[0],
    category: 'Document',
    detail: `${doc[1]} · ${doc[2]} · ${doc[3]}`,
    view: 'documentsView',
    keywords: doc.join(' ')
  }));

  const taskResults = tasks.map(task => ({
    title: task[1],
    category: 'Task',
    detail: `${task[0]} · ${task[2]} · Priority ${task[3]}`,
    view: 'tasksView',
    keywords: task.join(' ')
  }));

  const creditResults = creditDeals.map(deal => ({
    title: `${deal.customer} - ${deal.product}`,
    category: 'Credit Pipeline',
    detail: `${deal.status} · ${deal.value} · ${deal.probability}% probability`,
    view: 'creditPipelineView',
    keywords: `${deal.customer} ${deal.product} ${deal.status} ${deal.value}`
  }));

  const salesResults = salesOpps.map(opp => ({
    title: `${opp.customer} - ${opp.product}`,
    category: 'Sales Opportunity',
    detail: `${opp.stage} · ${opp.value} · Revenue ${opp.revenue}`,
    view: 'salesPipelineView',
    keywords: `${opp.customer} ${opp.product} ${opp.stage} ${opp.value} ${opp.revenue}`
  }));

  return [
    ...customerResults,
    ...alertResults,
    ...documentResults,
    ...taskResults,
    ...creditResults,
    ...salesResults
  ];
}

function handleGlobalSearch() {
  const query = globalSearchInput.value.trim().toLowerCase();

  if (!query) {
    globalSearchResults.classList.add('hidden');
    return;
  }

  const results = buildSearchIndex()
    .filter(item => item.keywords.toLowerCase().includes(query))
    .slice(0, 8);

  if (!results.length) {
    globalSearchResults.innerHTML = `
      <div class="search-result">
        <strong>No results found</strong>
        <span>Try customer name, document type, alert, task or product.</span>
      </div>
    `;
    globalSearchResults.classList.remove('hidden');
    return;
  }

  globalSearchResults.innerHTML = results.map((item, index) => `
    <button class="search-result" data-result-index="${index}">
      <strong>${item.category}: ${item.title}</strong>
      <span>${item.detail}</span>
    </button>
  `).join('');

  globalSearchResults.dataset.results = JSON.stringify(results);
  globalSearchResults.classList.remove('hidden');
}

function addChatMessage(text, sender = 'bot') {
  const chatWindow = document.getElementById('chatWindow');
  const div = document.createElement('div');

  div.className = `message ${sender}`;
  div.innerHTML = text.replace(/\n/g, '<br>');
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function copilotResponse(prompt) {
  const lower = prompt.toLowerCase();
  const customer = selectedCustomer();

  if (lower.includes('abc') || lower.includes('summarise') || lower.includes('summary')) {
    return `<strong>${customer.name} summary</strong>\n${customer.companyProfile}\n\nKey AI insights:\n- ${customer.aiSummary.map(item => item[0]).join('\n- ')}`;
  }

  if (lower.includes('annual review')) {
    return `<strong>Annual review draft outline</strong>\n1. Relationship overview\n2. Facilities and utilization\n3. Financial performance and ratios\n4. Repayment conduct\n5. Collateral and covenant status\n6. AI risk summary\n7. Recommended approval / action.`;
  }

  if (lower.includes('cross')) {
    return `<strong>Cross-sell recommendations</strong>\nFor ${customer.name}: ${customer.opportunities.join(', ')}.\nPriority action: ${customer.nextAction}`;
  }

  if (lower.includes('risk')) {
    return `<strong>Risk explanation</strong>\nRisk movement is driven by: ${customer.aiSignal}. Early warning signals: ${customer.ews.join(', ')}.`;
  }

  if (lower.includes('credit memo')) {
    return `<strong>Credit memo starter</strong>\nCustomer: ${customer.name}\nExposure: ${customer.exposure}\nDeposits: ${customer.deposits}\nInternal Rating: ${customer.internalRating}\nRecommendation: Review facilities based on AI signal - ${customer.aiSignal}.`;
  }

  return `I can help summarise a customer, draft annual review, recommend cross-sell opportunities, explain risk changes or generate a credit memo. Current customer context: ${customer.name}.`;
}

function renderAll() {
  renderDashboard();
  renderPortfolio();
  renderCustomerSelectors();
  renderCustomer360();
  renderCreditPipeline();
  renderSalesPipeline();
  renderTasks();
  renderAlerts();
  renderNotifications();
  renderDashboardAnalytics();
}

async function runScan() {
  const steps = [
    'Ingesting customer, transaction, facility, deposit and document data...',
    'Scanning alerts: large withdrawal, overdue credit, expiring facilities and covenant status...',
    'Identifying cross-sell opportunities across working capital, trade, treasury and cash management...',
    'Re-ranking portfolio by risk, revenue potential and relationship health...',
    'Generating RM tasks, AI insights and Copilot context...'
  ];

  scanOverlay.classList.remove('hidden');
  progressBar.style.width = '0%';

  for (let i = 0; i < steps.length; i += 1) {
    scanText.textContent = steps[i];
    progressBar.style.width = `${((i + 1) / steps.length) * 100}%`;
    await new Promise(resolve => setTimeout(resolve, 520));
  }

  scanOverlay.classList.add('hidden');
  updateHeaderTime();
  showToast('Portfolio analysis completed. CIMBrain insights refreshed.');
}

function initEvents() {
  loginForm.addEventListener('submit', event => {
    event.preventDefault();

    currentUsername = nameFromEmail(document.getElementById('userId').value);

    loginScreen.classList.add('hidden');
    app.classList.remove('hidden');

    updateHeaderTime();
    showToast('Login successful. Dashboard loaded.');

    setTimeout(() => {
      drawCustomerCharts();
      drawReportCharts();
    }, 80);
  });

  logoutBtn.addEventListener('click', () => {
    app.classList.add('hidden');
    loginScreen.classList.remove('hidden');
  });

  const ssoButton = document.getElementById("ssoBtn");

  if (ssoButton) {
    ssoButton.addEventListener("click", () => {
      showToast("Corporate SSO authentication completed.");
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => showView(item.dataset.view));
  });

  navGroupToggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      toggle.closest('.nav-group').classList.toggle('collapsed');
    });
  });

  document.body.addEventListener('click', event => {
    const targetButton = event.target.closest('[data-view-target]');

    if (targetButton) {
      showView(targetButton.dataset.viewTarget);
      return;
    }

    const customerTarget = event.target.closest('[data-customer-id]');

    if (customerTarget && customerTarget.dataset.customerId) {
      openCustomer(customerTarget.dataset.customerId);
    }
  });

  document.addEventListener('click', event => {
    if (!event.target.closest('.global-search')) {
      globalSearchResults.classList.add('hidden');
    }

    if (!event.target.closest('.notification-wrap')) {
      notificationPanel.classList.add('hidden');
    }
  });

  globalSearchInput.addEventListener('input', handleGlobalSearch);

  globalSearchResults.addEventListener('click', event => {
    const button = event.target.closest('.search-result');
    if (!button || button.dataset.resultIndex === undefined) return;

    const results = JSON.parse(globalSearchResults.dataset.results || '[]');
    const selected = results[Number(button.dataset.resultIndex)];
    if (!selected) return;

    if (selected.customerId) {
      openCustomer(selected.customerId);
    } else {
      showView(selected.view);
    }

    globalSearchInput.value = '';
    globalSearchResults.classList.add('hidden');
  });

  notificationBtn.addEventListener('click', event => {
    event.stopPropagation();
    notificationPanel.classList.toggle('hidden');
  });

  notificationList.addEventListener('click', () => {
    notificationPanel.classList.add('hidden');
    showView('alertsView');
  });

  clearNotificationsBtn.addEventListener('click', event => {
    event.stopPropagation();
    alerts = [];
    renderAlerts();
    renderNotifications();
    notificationPanel.classList.add('hidden');
    showToast('Notifications cleared for demo purposes.');
  });

  ['customerSearch', 'segmentFilter', 'industryFilter'].forEach(id => {
    document.getElementById(id).addEventListener('input', renderPortfolio);
  });

  const customerSelect = document.getElementById("customerSelect");

  if (customerSelect) {
    customerSelect.addEventListener("change", event => {
      selectedCustomerId = event.target.value;
      renderAll();
      drawCustomerCharts();
    });
  }

  document.getElementById('runScanBtn').addEventListener('click', runScan);

  document.getElementById('generateBriefBtn').addEventListener('click', () => {
    const customer = selectedCustomer();
    showToast(`Meeting brief generated for ${customer.name}. Open AI Copilot for draft output.`);
    showView('copilotView');
    addChatMessage(copilotResponse(`Summarise ${customer.name}`));
  });

  document.getElementById('markAlertsBtn').addEventListener('click', () => {
    showToast('Alerts marked as reviewed for demo purposes.');
  });

  document.querySelectorAll('.quick-prompts button').forEach(button => {
    button.addEventListener('click', () => {
      const prompt = button.dataset.prompt;
      addChatMessage(prompt, 'user');
      setTimeout(() => addChatMessage(copilotResponse(prompt)), 250);
    });
  });

  document.getElementById('chatForm').addEventListener('submit', event => {
    event.preventDefault();

    const input = document.getElementById('chatInput');
    const prompt = input.value.trim();

    if (!prompt) return;

    addChatMessage(prompt, 'user');
    input.value = '';

    setTimeout(() => addChatMessage(copilotResponse(prompt)), 250);
  });

  window.addEventListener('resize', () => {
    drawCustomerCharts();
    drawReportCharts();
  });

  const newCustomerBtn = document.getElementById("newCustomerBtn");

  if (newCustomerBtn) {
    newCustomerBtn.addEventListener("click", () => {
      showToast("New customer onboarding form opened for demo.");
    });
  }

  const sideCopilotBtn = document.getElementById("sideCopilotBtn");

  if (sideCopilotBtn) {
    sideCopilotBtn.addEventListener("click", () => {
      showView("copilotView");
    });
  }

  const quickActionsBtn = document.getElementById("quickActionsBtn");
  const quickActionsPanel = document.getElementById("quickActionsPanel");

  if (quickActionsBtn && quickActionsPanel) {
    quickActionsBtn.addEventListener("click", event => {
      event.stopPropagation();
      quickActionsPanel.classList.toggle("hidden");
    });

    quickActionsPanel.addEventListener("click", event => {
      const actionButton = event.target.closest("button");

      if (!actionButton) return;

      showToast(`${actionButton.dataset.action} opened for demo.`);
      quickActionsPanel.classList.add("hidden");
    });
  }

  document.addEventListener("click", event => {
    if (!event.target.closest(".global-search")) {
      globalSearchResults.classList.add("hidden");
    }

    if (!event.target.closest(".notification-wrap")) {
      notificationPanel.classList.add("hidden");
    }

    if (!event.target.closest(".quick-actions-wrap")) {
      const quickActionsPanel = document.getElementById("quickActionsPanel");
      if (quickActionsPanel) quickActionsPanel.classList.add("hidden");
    }
  });

  const topTasksBtn = document.getElementById("topTasksBtn");
  const topAlertsBtn = document.getElementById("topAlertsBtn");

  if (topTasksBtn) {
    topTasksBtn.addEventListener("click", () => {
      showView("tasksView");
    });
  }

  if (topAlertsBtn) {
    topAlertsBtn.addEventListener("click", () => {
      showView("alertsView");
    });
  }

  const dashboardPeriodToggle = document.getElementById("dashboardPeriodToggle");

if (dashboardPeriodToggle) {
  dashboardPeriodToggle.addEventListener("click", event => {
    const button = event.target.closest(".period-btn");
    if (!button) return;

    dashboardPeriod = button.dataset.period;
    renderDashboard();
  });
}

const dashboardModalClose = document.getElementById("dashboardModalClose");
const dashboardModal = document.getElementById("dashboardModal");

if (dashboardModalClose) {
  dashboardModalClose.addEventListener("click", closeDashboardModal);
}

if (dashboardModal) {
  dashboardModal.addEventListener("click", event => {
    if (event.target === dashboardModal) closeDashboardModal();
  });
}

document.body.addEventListener("click", event => {
  const priorityCard = event.target.closest("[data-priority-index]");

  if (priorityCard) {
    const item = dashboardPriorityDetails[Number(priorityCard.dataset.priorityIndex)];
    if (!item) return;

    openDashboardModal("AI Priority", item.title, item.details);
    return;
  }

  const signalButton = event.target.closest("[data-signal-index]");

  if (signalButton) {
    event.stopPropagation();

    const item = marketSignalDetails[Number(signalButton.dataset.signalIndex)];
    if (!item) return;

    openDashboardModal(
      "Market Intelligence",
      `${item.industry}: ${item.title}`,
      `
        <div class="modal-detail-grid">
          <div><span>Summary</span><strong>${item.summary}</strong></div>
          <div><span>Affected Client</span><strong>${item.clients}</strong></div>
          <div><span>Client Impact</span><strong>${item.impact}</strong></div>
          <div><span>AI Recommended Action</span><strong>${item.action}</strong></div>
        </div>
      `
    );
  }
});

  rotateSearchPlaceholder();
}

renderAll();
initEvents();
updateHeaderTime();

addChatMessage('Hi, I am your RM Copilot. Ask me to summarise a customer, draft annual review, recommend cross-sell opportunities, explain risk changes or generate a credit memo.');