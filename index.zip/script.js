const loginScreen = document.getElementById("loginScreen");
const loginForm = document.getElementById("loginForm");
const ssoBtn = document.getElementById("ssoBtn");

const app = document.getElementById('app');
const logoutBtn = document.getElementById('logoutBtn');

const navItems = document.querySelectorAll('.nav-item');
const navGroupToggles = document.querySelectorAll('.nav-group-toggle');
const views = document.querySelectorAll('.view');

const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');
const greetingText = document.getElementById('greetingText');
const summaryDate = document.getElementById('summaryDate');
const lastUpdated = document.getElementById('lastUpdated');

const toast = document.getElementById('toast');
const scanOverlay = document.getElementById('scanOverlay');
const scanText = document.getElementById('scanText');
const progressBar = document.getElementById('progressBar');

const globalSearchInput = document.getElementById('globalSearchInput');
const globalSearchResults = document.getElementById('globalSearchResults');

const notificationBtn = document.getElementById('notificationBtn');
const notificationPanel = document.getElementById('notificationPanel');
const notificationList = document.getElementById('notificationList');
const notificationCount = document.getElementById('notificationCount');
const clearNotificationsBtn = document.getElementById('clearNotificationsBtn');

const customers = [
  {
    id: 'abc',
    name: 'ABC Manufacturing Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Manufacturing',
    relationshipValue: 'High',
    riskRating: 'Good / Stable',
    revenue: 'RM 95m',
    revenueValue: 95,
    ebitda: 'RM 14.8m',
    exposure: 'RM 25.0m',
    exposureValue: 25,
    deposits: 'RM 12.0m',
    depositValue: 12,
    lastContact: 'Yesterday',
    health: 86,
    status: 'Healthy',
    companyProfile: 'Manufacturer of industrial components with import-heavy raw material sourcing.',
    groupStructure: 'Parent company with 3 operating subsidiaries.',
    ubo: 'Lim Wei Kiat, 62% effective ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / KYC refreshed May 2026',
    internalRating: 'CRR 4 - Acceptable',
    products: [
      ['Facilities', 'RM25.0m approved; RM17.8m utilized'],
      ['Deposits', 'RM12.0m average balance'],
      ['CASA', 'Operating account active'],
      ['Trade Finance', 'Import LC and BG potential'],
      ['Treasury', 'Low penetration'],
      ['FX', 'Recurring USD supplier payments']
    ],
    financials: [74, 80, 86, 95],
    repayment: [98, 96, 97, 98, 97, 99],
    ratios: [['Current Ratio', '1.42x'], ['Debt / EBITDA', '2.1x'], ['DSCR', '1.35x'], ['Gross Margin', '22%']],
    creditInfo: [
      ['Credit Limits', 'RM25.0m approved limit'],
      ['Utilisation', '71% current utilization'],
      ['Collateral', 'Factory charge + director guarantee'],
      ['Repayment History', 'No late repayments in 12 months']
    ],
    aiSummary: [
      ['Customer revenue grew 18% YoY', 'Expansion driven by higher export and domestic orders.'],
      ['Deposit balances declined over last 3 months', 'Funds are moving quickly to overseas suppliers after collections.'],
      ['FX opportunity identified', 'Recurring USD payments indicate hedging need.'],
      ['Payment behaviour remains healthy', 'No overdue instalments and stable collection pattern.']
    ],
    nextAction: 'Visit ABC Manufacturing and offer Treasury FX package.',
    aiSignal: 'Declining deposits + recurring USD payments',
    ews: ['Declining deposits', 'Reduced retained balances'],
    churn: 'Low',
    opportunities: ['Working Capital', 'Trade Finance', 'Cash Management', 'Treasury FX']
  },
  {
    id: 'def',
    name: 'DEF Retail Trading Sdn. Bhd.',
    segment: 'SME Commercial',
    industry: 'Retail Trading',
    relationshipValue: 'Medium',
    riskRating: 'Watchlist / Moderate',
    revenue: 'RM 58m',
    revenueValue: 58,
    ebitda: 'RM 6.2m',
    exposure: 'RM 9.4m',
    exposureValue: 9.4,
    deposits: 'RM 6.8m',
    depositValue: 6.8,
    lastContact: '5 days ago',
    health: 71,
    status: 'Monitor',
    companyProfile: 'Retail trading group with seasonal inventory build-up and merchant settlements.',
    groupStructure: 'Single operating company with 8 retail branches.',
    ubo: 'Tan Mei Ling, 70% direct ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / Annual KYC due Sep 2026',
    internalRating: 'CRR 6 - Monitor',
    products: [
      ['Facilities', 'RM9.4m approved; RM7.9m utilized'],
      ['Deposits', 'RM6.8m average balance'],
      ['CASA', 'Merchant settlement account'],
      ['Trade Finance', 'Not active'],
      ['Treasury', 'Not active'],
      ['FX', 'Limited']
    ],
    financials: [49, 52, 55, 58],
    repayment: [95, 92, 91, 94, 90, 92],
    ratios: [['Current Ratio', '1.18x'], ['Debt / EBITDA', '2.8x'], ['DSCR', '1.12x'], ['Gross Margin', '17%']],
    creditInfo: [
      ['Credit Limits', 'RM9.4m approved limit'],
      ['Utilisation', '84% current utilization'],
      ['Collateral', 'Inventory assignment + guarantee'],
      ['Repayment History', '2 minor delays in last 6 months']
    ],
    aiSummary: [
      ['Inventory financing need detected', 'Sales spikes before campaign periods require short-term funding.'],
      ['Limit utilisation nearing threshold', 'Current usage is above 80%.'],
      ['Deposit balance stable', 'Merchant collections remain healthy.'],
      ['Early warning: minor repayment delays', 'Monitor cash-flow before next campaign cycle.']
    ],
    nextAction: 'Offer inventory financing before campaign season.',
    aiSignal: 'High limit utilisation + campaign sales spike',
    ews: ['Limit utilisation >90% risk', 'Late repayments'],
    churn: 'Medium',
    opportunities: ['Working Capital', 'Cash Management']
  },
  {
    id: 'ghi',
    name: 'GHI Exporters Berhad',
    segment: 'Mid Corporate',
    industry: 'Export Manufacturing',
    relationshipValue: 'High',
    riskRating: 'Good / Stable',
    revenue: 'RM 165m',
    revenueValue: 165,
    ebitda: 'RM 21.0m',
    exposure: 'RM 42.0m',
    exposureValue: 42,
    deposits: 'RM 18.5m',
    depositValue: 18.5,
    lastContact: '2 days ago',
    health: 82,
    status: 'Healthy',
    companyProfile: 'Exporter with USD receivables and regional customer concentration.',
    groupStructure: 'Listed holding company with 2 export subsidiaries.',
    ubo: 'Public shareholders; founder family retains 28%',
    rm: 'Qian Tong, Mid Corporate RM',
    onboarding: 'Completed / Beneficial ownership verified',
    internalRating: 'CRR 4 - Acceptable',
    products: [
      ['Facilities', 'RM42.0m approved; RM26.4m utilized'],
      ['Deposits', 'RM18.5m average balance'],
      ['CASA', 'Active multi-currency account'],
      ['Trade Finance', 'Export bills and invoice financing'],
      ['Treasury', 'Ad hoc FX conversion'],
      ['FX', 'High USD receipt volume']
    ],
    financials: [130, 141, 152, 165],
    repayment: [99, 99, 98, 99, 98, 99],
    ratios: [['Current Ratio', '1.58x'], ['Debt / EBITDA', '1.9x'], ['DSCR', '1.52x'], ['Gross Margin', '24%']],
    creditInfo: [
      ['Credit Limits', 'RM42.0m approved limit'],
      ['Utilisation', '63% current utilization'],
      ['Collateral', 'Receivables assignment + debenture'],
      ['Repayment History', 'Excellent repayment record']
    ],
    aiSummary: [
      ['Treasury opportunity identified', 'Large USD conversions happen close to month-end.'],
      ['Receivables financing fit is strong', 'Export settlement cycle creates funding gap.'],
      ['Revenue growth remains strong', 'Customer revenue increased 9% YoY.'],
      ['Payment behaviour remains healthy', 'No overdue payments detected.']
    ],
    nextAction: 'Prepare FX scenario brief for CFO.',
    aiSignal: 'Large USD receipts + ad hoc conversions',
    ews: ['FX volatility exposure'],
    churn: 'Low',
    opportunities: ['Treasury FX', 'Receivables Financing', 'Trade Finance']
  },
  {
    id: 'jkl',
    name: 'JKL Food Processing Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Food Processing',
    relationshipValue: 'Medium',
    riskRating: 'Watchlist / Moderate',
    revenue: 'RM 72m',
    revenueValue: 72,
    ebitda: 'RM 8.1m',
    exposure: 'RM 15.2m',
    exposureValue: 15.2,
    deposits: 'RM 4.9m',
    depositValue: 4.9,
    lastContact: '12 days ago',
    health: 64,
    status: 'At Risk',
    companyProfile: 'Food processor exposed to commodity input costs and supplier concentration.',
    groupStructure: 'Parent company with 1 logistics subsidiary.',
    ubo: 'Ng Soon Huat, 55% effective ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Completed / Financial statements due',
    internalRating: 'CRR 7 - Watchlist',
    products: [
      ['Facilities', 'RM15.2m approved; RM13.9m utilized'],
      ['Deposits', 'RM4.9m average balance'],
      ['CASA', 'Operating account active'],
      ['Trade Finance', 'Limited supplier support'],
      ['Treasury', 'Not active'],
      ['FX', 'Occasional payments']
    ],
    financials: [71, 75, 74, 72],
    repayment: [93, 90, 89, 87, 88, 86],
    ratios: [['Current Ratio', '1.03x'], ['Debt / EBITDA', '3.3x'], ['DSCR', '1.05x'], ['Gross Margin', '13%']],
    creditInfo: [
      ['Credit Limits', 'RM15.2m approved limit'],
      ['Utilisation', '91% current utilization'],
      ['Collateral', 'Plant and machinery + guarantee'],
      ['Repayment History', 'Several small delays detected']
    ],
    aiSummary: [
      ['Limit utilisation exceeds 90%', 'Facility usage is near full capacity.'],
      ['Financial statements overdue', 'Annual review cannot proceed without updated accounts.'],
      ['Supplier concentration detected', 'Payments concentrated to three major suppliers.'],
      ['Risk increased', 'Reduced transaction volume and delayed repayments detected.']
    ],
    nextAction: 'Collect financial statements and review facility limit.',
    aiSignal: 'Utilisation >90% + overdue financial statements',
    ews: ['Limit utilisation >90%', 'Financial statement overdue', 'Late repayments'],
    churn: 'Medium',
    opportunities: ['Facility Review', 'Supply Chain Advisory']
  },
  {
    id: 'mno',
    name: 'MNO Construction Group Sdn. Bhd.',
    segment: 'Commercial',
    industry: 'Construction',
    relationshipValue: 'Medium',
    riskRating: 'High Risk',
    revenue: 'RM 88m',
    revenueValue: 88,
    ebitda: 'RM 5.5m',
    exposure: 'RM 31.0m',
    exposureValue: 31,
    deposits: 'RM 3.1m',
    depositValue: 3.1,
    lastContact: '21 days ago',
    health: 48,
    status: 'High Risk',
    companyProfile: 'Construction contractor with project-based cash flow and high limit usage.',
    groupStructure: 'Holding company with 4 project SPVs.',
    ubo: 'Chong Kar Ming, 51% direct ownership',
    rm: 'Qian Tong, Commercial RM',
    onboarding: 'Enhanced due diligence required',
    internalRating: 'CRR 8 - High Risk',
    products: [
      ['Facilities', 'RM31.0m approved; RM30.2m utilized'],
      ['Deposits', 'RM3.1m average balance'],
      ['CASA', 'Project collection accounts'],
      ['Trade Finance', 'Guarantees and performance bonds'],
      ['Treasury', 'Not active'],
      ['FX', 'Not active']
    ],
    financials: [96, 101, 94, 88],
    repayment: [88, 84, 82, 79, 78, 75],
    ratios: [['Current Ratio', '0.92x'], ['Debt / EBITDA', '4.9x'], ['DSCR', '0.91x'], ['Gross Margin', '9%']],
    creditInfo: [
      ['Credit Limits', 'RM31.0m approved limit'],
      ['Utilisation', '97% current utilization'],
      ['Collateral', 'Project proceeds assignment'],
      ['Repayment History', 'Overdue and restructuring watch']
    ],
    aiSummary: [
      ['Portfolio risk alert', 'Limit utilisation is above 90% and deposit balances are declining.'],
      ['Churn / exit risk elevated', 'Reduced transaction volume and high utilization indicate stress.'],
      ['Credit overdue detected', 'Immediate RM follow-up is required.'],
      ['Covenant review required', 'DSCR has fallen below internal threshold.']
    ],
    nextAction: 'Arrange urgent site visit and credit review.',
    aiSignal: 'Credit overdue + reduced transaction volume',
    ews: ['Credit overdue', 'Covenant breach', 'Large withdrawal', 'Dormant project account'],
    churn: 'High',
    opportunities: ['Restructuring Review', 'Cash Management']
  }
];

const creditDeals = [
  { status: 'Draft', customer: 'ABC Manufacturing', product: 'Working Capital', value: 'RM 8.0m', date: '12 Jul 2026', probability: 35 },
  { status: 'Submitted', customer: 'DEF Retail Trading', product: 'Inventory Financing', value: 'RM 3.5m', date: '15 Jul 2026', probability: 50 },
  { status: 'Credit Review', customer: 'GHI Exporters', product: 'Receivables Financing', value: 'RM 12.0m', date: '18 Jul 2026', probability: 68 },
  { status: 'Additional Information Required', customer: 'JKL Food Processing', product: 'Limit Renewal', value: 'RM 15.2m', date: '22 Jul 2026', probability: 42 },
  { status: 'Approved', customer: 'ABC Manufacturing', product: 'Trade Facility', value: 'RM 5.0m', date: '10 Jul 2026', probability: 90 },
  { status: 'Rejected', customer: 'MNO Construction', product: 'Term Loan', value: 'RM 10.0m', date: '28 Jun 2026', probability: 0 },
  { status: 'Disbursed', customer: 'GHI Exporters', product: 'Export Bills', value: 'RM 7.5m', date: '02 Jul 2026', probability: 100 }
];

const salesOpps = [
  { stage: 'Prospect', customer: 'ABC Manufacturing', product: 'Treasury FX Package', value: 'RM 120k', revenue: 'RM 38k', probability: 25 },
  { stage: 'Qualified', customer: 'DEF Retail Trading', product: 'Cash Management', value: 'RM 80k', revenue: 'RM 24k', probability: 40 },
  { stage: 'Proposal', customer: 'GHI Exporters', product: 'FX Forward', value: 'RM 180k', revenue: 'RM 60k', probability: 65 },
  { stage: 'Negotiation', customer: 'ABC Manufacturing', product: 'Trade Finance', value: 'RM 220k', revenue: 'RM 72k', probability: 78 },
  { stage: 'Won', customer: 'GHI Exporters', product: 'Receivables Financing', value: 'RM 300k', revenue: 'RM 95k', probability: 100 },
  { stage: 'Lost', customer: 'JKL Food Processing', product: 'Treasury Advisory', value: 'RM 40k', revenue: 'RM 12k', probability: 0 }
];

const tasks = [
  ['Call', 'Call CFO of ABC Manufacturing', 'Today, 10:00 AM', 'High'],
  ['Site Visit', 'MNO Construction project site visit', 'Today, 2:30 PM', 'High'],
  ['Meeting', 'GHI Exporters FX scenario review', 'Tomorrow, 11:00 AM', 'Medium'],
  ['Follow-up', 'DEF Retail inventory financing proposal', 'Tomorrow, 4:00 PM', 'Medium'],
  ['Annual Review', 'JKL Food Processing annual review', 'Fri, 9:30 AM', 'High'],
  ['Financial Statement Collection', 'Collect audited FS from JKL', 'Fri, 12:00 PM', 'High']
];

let alerts = [
  ['Large withdrawal', 'ABC Manufacturing transferred RM4.8m to overseas supplier yesterday.', 'warning'],
  ['Credit overdue', 'MNO Construction has overdue repayment requiring follow-up.', 'critical'],
  ['Limit utilisation >90%', 'JKL Food Processing utilisation is now 91%.', 'critical'],
  ['Financial statement overdue', 'JKL Food Processing latest audited financial statements pending.', 'warning'],
  ['Facility expiring', 'ABC Manufacturing trade facility expires in 45 days.', 'info'],
  ['Covenant breach', 'MNO Construction DSCR below internal threshold.', 'critical'],
  ['AML alert', 'Unusual transaction pattern requires review for MNO Construction.', 'warning'],
  ['Dormant account', 'MNO Construction project account inactive for 60 days.', 'info']
];

const documents = [
  ['FY2025 Audited Financial Statements.pdf', 'ABC Manufacturing', 'Financial Statements', 'Current', '28 Jun 2026', 'RM Team'],
  ['Credit Paper - Working Capital.docx', 'ABC Manufacturing', 'Credit Papers', 'Draft', '01 Jul 2026', 'Qian Tong'],
  ['Board Resolution.pdf', 'GHI Exporters', 'Board Resolution', 'Approved', '22 Jun 2026', 'Credit Admin'],
  ['KYC Refresh Form.pdf', 'DEF Retail Trading', 'KYC', 'Due Sep 2026', 'Compliance'],
  ['Company Profile.pdf', 'JKL Food Processing', 'Company Profile', 'Current', '11 Jun 2026', 'RM Team'],
  ['Facility Letter.pdf', 'GHI Exporters', 'Facility Letters', 'Executed', '02 Jul 2026', 'Legal'],
  ['Collateral Valuation.pdf', 'MNO Construction', 'Collateral Documents', 'Review Required', '18 May 2026', 'Credit Risk']
];

const activities = [
  ['Today', 'Call', 'Called ABC CFO to discuss upcoming USD supplier payment.'],
  ['Yesterday', 'Email', 'Sent FX hedging illustration to GHI Exporters.'],
  ['2 days ago', 'Meeting', 'Reviewed merchant settlement trend with DEF Retail.'],
  ['Last week', 'Site Visit', 'Visited JKL production facility and discussed input cost pressure.'],
  ['Last week', 'Notes', 'MNO Construction requested temporary repayment support.']
];

let activeDashboardPeriod = 'today';

const dashboardPeriodMetrics = {
  today: {
    kpis: {
      totalCustomers: ['86', 'Commercial relationships', '+4 reviewed today', 'trend-up'],
      creditExposure: ['RM438m', 'Approved and utilised limits', '+RM6.4m movement', 'trend-up'],
      depositBalance: ['RM212m', 'CASA and fixed deposits', '-RM2.1m today', 'trend-down'],
      portfolioHealth: ['Stable', 'Weighted portfolio risk score', '82 / 100', 'trend-up'],
      revenueContribution: ['RM0.42m', 'Revenue booked today', '+6.1% vs daily run-rate', 'trend-light']
    },
    portfolioMix: [['Manufacturing', 34], ['Construction', 20], ['Retail', 18], ['Services', 15], ['Others', 13]],
    productExposure: [['Working Capital', 38], ['Term Loan', 24], ['Trade Finance', 20], ['Guarantees', 11], ['Treasury', 7]],
    dealMovement: [['Prospect', 8], ['Proposal', 5], ['Review', 3], ['Negotiation', 2], ['Won', 1], ['Lost', 1]],
    rmPerformance: [['Meetings today', '3'], ['Follow-ups due', '12'], ['Revenue booked', 'RM0.42m'], ['Priority actions closed', '5']]
  },
  mtd: {
    kpis: {
      totalCustomers: ['86', 'Customers touched this month', '+18 reviewed MTD', 'trend-up'],
      creditExposure: ['RM438m', 'Approved and utilised limits', '+RM24m MTD', 'trend-up'],
      depositBalance: ['RM212m', 'Average deposits MTD', '-1.8% MTD', 'trend-down'],
      portfolioHealth: ['Stable', 'Weighted portfolio risk score', '81 / 100', 'trend-up'],
      revenueContribution: ['RM4.8m', 'MTD relationship revenue', '+7.2% vs target', 'trend-light']
    },
    portfolioMix: [['Manufacturing', 32], ['Construction', 21], ['Retail', 19], ['Services', 15], ['Others', 13]],
    productExposure: [['Working Capital', 36], ['Term Loan', 25], ['Trade Finance', 21], ['Guarantees', 11], ['Treasury', 7]],
    dealMovement: [['Prospect', 18], ['Proposal', 12], ['Review', 8], ['Negotiation', 6], ['Won', 4], ['Lost', 2]],
    rmPerformance: [['Meetings completed', '24'], ['Pipeline conversion', '41%'], ['Revenue achieved', 'RM4.8m'], ['Annual reviews completed', '33%']]
  },
  ytd: {
    kpis: {
      totalCustomers: ['86', 'Commercial relationships', '+4.8% YTD', 'trend-up'],
      creditExposure: ['RM438m', 'Approved and utilised limits', '+6.2% YTD', 'trend-up'],
      depositBalance: ['RM212m', 'CASA and fixed deposits', '-3.0% YTD', 'trend-down'],
      portfolioHealth: ['Stable', 'Weighted portfolio risk score', '82 / 100', 'trend-up'],
      revenueContribution: ['RM18.7m', 'YTD relationship revenue', '+8.5% YTD', 'trend-light']
    },
    portfolioMix: [['Manufacturing', 34], ['Construction', 20], ['Retail', 18], ['Services', 15], ['Others', 13]],
    productExposure: [['Working Capital', 38], ['Term Loan', 24], ['Trade Finance', 20], ['Guarantees', 11], ['Treasury', 7]],
    dealMovement: [['Prospect', 24], ['Proposal', 18], ['Review', 11], ['Negotiation', 9], ['Won', 7], ['Lost', 4]],
    rmPerformance: [['Meetings completed', '146'], ['Pipeline conversion', '41%'], ['Revenue achieved', 'RM18.7m'], ['Annual reviews completed', '76%']]
  }
};

const dashboardPriorityItems = [
  {
    rank: '01',
    level: 'critical',
    icon: '!',
    title: 'Follow up high-risk customers',
    count: '2 customers',
    impact: 'High Impact',
    confidence: 'AI Confidence 92%',
    detail: 'MNO Construction and JKL Food Processing both show elevated risk signals that need RM action today.',
    affected: 'MNO Construction, JKL Food Processing',
    why: 'Utilisation is above internal comfort levels, repayment behaviour has weakened, and supporting documents are overdue.',
    actions: ['Call both customers today', 'Schedule MNO site visit', 'Collect JKL audited financial statements', 'Escalate credit review notes']
  },
  {
    rank: '02',
    level: 'urgent',
    icon: 'T',
    title: 'Renew expiring facilities',
    count: '11 facilities',
    impact: 'Retention Priority',
    confidence: 'AI Confidence 88%',
    detail: 'Several facilities are entering the renewal window and may create retention or operational risk if not started early.',
    affected: 'ABC Manufacturing, DEF Retail Trading, selected SME accounts',
    why: 'Pending renewals can delay drawdowns, reduce customer confidence, and increase manual follow-up close to expiry.',
    actions: ['Prioritise facilities expiring in 60 days', 'Pre-fill renewal checklist', 'Request latest management accounts', 'Book customer confirmation calls']
  },
  {
    rank: '03',
    level: 'opportunity',
    icon: '$',
    title: 'Offer Treasury FX package',
    count: 'ABC Manufacturing',
    impact: 'Revenue Opportunity',
    confidence: 'AI Confidence 94%',
    detail: 'Recurring USD supplier payments indicate a strong fit for a Treasury FX package before the next payment cycle.',
    affected: 'ABC Manufacturing',
    why: 'Deposit balances are moving out quickly after collections, while supplier payment timing creates a clear hedging conversation.',
    actions: ['Prepare FX proposal', 'Include forward-rate scenarios', 'Coordinate with Treasury specialist', 'Discuss before next supplier payment']
  },
  {
    rank: '04',
    level: 'normal',
    icon: 'R',
    title: 'Accelerate credit reviews',
    count: '9 applications',
    impact: 'Pipeline Priority',
    confidence: 'AI Confidence 76%',
    detail: 'Credit applications in review have missing information or pending clarification that can be resolved by RM follow-up.',
    affected: 'GHI Exporters, DEF Retail Trading, JKL Food Processing',
    why: 'Pipeline movement is slower than target and may delay revenue recognition if clarification items remain open.',
    actions: ['Chase pending documents', 'Confirm open credit queries', 'Update expected decision dates', 'Close low-probability applications']
  }
];

const marketSignals = [
  {
    icon: 'FP',
    industry: 'Food Processing',
    title: 'Palm oil prices rise',
    text: 'May increase working capital needs for food processing customers.',
    url: 'https://bepi.mpob.gov.my/',
    summary: 'Input costs are rising, which can compress margins and increase short-term financing needs.',
    clients: 'JKL Food Processing',
    impact: 'Higher raw material costs may stretch cash conversion cycles and raise limit utilisation.',
    actions: ['Review working capital headroom', 'Request latest purchase forecasts', 'Discuss supplier payment support']
  },
  {
    icon: 'FX',
    industry: 'Export Manufacturing',
    title: 'USD remains firm',
    text: 'Exporters may need renewed FX hedging discussions this week.',
    url: 'https://www.bnm.gov.my/',
    summary: 'Currency movement creates both revenue upside and hedging risk for exporters with USD receipts.',
    clients: 'GHI Exporters, ABC Manufacturing',
    impact: 'Clients with USD flows may need better timing and hedging discipline to protect margins.',
    actions: ['Prepare FX sensitivity view', 'Offer forward contract discussion', 'Coordinate Treasury call']
  },
  {
    icon: 'CT',
    industry: 'Construction',
    title: 'Construction material costs rise',
    text: 'Could pressure margins for construction-related borrowers.',
    url: 'https://www.cidb.gov.my/',
    summary: 'Material cost inflation may reduce project margins and increase drawdown pressure.',
    clients: 'MNO Construction',
    impact: 'Project cash flow may weaken and covenant pressure may increase if claims collection is delayed.',
    actions: ['Request project cash-flow update', 'Review covenant position', 'Schedule site visit']
  },
  {
    icon: 'RT',
    industry: 'Retail Trading',
    title: 'Consumer spending shows uneven recovery',
    text: 'Inventory financing and cashflow cycles may need closer monitoring.',
    url: 'https://www.dosm.gov.my/',
    summary: 'Demand recovery is uneven, making stock planning and settlement cycles more important.',
    clients: 'DEF Retail Trading',
    impact: 'Inventory build-up may increase facility usage before campaign periods.',
    actions: ['Review inventory turnover', 'Discuss seasonal financing', 'Monitor merchant settlement inflows']
  },
  {
    icon: 'TF',
    industry: 'Trade Finance',
    title: 'Shipping delays reported',
    text: 'Trade finance clients may face slower inventory turnover.',
    url: 'https://www.matrade.gov.my/',
    summary: 'Shipping delays can extend inventory cycles and delay customer collections.',
    clients: 'ABC Manufacturing, GHI Exporters',
    impact: 'Longer fulfilment periods may increase short-term working capital needs.',
    actions: ['Check import LC timelines', 'Review receivables financing fit', 'Flag affected shipments']
  }
];

const upcomingMeetings = [
  {
    time: 'Tomorrow - 10:30 AM',
    customer: 'ABC Manufacturing',
    success: 91,
    relationshipValue: 'RM25m',
    focus: 'FX Package',
    tags: ['FX Package', 'Annual Review', 'Deposit Growth'],
    note: 'CIMBrain recommends preparing an FX proposal before the client next supplier payment cycle.'
  },
  {
    time: 'Tomorrow - 3:00 PM',
    customer: 'GHI Exporters',
    success: 84,
    relationshipValue: 'RM42m',
    focus: 'Receivables Financing',
    tags: ['FX Forward', 'Export Bills', 'Receivables'],
    note: 'Bring a short receivables financing view and confirm upcoming USD receipt timing.'
  }
];

const pageMeta = {
  dashboardView: ['Dashboard', 'Operations overview with risk, credit, alerts and approval queues.'],
  portfolioView: ['Customer Portfolio', 'Search, segment and prioritize customers in the RM portfolio.'],
  customer360View: ['Customer 360', 'Consolidated customer profile, facilities, financials and AI summary.'],
  creditPipelineView: ['Credit Pipeline', 'End-to-end financing workflow and approval status.'],
  salesPipelineView: ['Sales Opportunities', 'Sales CRM pipeline across prospect, proposal, negotiation and outcome stages.'],
  alertsView: ['Alerts', 'Real-time alerts for risk, facility, covenant, AML and account events.'],
  copilotView: ['Operations Copilot', 'Controlled assistant for summaries, annual reviews, cross-sell and credit memo drafting.']
};

let selectedCustomerId = 'abc';
let currentUsername = 'Qian Tong';

function selectedCustomer() {
  return customers.find(customer => customer.id === selectedCustomerId) || customers[0];
}

function formatDate(date) {
  return date.toLocaleDateString('en-MY', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatDateTime(date) {
  return date.toLocaleString('en-MY', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getGreeting() {
  const hour = new Date().getHours();

  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function nameFromEmail(value) {
  if (!value) return "Relationship Manager";

  const cleanValue = value.trim();

  if (!cleanValue.includes("@")) {
    return cleanValue;
  }

  return cleanValue
    .split("@")[0]
    .split(/[._-]/)
    .filter(Boolean)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function updateHeaderTime() {
  const now = new Date();

  if (greetingText) {
    greetingText.textContent = `${getGreeting()}, ${currentUsername.toUpperCase()}`;
  }

  if (summaryDate) {
    summaryDate.textContent = "";
  }

  if (lastUpdated) {
    lastUpdated.textContent = `Last updated on: ${formatDateTime(now)}`;
  }

  const riskScanTime = document.getElementById('lastRiskScanTime');
  if (riskScanTime) {
    riskScanTime.textContent = formatDateTime(new Date(now.getTime() - 60 * 60 * 1000));
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');

  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2800);
}

function badgeClass(customer) {
  if (customer.health >= 80) return 'good';
  if (customer.health >= 60) return 'medium';
  return 'bad';
}

function rotateSearchPlaceholder() {
  const prompts = [
    "Search customer, case, alert or document...",
    "Search customer",
    "Who needs attention today?",
    "Generate meeting brief",
    "Show expiring facilities",
    "Summarise Apex Meridian",
    "Prepare annual review"
  ];

  let index = 0;

  setInterval(() => {
    if (!globalSearchInput) return;
    if (document.activeElement === globalSearchInput) return;

    index = (index + 1) % prompts.length;
    globalSearchInput.placeholder = prompts[index];
  }, 2200);
}

function showView(viewId) {
  views.forEach(view => view.classList.toggle('active', view.id === viewId));
  navItems.forEach(item => item.classList.toggle('active', item.dataset.view === viewId));

  const meta = pageMeta[viewId] || pageMeta.dashboardView;

  pageTitle.textContent = meta[0];
  pageSubtitle.textContent = meta[1];

  const dashboardPeriodSwitch = document.querySelector('.dashboard-period-switch');
  if (dashboardPeriodSwitch) {
    dashboardPeriodSwitch.classList.toggle('hidden', viewId !== 'dashboardView');
  }

  if (viewId === 'customer360View') setTimeout(drawCustomerCharts, 80);
  if (viewId === 'reportsView') setTimeout(drawReportCharts, 80);

  globalSearchResults.classList.add('hidden');
}

function openCustomer(customerId) {
  selectedCustomerId = customerId;
  c360Mode = 'detail';
  renderAll();
  showView('customer360View');
}

function getActiveDashboardMetrics() {
  return dashboardPeriodMetrics[activeDashboardPeriod] || dashboardPeriodMetrics.today;
}

function findDashboardKpiCard(label) {
  return Array.from(document.querySelectorAll('#dashboardView .kpi-card'))
    .find(card => {
      const labelEl = card.querySelector('span');
      return labelEl && labelEl.textContent.trim() === label;
    });
}

function setDashboardKpi(label, values) {
  const [value, helperText, trendText, trendClass] = values;
  const card = findDashboardKpiCard(label);
  if (!card) return;

  const valueEl = card.querySelector('strong');
  const helperEl = card.querySelector('p');
  const trendEl = card.querySelector('.kpi-bottom small');

  if (valueEl) valueEl.textContent = value;
  if (helperEl) helperEl.textContent = helperText;

  if (trendEl) {
    trendEl.textContent = trendText;
    trendEl.className = trendClass;
  }
}

function renderDashboardKpis() {
  const { kpis } = getActiveDashboardMetrics();

  setDashboardKpi('Total Customers', kpis.totalCustomers);
  setDashboardKpi('Total Credit Exposure', kpis.creditExposure);
  setDashboardKpi('Deposit Balance', kpis.depositBalance);
  setDashboardKpi('Portfolio Health', kpis.portfolioHealth);
  setDashboardKpi('Revenue Contribution', kpis.revenueContribution);
}

function renderDetailList(items) {
  return `<ul>${items.map(item => `<li>${item}</li>`).join('')}</ul>`;
}

function openDetailModal({ kicker, title, body }) {
  const modal = document.getElementById('detailModal');
  const kickerEl = document.getElementById('detailModalKicker');
  const titleEl = document.getElementById('detailModalTitle');
  const bodyEl = document.getElementById('detailModalBody');

  if (!modal || !titleEl || !bodyEl) return;

  if (kickerEl) kickerEl.textContent = kicker;
  titleEl.textContent = title;
  bodyEl.innerHTML = body;
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
}

function closeDetailModal() {
  const modal = document.getElementById('detailModal');
  if (!modal) return;

  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
}

function openPriorityDetail(index) {
  const item = dashboardPriorityItems[index];
  if (!item) return;

  openDetailModal({
    kicker: 'AI Priorities',
    title: item.title,
    body: `
      <section class="detail-section">
        <strong>What needs attention</strong>
        <p>${item.detail}</p>
      </section>
      <section class="detail-section">
        <strong>Affected clients</strong>
        <p>${item.affected}</p>
      </section>
      <section class="detail-section">
        <strong>Why it matters</strong>
        <p>${item.why}</p>
      </section>
      <section class="detail-section">
        <strong>Recommended actions</strong>
        ${renderDetailList(item.actions)}
      </section>
    `
  });
}

function openMarketDetail(index) {
  const item = marketSignals[index];
  if (!item) return;
  const impact = String(item.impact)
    .replace(/\bJKL\b/g, 'Jelita Kencana Foods')
    .replace(/\bGHI\b/g, 'Global Halcyon Exports')
    .replace(/\bABC\b/g, 'Apex Meridian Industries')
    .replace(/\bDEF\b/g, 'DayaVista Retail')
    .replace(/\bMNO\b/g, 'Murni Nusantara Construction');

  openDetailModal({
    kicker: 'Market Intelligence',
    title: item.title,
    body: `
      <section class="detail-section">
        <strong>Simple summary</strong>
        <p>${item.summary}</p>
      </section>
      <section class="detail-section">
        <strong>Clients affected</strong>
        <p>${item.clients}</p>
      </section>
      <section class="detail-section">
        <strong>How it impacts client</strong>
        <p>${item.impact}</p>
      </section>
      <section class="detail-section">
        <strong>Recommended actions</strong>
        ${renderDetailList(item.actions)}
      </section>
    `
  });
}

function renderDashboardPriorities() {
  const target = document.getElementById('dashboardInsights');
  if (!target) return;

  target.innerHTML = dashboardPriorityItems
    .map((item, index) => `
      <button class="ai-priority-card priority-${item.level}" type="button" data-priority-index="${index}">
        <span class="priority-attention-pill">What needs attention</span>
        <div class="priority-rank">${item.rank}</div>
        <div class="ai-priority-icon">${item.icon}</div>
        <div class="priority-card-body">
          <h4>${item.title}</h4>
          <p>${item.count}</p>
        </div>
        <div class="priority-card-footer">
          <span class="priority-chip impact">${item.impact}</span>
          <span class="ai-confidence-subtle">${item.confidence}</span>
        </div>
      </button>
    `)
    .join('');
}

function renderMarketSignals() {
  const target = document.getElementById('recentActivities');
  if (!target) return;

  target.innerHTML = marketSignals
    .map((item, index) => `
      <div class="market-signal-item">
        <div class="market-signal-industry">
          <span class="market-signal-icon">${item.icon}</span>
          <span>${item.industry}</span>
        </div>
        <div class="market-signal-body">
          <strong>${item.title}</strong>
          <p>${item.text}</p>
        </div>
        <div class="market-signal-actions">
          <button type="button" class="market-detail-btn" data-market-index="${index}">Details</button>
          <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="market-source-link">Source</a>
        </div>
      </div>
    `)
    .join('');
}

function renderDashboardMeetings() {
  const target = document.getElementById('dashboardMeetings');
  if (!target) return;

  target.innerHTML = upcomingMeetings
    .map(meeting => `
      <div class="clean-meeting-card dashboard-meeting-card">
        <div class="meeting-success-bubble">
          <strong>${meeting.success}%</strong>
          <span>Success</span>
        </div>
        <div class="meeting-card-top">
          <div>
            <small>${meeting.time}</small>
            <h4>${meeting.customer}</h4>
          </div>
        </div>
        <div class="meeting-success-progress" aria-label="Estimated success ${meeting.success}%">
          <div style="width:${meeting.success}%"></div>
        </div>
        <div class="meeting-stats">
          <div>
            <span>Relationship Value</span>
            <strong>${meeting.relationshipValue}</strong>
          </div>
          <div>
            <span>Recommended Focus</span>
            <strong>${meeting.focus}</strong>
          </div>
        </div>
        <div class="meeting-topic-tags">
          ${meeting.tags.map(tag => `<span>${tag}</span>`).join('')}
        </div>
        <p>${meeting.note}</p>
      </div>
    `)
    .join('');
}

function renderDashboard() {
  const getRiskBadge = customer => {
    if (customer.health >= 80) {
      return `<span class="risk-dot-badge good">● Healthy</span>`;
    }

    if (customer.health >= 60) {
      return `<span class="risk-dot-badge warn">● Watchlist</span>`;
    }

    return `<span class="risk-dot-badge risk">● High Risk</span>`;
  };

  const getConfidenceChip = customer => {
    if (customer.health >= 80) {
      return `<span class="ai-confidence-subtle">AI Confidence • 94%</span>`;
    }

    if (customer.health >= 60) {
      return `<span class="ai-confidence-subtle warn">AI Confidence • 76%</span>`;
    }

    return `<span class="ai-confidence-subtle risk">AI Confidence • 58%</span>`;
  };

  const dashboardRows = [...customers]
    .sort((a, b) => a.health - b.health)
    .map(customer => `
      <tr data-customer-id="${customer.id}">
        <td>
          <button class="customer-button" data-customer-id="${customer.id}">
            <div class="customer-name-block">
              <strong>${customer.name}</strong>
              <small>${customer.industry}</small>
            </div>
          </button>
        </td>
        <td>${customer.exposure}</td>
        <td>${getRiskBadge(customer)}</td>
        <td>
          <div class="next-action-clean">
            <strong>${customer.nextAction}</strong>
            ${getConfidenceChip(customer)}
          </div>
        </td>
      </tr>
    `)
    .join("");

  document.getElementById("dashboardCustomerRows").innerHTML = dashboardRows;

  document.getElementById("dashboardInsights").innerHTML = [
    {
      rank: "01",
      level: "critical",
      icon: "HI",
      title: "Follow up high-risk customers",
      count: "2 customers",
      impact: "High Impact",
      due: "Due Today",
      confidence: "AI Confidence • 92%"
    },
    {
      rank: "02",
      level: "urgent",
      icon: "TM",
      title: "Renew expiring facilities",
      count: "11 facilities",
      impact: "Retention Priority",
      due: "Next 60 Days",
      confidence: "AI Confidence • 88%"
    },
    {
      rank: "03",
      level: "opportunity",
      icon: "FX",
      title: "Offer Treasury FX package",
      count: "ABC Manufacturing",
      impact: "Revenue Opportunity",
      due: "This Week",
      confidence: "AI Confidence • 94%"
    },
    {
      rank: "04",
      level: "normal",
      icon: "CR",
      title: "Accelerate credit reviews",
      count: "9 applications",
      impact: "Pipeline Priority",
      due: "3 Urgent",
      confidence: "AI Confidence • 76%"
    }
  ]
    .map(item => `
      <div class="ai-priority-card priority-${item.level}">
        <div class="priority-rank">${item.rank}</div>

        <div class="ai-priority-icon">${item.icon}</div>

        <div>
          <h4>${item.title}</h4>
          <p>${item.count}</p>
        </div>

        <div class="priority-card-footer">
          <span class="priority-chip impact">${item.impact}</span>
          <span class="priority-chip">${item.due}</span>
          <span class="ai-confidence-subtle">${item.confidence}</span>
        </div>
      </div>
    `)
    .join("");

  document.getElementById("recentActivities").innerHTML = [
    [
      "Food Processing",
      "Palm oil prices rise",
      "May increase working capital needs for food processing customers.",
      "https://bepi.mpob.gov.my/"
    ],
    [
      "Export Manufacturing",
      "USD remains firm",
      "Exporters may need renewed FX hedging discussions this week.",
      "https://www.bnm.gov.my/"
    ],
    [
      "Construction",
      "Construction material costs rise",
      "Could pressure margins for construction-related borrowers.",
      "https://www.cidb.gov.my/"
    ],
    [
      "Retail Trading",
      "Consumer spending shows uneven recovery",
      "Inventory financing and cashflow cycles may need closer monitoring.",
      "https://www.dosm.gov.my/"
    ],
    [
      "Trade Finance",
      "Shipping delays reported",
      "Trade finance clients may face slower inventory turnover.",
      "https://www.matrade.gov.my/"
    ]
  ]
    .map(([industry, title, text, url]) => `
      <div class="market-signal-item">
        <div class="market-signal-industry">${industry}</div>

        <div class="market-signal-body">
          <strong>${title}</strong>
          <p>${text}</p>
        </div>

        <a href="${url}" target="_blank" rel="noopener noreferrer" class="market-source-link">
          source
        </a>
      </div>
    `)
    .join("");

  renderDashboardKpis();
  renderDashboardPriorities();
  renderMarketSignals();
  renderDashboardMeetings();
  renderDashboardAnalytics();
}

function renderDashboardAnalytics() {
  const {
    portfolioMix,
    productExposure,
    dealMovement,
    rmPerformance
  } = getActiveDashboardMetrics();

  const maxDealValue = Math.max(...dealMovement.map(item => item[1]));

  const portfolioMixEl = document.getElementById("dashboardPortfolioMix");
  if (portfolioMixEl) {
    portfolioMixEl.innerHTML = portfolioMix
      .map(([label, value]) => `
        <div class="pink-bar-row">
          <div class="pink-bar-head">
            <strong>${label}</strong>
            <span>${value}%</span>
          </div>
          <div class="pink-bar-track">
            <div class="pink-bar-fill" style="width:${value}%"></div>
          </div>
        </div>
      `)
      .join("");
  }

  const productExposureEl = document.getElementById("dashboardProductExposure");
  if (productExposureEl) {
    productExposureEl.innerHTML = productExposure
      .map(([label, value]) => `
        <div class="pink-bar-row product-wide-row">
          <div class="pink-bar-head">
            <strong>${label}</strong>
            <span>${value}%</span>
          </div>
          <div class="pink-bar-track">
            <div class="pink-bar-fill strong" style="width:${value}%"></div>
          </div>
        </div>
      `)
      .join("");
  }

  const dealMovementEl = document.getElementById("dashboardDealMovement");
  if (dealMovementEl) {
    dealMovementEl.innerHTML = dealMovement
      .map(([label, value]) => `
        <div class="pink-bar-row compact-bar-row">
          <div class="pink-bar-head">
            <strong>${label}</strong>
            <span>${value}</span>
          </div>
          <div class="pink-bar-track">
            <div class="pink-bar-fill soft" style="width:${(value / maxDealValue) * 100}%"></div>
          </div>
        </div>
      `)
      .join("");
  }

  const rmPerformanceEl = document.getElementById("dashboardRMPerformance");
  if (rmPerformanceEl) {
    rmPerformanceEl.innerHTML = rmPerformance
      .map(([label, value]) => `
        <div class="rm-performance-item">
          <span>${label}</span>
          <strong>${value}</strong>
        </div>
      `)
      .join("");
  }
}

function renderPortfolio() {
  const search = document.getElementById('customerSearch').value.toLowerCase();
  const segment = document.getElementById('segmentFilter').value;
  const industryValue = document.getElementById('industryFilter').value;

  const filtered = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(search) || customer.industry.toLowerCase().includes(search);
    const matchesSegment = segment === 'All' || customer.segment === segment;
    const matchesIndustry = industryValue === 'All' || customer.industry === industryValue;

    return matchesSearch && matchesSegment && matchesIndustry;
  });

  document.getElementById('portfolioRows').innerHTML = filtered.map(customer => `
    <tr data-customer-id="${customer.id}">
      <td><button class="customer-button" data-customer-id="${customer.id}">${customer.name}</button></td>
      <td>${customer.segment}</td>
      <td>${customer.industry}</td>
      <td>${customer.relationshipValue}</td>
      <td>${customer.riskRating}</td>
      <td>${customer.revenue}</td>
      <td>${customer.exposure}</td>
      <td>${customer.deposits}</td>
      <td>${customer.lastContact}</td>
      <td><span class="badge ${badgeClass(customer)}">${customer.health}</span></td>
    </tr>
  `).join('');
}

function renderCustomerSelectors() {
  const options = customers
    .map(customer => `<option value="${customer.id}">${customer.name}</option>`)
    .join("");

  const customerSelect = document.getElementById("customerSelect");

  if (customerSelect) {
    customerSelect.innerHTML = options;
    customerSelect.value = selectedCustomerId;
  }
}

function renderCustomer360() {
  const customer = selectedCustomer();

  document.getElementById('customerName').textContent = customer.name;
  document.getElementById('customerHealthBadge').textContent = `${customer.status} · ${customer.health}`;
  document.getElementById('customerHealthBadge').className = `badge ${badgeClass(customer)}`;

  document.getElementById('companyProfile').textContent = customer.companyProfile;
  document.getElementById('groupStructure').textContent = customer.groupStructure;
  document.getElementById('ubo').textContent = customer.ubo;
  document.getElementById('relationshipManager').textContent = customer.rm;
  document.getElementById('onboardingStatus').textContent = customer.onboarding;
  document.getElementById('internalRating').textContent = customer.internalRating;

  document.getElementById('aiSummaryList').innerHTML = customer.aiSummary
    .map(([title, text]) => `<div class="insight-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  document.getElementById('bankingProducts').innerHTML = customer.products
    .map(([title, text]) => `<div class="product-card"><strong>${title}</strong><span>${text}</span></div>`)
    .join('');

  document.getElementById('creditInfo').innerHTML = customer.creditInfo
    .map(([title, text]) => `<div class="metric-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  document.getElementById('ratioCards').innerHTML = customer.ratios
    .map(([title, value]) => `<div><strong>${value}</strong><span>${title}</span></div>`)
    .join('');

  document.getElementById('customerSelect').value = selectedCustomerId;

  renderCustomerInteractions();
  renderCustomerDocuments();
}

function getCustomerShortName(customer) {
  if (customer.shortName) return customer.shortName;

  return customer.name
    .replace(" Sdn. Bhd.", "")
    .replace(" Berhad", "")
    .replace(" Group", "")
    .trim();
}

function interactionIconId(title) {
  const clean = title.toLowerCase();
  if (clean.includes('call')) return 'i-customer';
  if (clean.includes('email') || clean.includes('document') || clean.includes('memo')) return 'i-documents';
  if (clean.includes('treasury') || clean.includes('deposit')) return 'i-reports';
  if (clean.includes('risk') || clean.includes('watchlist') || clean.includes('covenant')) return 'i-alert';
  if (clean.includes('meeting') || clean.includes('site')) return 'i-calendar';
  return 'i-copilot';
}

function renderCustomerInteractions() {
  const customer = selectedCustomer();

  const interactionMap = {
    abc: [
      ["09:32 AM", "CL", "Call", "Discussed upcoming USD supplier payment with CFO."],
      ["Yesterday", "EM", "Email Sent", "Sent indicative FX hedging proposal."],
      ["2 days ago", "CM", "Credit Memo", "Working capital memo prepared for internal review."],
      ["Last week", "DP", "Deposit Movement", "RM4.8m supplier payment detected."]
    ],
    def: [
      ["10:20 AM", "EM", "Email Sent", "Followed up on inventory financing documents."],
      ["Yesterday", "MT", "Meeting", "Discussed campaign season working capital needs."],
      ["5 days ago", "RN", "Risk Note", "Minor repayment delay flagged for monitoring."]
    ],
    ghi: [
      ["11:48 AM", "EM", "Email Sent", "Sent FX hedging illustration to CFO."],
      ["Yesterday", "TR", "Treasury", "Large USD conversion identified near month-end."],
      ["2 days ago", "MT", "Meeting", "Reviewed export receivables financing opportunity."]
    ],
    jkl: [
      ["02:20 PM", "SV", "Site Visit", "Reviewed input cost pressure and facility usage."],
      ["Yesterday", "DR", "Document Request", "Requested latest audited financial statements."],
      ["Last week", "WL", "Watchlist", "High utilisation and delayed repayment noted."]
    ],
    mno: [
      ["09:10 AM", "RA", "Risk Alert", "Moved into high-risk monitoring."],
      ["Yesterday", "SV", "Site Visit", "Project site visit arranged for credit review."],
      ["Last week", "CR", "Covenant Review", "DSCR below internal threshold."]
    ]
  };

  const target = document.getElementById("customerInteractionList");
  if (!target) return;

  const interactions = interactionMap[customer.id] || [];

  target.innerHTML = interactions
    .map(([time, icon, title, text]) => `
      <div class="customer-interaction-item">
        <div class="customer-interaction-icon professional-interaction-icon" aria-hidden="true"><svg class="icon"><use href="#${interactionIconId(title)}"></use></svg></div>
        <div class="customer-interaction-content">
          <small>${time}</small>
          <strong>${title}</strong>
          <p>${text}</p>
        </div>
      </div>
    `)
    .join("");
}

function renderCustomerDocuments() {
  const customer = selectedCustomer();
  const shortName = getCustomerShortName(customer);

  const customerDocs = documents.filter(doc => {
    const docCustomer = doc[1];
    return shortName.includes(docCustomer) || docCustomer.includes(shortName);
  });

  const target = document.getElementById("customerDocumentsList");
  if (!target) return;

  target.innerHTML = customerDocs.length
    ? customerDocs
        .map(([fileName, customerName, category, status, date, owner]) => `
          <div class="customer-document-card">
            <small>${category}</small>
            <strong>${fileName}</strong>
            <p>${customerName}</p>

            <div class="customer-document-meta">
              <span class="status">${status}</span>
              <span>${date}</span>
              <span>${owner}</span>
            </div>
          </div>
        `)
        .join("")
    : `
      <div class="customer-document-card">
        <strong>No documents found</strong>
        <p>No repository items are currently tagged to this customer.</p>
      </div>
    `;
}

function getCustomerShortName(customer) {
  if (customer.shortName) return customer.shortName;

  return customer.name
    .replace(" Sdn. Bhd.", "")
    .replace(" Berhad", "")
    .replace(" Group", "")
    .trim();
}

function renderCustomerInteractions() {
  const customer = selectedCustomer();

  const interactionMap = {
    abc: [
      ["09:32 AM", "CL", "Call", "Discussed upcoming USD supplier payment with CFO."],
      ["Yesterday", "EM", "Email Sent", "Sent indicative FX hedging proposal."],
      ["2 days ago", "CM", "Credit Memo", "Working capital memo prepared for internal review."],
      ["Last week", "DP", "Deposit Movement", "RM4.8m supplier payment detected."]
    ],
    def: [
      ["10:20 AM", "EM", "Email Sent", "Followed up on inventory financing documents."],
      ["Yesterday", "MT", "Meeting", "Discussed campaign season working capital needs."],
      ["5 days ago", "RN", "Risk Note", "Minor repayment delay flagged for monitoring."]
    ],
    ghi: [
      ["11:48 AM", "EM", "Email Sent", "Sent FX hedging illustration to CFO."],
      ["Yesterday", "TR", "Treasury", "Large USD conversion identified near month-end."],
      ["2 days ago", "MT", "Meeting", "Reviewed export receivables financing opportunity."]
    ],
    jkl: [
      ["02:20 PM", "SV", "Site Visit", "Reviewed input cost pressure and facility usage."],
      ["Yesterday", "DR", "Document Request", "Requested latest audited financial statements."],
      ["Last week", "WL", "Watchlist", "High utilisation and delayed repayment noted."]
    ],
    mno: [
      ["09:10 AM", "RA", "Risk Alert", "Moved into high-risk monitoring."],
      ["Yesterday", "SV", "Site Visit", "Project site visit arranged for credit review."],
      ["Last week", "CR", "Covenant Review", "DSCR below internal threshold."]
    ]
  };

  const interactions = interactionMap[customer.id] || [];

  const target = document.getElementById("customerInteractionList");
  if (!target) return;

  target.innerHTML = interactions
    .map(([time, icon, title, text]) => `
      <div class="customer-interaction-item">
        <div class="customer-interaction-icon professional-interaction-icon" aria-hidden="true"><svg class="icon"><use href="#${interactionIconId(title)}"></use></svg></div>
        <div class="customer-interaction-content">
          <small>${time}</small>
          <strong>${title}</strong>
          <p>${text}</p>
        </div>
      </div>
    `)
    .join("");
}

function renderCustomerDocuments() {
  const customer = selectedCustomer();
  const shortName = getCustomerShortName(customer);

  const customerDocs = documents.filter(doc => {
    const docCustomer = doc[1];
    return shortName.includes(docCustomer) || docCustomer.includes(shortName);
  });

  const target = document.getElementById("customerDocumentsList");
  if (!target) return;

  target.innerHTML = customerDocs.length
    ? customerDocs
        .map(([fileName, customerName, category, status, date, owner]) => `
          <div class="customer-document-card">
            <small>${category}</small>
            <strong>${fileName}</strong>
            <p>${customerName}</p>

            <div class="customer-document-meta">
              <span class="status">${status}</span>
              <span>${date}</span>
              <span>${owner}</span>
            </div>
          </div>
        `)
        .join("")
    : `
      <div class="customer-document-card">
        <strong>No documents found</strong>
        <p>No repository items are currently tagged to this customer.</p>
      </div>
    `;
}

function renderCreditPipeline() {
  const statuses = ['Draft', 'Submitted', 'Credit Review', 'Additional Information Required', 'Approved', 'Rejected', 'Disbursed'];

  document.getElementById('creditPipeline').innerHTML = statuses.map(status => {
    const cards = creditDeals
      .filter(deal => deal.status === status)
      .map(deal => `
        <div class="pipeline-card">
          <strong>${deal.customer}</strong>
          <span>Product: ${deal.product}</span>
          <span>Deal Value: ${deal.value}</span>
          <span>Expected Approval: ${deal.date}</span>
          <span>Probability: ${deal.probability}%</span>
          <div class="probability"><div style="width:${deal.probability}%"></div></div>
        </div>
      `)
      .join('') || '<p class="table-note">No deals</p>';

    return `<div class="pipeline-column"><h4>${status}</h4>${cards}</div>`;
  }).join('');
}

function renderSalesPipeline() {
  const stages = ['Prospect', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];

  document.getElementById('salesPipeline').innerHTML = stages.map(stage => {
    const cards = salesOpps
      .filter(opp => opp.stage === stage)
      .map(opp => `
        <div class="opportunity-card">
          <strong>${opp.customer}</strong>
          <span>Product: ${opp.product}</span>
          <span>Opportunity Value: ${opp.value}</span>
          <span>Expected Revenue: ${opp.revenue}</span>
          <span>Probability: ${opp.probability}%</span>
          <div class="probability"><div style="width:${opp.probability}%"></div></div>
        </div>
      `)
      .join('') || '<p class="table-note">No opportunities</p>';

    return `<div class="kanban-column"><h4>${stage}</h4>${cards}</div>`;
  }).join('');
}

function renderAIInsights() {
  document.getElementById('portfolioRiskCards').innerHTML = customers
    .filter(customer => customer.health < 75)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>${customer.aiSignal}. Health score: ${customer.health}.</p></div>`)
    .join('');

  document.getElementById('growthCards').innerHTML = customers
    .filter(customer => customer.opportunities.length > 2)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>Eligible for: ${customer.opportunities.join(', ')}.</p></div>`)
    .join('');

  document.getElementById('nextBestActionCards').innerHTML = customers
    .slice(0, 4)
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>${customer.nextAction}</p></div>`)
    .join('');

  document.getElementById('churnCards').innerHTML = customers
    .map(customer => `<div class="insight-item"><strong>${customer.name}</strong><p>Churn prediction: ${customer.churn}. Main signal: ${customer.aiSignal}.</p></div>`)
    .join('');

  document.getElementById('ewsCards').innerHTML = alerts
    .map(([title, text, severity]) => `
      <div class="warning-card">
        <strong>${title}</strong>
        <p>${text}</p>
        <span class="badge ${severity === 'critical' ? 'bad' : severity === 'warning' ? 'medium' : 'neutral'}">${severity}</span>
      </div>
    `)
    .join('');
}

function renderTasks() {
  const taskList = document.getElementById('taskList');
  const calendarGrid = document.getElementById('calendarGrid');
  if (!taskList || !calendarGrid) return;

  taskList.innerHTML = tasks.map(([type, title, time, priority]) => `
    <div class="task-item">
      <strong>${type}: ${title}</strong>
      <p>${time} · Priority: ${priority}</p>
    </div>
  `).join('');

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

  calendarGrid.innerHTML = days.map((day, index) => {
    const dayTasks = tasks.filter((_, taskIndex) => taskIndex % 5 === index);

    return `
      <div class="calendar-day">
        <h4>${day}</h4>
        ${dayTasks.map(task => `<div class="calendar-event"><strong>${task[0]}</strong><br>${task[1]}</div>`).join('')}
      </div>
    `;
  }).join('');
}

function renderAlerts() {
  document.getElementById('alertsList').innerHTML = alerts.map(([title, text, severity]) => `
    <div class="alert-item ${severity}">
      <strong>${title}</strong>
      <p>${text}</p>
    </div>
  `).join('');
}

function renderNotifications() {
  const notificationSummary = [
    { icon: 'i-alert', title: '2 High Risk Customers', text: 'Immediate RM attention required', view: 'alertsView' },
    { icon: 'i-pipeline', title: '4 Applications Awaiting Approval', text: 'Pending credit decision', view: 'creditPipelineView' },
    { icon: 'i-engagement', title: '1 Relationship Milestone', text: 'Engagement opportunity', view: 'customer360View', customerId: 'abc' },
    { icon: 'i-calendar', title: '1 Credit Limit Expiring', text: 'Facility review due soon', view: 'alertsView' }
  ];

  const notificationTotal = 8;
  notificationCount.textContent = String(notificationTotal);
  const sideAlertCount = document.getElementById('sideAlertCount');
  if (sideAlertCount) sideAlertCount.textContent = String(notificationTotal);

  notificationList.innerHTML = notificationSummary
    .map(item => `
      <button type="button" class="notification-summary-item" data-notification-view="${item.view}" ${item.customerId ? `data-notification-customer="${item.customerId}"` : ''}>
        <span class="notification-logo" aria-hidden="true"><svg class="icon"><use href="#${item.icon}"></use></svg></span>
        <div>
          <strong>${item.title}</strong>
          <span>${item.text}</span>
        </div>
      </button>
    `)
    .join("");
}

function renderDocuments() {
  document.getElementById('documentRows').innerHTML = documents.map(doc => `
    <tr>
      <td><strong>${doc[0]}</strong></td>
      <td>${doc[1]}</td>
      <td>${doc[2]}</td>
      <td>${doc[3]}</td>
      <td>${doc[4]}</td>
      <td>${doc[5]}</td>
    </tr>
  `).join('');
}

function renderEngagement() {
  document.getElementById('engagementCustomerSelect').value = selectedCustomerId;

  document.getElementById('engagementTimeline').innerHTML = activities.map(([date, type, text]) => `
    <div class="timeline-item">
      <div class="timeline-date">${date}</div>
      <div class="timeline-content"><strong>${type}</strong><p>${text}</p></div>
    </div>
  `).join('');
}

function renderReports() {
  const data = getReportPeriodData(activeReportPeriod);

  renderBarChart('industryChart', data.portfolioMix);
  renderBarChart('loanMixChart', data.productExposure);
  renderBarChart('stageChart', data.dealMovement);

  const conversionTarget = document.getElementById('pipelineConversionMetric');
  if (conversionTarget) {
    conversionTarget.innerHTML = `
      <span>Pipeline conversion</span>
      <strong>${data.pipelineConversion}</strong>
      <small>${data.pipelineConversionNote}</small>
    `;
  }

  document.getElementById('rmPerformance').innerHTML = data.rmReports
    .map(report => `
      <div class="export-report-card">
        <div>
          <strong>${report.title}</strong>
          <p>${report.text}</p>
          <small>${report.metric}</small>
        </div>
        <button type="button" class="text-button" data-export-report="${report.title}">Export</button>
      </div>
    `)
    .join('');

  drawReportCharts();
}

function getDashboardReportRows(period, key) {
  const mappedPeriod = ['today', 'mtd', 'ytd'].includes(period) ? period : 'ytd';
  return dashboardPeriodMetrics[mappedPeriod]?.[key] || [];
}

function getReportPeriodData(period = activeReportPeriod) {
  const periodData = {
    today: {
      portfolioMix: getDashboardReportRows('today', 'portfolioMix'),
      productExposure: getDashboardReportRows('today', 'productExposure'),
      dealMovement: [['Prospect', 8], ['Proposal', 5], ['Review', 3], ['Negotiation', 2], ['Won', 1], ['Lost', 1]],
      pipelineConversion: '50%',
      pipelineConversionNote: '1 won / 2 closed today',
      rmReports: [
        { title: 'Daily RM Activity Report', text: '3 meetings, 12 follow-ups due, 5 actions closed.', metric: 'PDF / Excel ready' },
        { title: 'Priority Action SLA Report', text: '2 critical cases and 3 warning items remain open.', metric: 'Updated today' },
        { title: 'Revenue Booking Report', text: 'RM0.42m booked today with 3 fee events pending.', metric: 'Finance export' },
        { title: 'Customer Contact Report', text: 'Calls, visits and pending callbacks across active customers.', metric: 'RM audit trail' }
      ]
    },
    mtd: {
      portfolioMix: getDashboardReportRows('mtd', 'portfolioMix'),
      productExposure: getDashboardReportRows('mtd', 'productExposure'),
      dealMovement: [['Prospect', 18], ['Proposal', 12], ['Review', 8], ['Negotiation', 6], ['Won', 4], ['Lost', 2]],
      pipelineConversion: '67%',
      pipelineConversionNote: '4 won / 6 closed MTD',
      rmReports: [
        { title: 'MTD Coverage Report', text: '24 meetings completed and 18 customers reviewed.', metric: 'Coverage pack' },
        { title: 'Pipeline Conversion Report', text: '41% weighted conversion with RM4.8m revenue achieved.', metric: 'Sales governance' },
        { title: 'Annual Review Progress', text: '33% of annual reviews completed this month.', metric: 'Credit readiness' },
        { title: 'Cross-sell Activity Report', text: '8 opportunities logged with 5 high-confidence recommendations.', metric: 'Growth tracking' }
      ]
    },
    '3m': {
      portfolioMix: [['Manufacturing', 31], ['Export', 25], ['Retail', 17], ['Construction', 15], ['Food', 12]],
      productExposure: [['Working Capital', 37], ['Trade Finance', 23], ['Term Loan', 22], ['Guarantees', 10], ['Treasury', 8]],
      dealMovement: [['Prospect', 22], ['Qualified', 18], ['Proposal', 24], ['Negotiation', 16], ['Won', 13], ['Lost', 7]],
      pipelineConversion: '65%',
      pipelineConversionNote: '13 won / 20 closed over 3M',
      rmReports: [
        { title: 'Quarterly Relationship Review', text: 'Coverage, risk, revenue and opportunity movement.', metric: 'Board-ready PDF' },
        { title: 'RM Productivity Report', text: 'Meetings, call packs, follow-ups and closure velocity.', metric: 'Excel export' },
        { title: 'Credit SLA Performance', text: 'Approval cycle time and information-request delays.', metric: 'Credit ops report' },
        { title: 'Wallet Growth Report', text: 'Product penetration, wallet share and untapped opportunity.', metric: 'AI appendix' }
      ]
    },
    '6m': {
      portfolioMix: [['Manufacturing', 33], ['Export', 24], ['Retail', 18], ['Food', 13], ['Construction', 12]],
      productExposure: [['Working Capital', 38], ['Term Loan', 24], ['Trade Finance', 20], ['Guarantees', 11], ['Treasury', 7]],
      dealMovement: [['Prospect', 20], ['Qualified', 19], ['Proposal', 26], ['Negotiation', 17], ['Won', 12], ['Lost', 6]],
      pipelineConversion: '67%',
      pipelineConversionNote: '12 won / 18 closed over 6M',
      rmReports: [
        { title: 'Half-Year RM Scorecard', text: 'Portfolio value, revenue, coverage and sales conversion.', metric: 'Management pack' },
        { title: 'High-Risk Customer Report', text: 'Watchlist migration, mitigants and RM action status.', metric: 'Risk export' },
        { title: 'Facility Renewal Report', text: 'Renewal pipeline, expiries and document readiness.', metric: 'Credit workflow' },
        { title: 'Revenue Leakage Report', text: 'Deposit attrition, fee gaps and missed cross-sell events.', metric: 'Growth control' }
      ]
    },
    ytd: {
      portfolioMix: getDashboardReportRows('ytd', 'portfolioMix'),
      productExposure: getDashboardReportRows('ytd', 'productExposure'),
      dealMovement: [['Prospect', 24], ['Proposal', 18], ['Review', 11], ['Negotiation', 9], ['Won', 7], ['Lost', 4]],
      pipelineConversion: '64%',
      pipelineConversionNote: '7 won / 11 closed YTD',
      rmReports: [
        { title: 'YTD RM Performance Pack', text: 'Revenue, meetings, review completion and conversion.', metric: 'Executive PDF' },
        { title: 'Customer Portfolio Report', text: '10 active customers, risk tier movement and exposure mix.', metric: 'Excel workbook' },
        { title: 'Pipeline Governance Report', text: 'Deal stage ageing, conversion, approvals and losses.', metric: 'CRM export' },
        { title: 'Relationship Revenue Report', text: 'RM18.7m YTD revenue with fee, loan and treasury split.', metric: 'Finance view' }
      ]
    }
  };

  return periodData[period] || periodData.ytd;
}

function renderBarChart(targetId, rows) {
  document.getElementById(targetId).innerHTML = rows.map(([label, value]) => `
    <div class="bar-row">
      <strong>${label}</strong>
      <div class="bar-track"><div class="bar-fill" style="width:${value}%"></div></div>
      <span>${value}%</span>
    </div>
  `).join('');
}

function getChartTooltip() {
  let tooltip = document.getElementById('chartHoverTooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = 'chartHoverTooltip';
    tooltip.className = 'chart-hover-tooltip hidden';
    document.body.appendChild(tooltip);
  }
  return tooltip;
}

function drawLineChart(canvasId, values, title, options = {}) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const chartValues = values.map(Number);
  const padding = { top: 46, right: 30, bottom: 52, left: 62 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const maxValue = Math.max(...chartValues);
  const minValue = Math.min(...chartValues);
  const max = Math.ceil((maxValue + 6) / 5) * 5;
  const min = Math.max(0, Math.floor((minValue - 6) / 5) * 5);
  const range = Math.max(1, max - min);
  const labels = options.labels || chartValues.map((_, index) => `P${index + 1}`);
  const yAxisLabel = options.yAxisLabel || 'Value';
  const xAxisLabel = options.xAxisLabel || 'Period';
  const valueSuffix = options.valueSuffix || '';
  const valuePrefix = options.valuePrefix || '';
  const hoverIndex = Number.isInteger(options.hoverIndex) ? options.hoverIndex : -1;

  ctx.clearRect(0, 0, width, height);

  ctx.fillStyle = '#fffefa';
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = '#f0c6cd';
  ctx.lineWidth = 1;

  for (let i = 0; i <= 4; i += 1) {
    const y = padding.top + (chartHeight / 4) * i;
    const tickValue = Math.round(max - (range / 4) * i);

    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(width - padding.right, y);
    ctx.stroke();

    ctx.fillStyle = '#735e64';
    ctx.font = '11px Arial';
    ctx.textAlign = 'right';
    ctx.fillText(`${valuePrefix}${tickValue}${valueSuffix}`, padding.left - 10, y + 4);
  }

  ctx.strokeStyle = '#5d0714';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, height - padding.bottom);
  ctx.lineTo(width - padding.right, height - padding.bottom);
  ctx.stroke();

  const points = chartValues.map((value, index) => ({
    x: padding.left + (chartValues.length === 1 ? chartWidth / 2 : (chartWidth / (chartValues.length - 1)) * index),
    y: padding.top + chartHeight - ((value - min) / range) * chartHeight,
    value
  }));

  ctx.beginPath();

  points.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });

  ctx.strokeStyle = '#a80f24';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke();

  points.forEach((point, index) => {
    ctx.beginPath();
    ctx.arc(point.x, point.y, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = index === points.length - 1 ? '#22b8b0' : '#e31837';
    ctx.fill();
  });

  if (hoverIndex >= 0 && points[hoverIndex]) {
    const point = points[hoverIndex];
    ctx.beginPath();
    ctx.arc(point.x, point.y, 8, 0, Math.PI * 2);
    ctx.strokeStyle = '#5d0714';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(point.x, point.y, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
  }

  labels.forEach((label, index) => {
    const x = padding.left + (labels.length === 1 ? chartWidth / 2 : (chartWidth / (labels.length - 1)) * index);
    ctx.fillStyle = '#735e64';
    ctx.font = '11px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(label, x, height - 28);
  });

  ctx.fillStyle = '#23191c';
  ctx.font = 'bold 14px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(title, padding.left, 24);

  canvas._chartState = {
    canvasId,
    values: chartValues,
    title,
    options: { ...options, hoverIndex: undefined },
    points,
    labels,
    valuePrefix,
    valueSuffix
  };

  if (!canvas.dataset.hoverBound) {
    canvas.dataset.hoverBound = 'true';
    canvas.addEventListener('mousemove', event => {
      const state = canvas._chartState;
      if (!state) return;

      const rect = canvas.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * canvas.width;
      const y = ((event.clientY - rect.top) / rect.height) * canvas.height;
      let closestIndex = -1;
      let closestDistance = Infinity;

      state.points.forEach((point, index) => {
        const distance = Math.hypot(point.x - x, point.y - y);
        if (distance < closestDistance) {
          closestDistance = distance;
          closestIndex = index;
        }
      });

      const tooltip = getChartTooltip();

      if (closestDistance <= 24 && closestIndex >= 0) {
        const value = state.values[closestIndex];
        const label = state.labels[closestIndex] || `P${closestIndex + 1}`;
        tooltip.innerHTML = `<strong>${state.valuePrefix}${value}${state.valueSuffix}</strong><span>${label}</span>`;
        tooltip.style.left = `${event.clientX + 14}px`;
        tooltip.style.top = `${event.clientY + 14}px`;
        tooltip.classList.remove('hidden');
        drawLineChart(state.canvasId, state.values, state.title, { ...state.options, hoverIndex: closestIndex });
      } else {
        tooltip.classList.add('hidden');
        drawLineChart(state.canvasId, state.values, state.title, state.options);
      }
    });

    canvas.addEventListener('mouseleave', () => {
      const state = canvas._chartState;
      getChartTooltip().classList.add('hidden');
      if (state) drawLineChart(state.canvasId, state.values, state.title, state.options);
    });
  }
}

function drawCustomerCharts() {
  const customer = selectedCustomer();

  drawLineChart('financialChart', customer.financials, 'Revenue trend: FY2023 to FY2026');
  drawLineChart('repaymentChart', customer.repayment, 'Repayment behaviour score: last 6 months');
}

function recentMonthLabels(count) {
  const now = new Date();
  return Array.from({ length: count }, (_, index) => {
    const date = new Date(now.getFullYear(), now.getMonth() - (count - 1 - index), 1);
    return date.toLocaleDateString('en-MY', { month: 'short' });
  });
}

function currentReportSeries(period = activeReportPeriod) {
  const now = new Date();
  const currentHour = now.getHours();
  const todaySlots = [
    { label: '9 AM', hour: 9, revenue: 0.08, deposits: 72.4 },
    { label: '12 PM', hour: 12, revenue: 0.16, deposits: 71.8 },
    { label: '3 PM', hour: 15, revenue: 0.29, deposits: 71.2 },
    { label: '6 PM', hour: 18, revenue: 0.42, deposits: 70.9 }
  ].filter(slot => slot.hour <= currentHour);

  const todaySeries = todaySlots.length ? todaySlots : [{
    label: now.toLocaleTimeString('en-MY', { hour: 'numeric' }),
    revenue: 0.03,
    deposits: 72.8
  }];

  const weekOfMonth = Math.max(1, Math.ceil(now.getDate() / 7));
  const mtdLabels = Array.from({ length: Math.min(5, weekOfMonth) }, (_, index) => `Week ${index + 1}`);
  const currentQuarter = Math.max(1, Math.floor(now.getMonth() / 3) + 1);

  const series = {
    today: {
      labels: todaySeries.map(slot => slot.label),
      revenue: todaySeries.map(slot => slot.revenue),
      deposits: todaySeries.map(slot => slot.deposits)
    },
    mtd: {
      labels: mtdLabels,
      revenue: [1.1, 2.4, 3.6, 4.8, 5.3].slice(0, mtdLabels.length),
      deposits: [73.8, 72.5, 71.6, 70.9, 70.5].slice(0, mtdLabels.length)
    },
    '3m': {
      labels: recentMonthLabels(3),
      revenue: [5.2, 6.1, 7.4],
      deposits: [76.4, 73.2, 70.9]
    },
    '6m': {
      labels: recentMonthLabels(6),
      revenue: [11.2, 12.8, 14.3, 15.7, 16.9, 18.7],
      deposits: [230, 225, 221, 218, 215, 212]
    },
    ytd: {
      labels: ['Q1', 'Q2', 'Q3', 'Q4'].slice(0, currentQuarter),
      revenue: [4.1, 8.9, 13.6, 18.7].slice(0, currentQuarter),
      deposits: [224, 218, 214, 212].slice(0, currentQuarter)
    }
  };

  return series[period] || series.ytd;
}

function updateReportTrendSummary(series) {
  const revenueValue = series.revenue[series.revenue.length - 1] || 0;
  const depositValue = series.deposits[series.deposits.length - 1] || 0;
  const periodName = periodLabel(activeReportPeriod);
  const now = new Date();
  const asOf = now.toLocaleString('en-MY', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });

  const revenueTarget = document.getElementById('revenueTrendValue');
  const depositTarget = document.getElementById('depositTrendValue');
  const asOfTarget = document.getElementById('reportTrendAsOf');

  if (revenueTarget) revenueTarget.textContent = `RM${revenueValue}m ${periodName} revenue`;
  if (depositTarget) depositTarget.textContent = `RM${depositValue}m ${periodName} deposits`;
  if (asOfTarget) asOfTarget.textContent = `As at ${asOf}`;
}

function drawReportCharts() {
  const series = currentReportSeries(activeReportPeriod);
  const periodName = activeReportPeriod.toUpperCase();

  updateReportTrendSummary(series);

  drawLineChart('revenueTrendChart', series.revenue, `Revenue trend: ${periodName}`, {
    labels: series.labels,
    valuePrefix: 'RM',
    valueSuffix: 'm'
  });
  drawLineChart('depositTrendChart', series.deposits, `Deposit trend: ${periodName}`, {
    labels: series.labels,
    valuePrefix: 'RM',
    valueSuffix: 'm'
  });
}

function buildSearchIndex() {
  const customerResults = customers.map(customer => ({
    title: customer.name,
    category: 'Customer',
    detail: `${customer.industry} · ${customer.segment} · Health ${customer.health}`,
    view: 'customer360View',
    customerId: customer.id,
    keywords: `${customer.name} ${customer.industry} ${customer.segment} ${customer.riskRating} ${customer.aiSignal}`
  }));

  const alertResults = alerts.map(([title, text, severity]) => ({
    title,
    category: 'Alert',
    detail: `${severity} · ${text}`,
    view: 'alertsView',
    keywords: `${title} ${text} ${severity}`
  }));

  const documentResults = documents.map(doc => ({
    title: doc[0],
    category: 'Document',
    detail: `${doc[1]} · ${doc[2]} · ${doc[3]}`,
    view: 'documentsView',
    keywords: doc.join(' ')
  }));

  const appointmentResults = relationshipAppointments.map(appointment => {
    const customer = customerById(appointment.customerId);
    return {
      title: appointment.title,
      category: 'Calendar',
      detail: `${appointment.type} / ${getCustomerShortName(customer)} / ${appointment.time} / Priority ${appointment.priority}`,
      view: 'dashboardView',
      keywords: `${appointment.title} ${appointment.type} ${appointment.time} ${appointment.priority} ${getCustomerShortName(customer)}`
    };
  });

  const creditResults = creditDeals.map(deal => ({
    title: `${deal.customer} - ${deal.product}`,
    category: 'Credit Pipeline',
    detail: `${deal.status} · ${deal.value} · ${deal.probability}% probability`,
    view: 'creditPipelineView',
    keywords: `${deal.customer} ${deal.product} ${deal.status} ${deal.value}`
  }));

  const salesResults = salesOpps.map(opp => ({
    title: `${opp.customer} - ${opp.product}`,
    category: 'Sales Opportunity',
    detail: `${opp.stage} · ${opp.value} · Revenue ${opp.revenue}`,
    view: 'salesPipelineView',
    keywords: `${opp.customer} ${opp.product} ${opp.stage} ${opp.value} ${opp.revenue}`
  }));

  return [
    ...customerResults,
    ...alertResults,
    ...documentResults,
    ...appointmentResults,
    ...creditResults,
    ...salesResults
  ];
}

function handleGlobalSearch() {
  const query = globalSearchInput.value.trim().toLowerCase();

  if (!query) {
    globalSearchResults.classList.add('hidden');
    return;
  }

  const results = buildSearchIndex()
    .filter(item => item.keywords.toLowerCase().includes(query))
    .slice(0, 8);

  if (!results.length) {
    globalSearchResults.innerHTML = `
      <div class="search-result">
        <strong>No results found</strong>
        <span>Try customer name, document type, alert, appointment or product.</span>
      </div>
    `;
    globalSearchResults.classList.remove('hidden');
    return;
  }

  globalSearchResults.innerHTML = results.map((item, index) => `
    <button class="search-result" data-result-index="${index}">
      <strong>${item.category}: ${item.title}</strong>
      <span>${item.detail}</span>
    </button>
  `).join('');

  globalSearchResults.dataset.results = JSON.stringify(results);
  globalSearchResults.classList.remove('hidden');
}

function addChatMessage(text, sender = 'bot') {
  const chatWindow = document.getElementById('chatWindow');
  const div = document.createElement('div');
  const welcome = document.getElementById('copilotWelcome');
  const timestamp = new Date().toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit' });

  div.className = `message ${sender}`;
  if (welcome) welcome.classList.add('hidden');

  if (sender === 'user') {
    div.innerHTML = `<div class="message-body">${text.replace(/\n/g, '<br>')}<time>${timestamp}</time></div>`;
  } else {
    div.innerHTML = `
      <div class="message-body">
        ${text.replace(/\n/g, '<br>')}
        <div class="ai-message-actions">
          <button type="button">Generate Pitch</button>
          <button type="button">Add to Pipeline</button>
          <button type="button">Schedule Follow-up</button>
          <button type="button">Export Summary</button>
          <button type="button">Save to Customer 360</button>
        </div>
        <time>${timestamp}</time>
      </div>
    `;
  }
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function copilotResponse(prompt) {
  const lower = prompt.toLowerCase();
  const customer = selectedCustomer();

  if (lower.includes('abc') || lower.includes('summarise') || lower.includes('summary')) {
    return `<strong>${customer.name} summary</strong>\n${customer.companyProfile}\n\nKey system observations:\n- ${customer.aiSummary.map(item => item[0]).join('\n- ')}`;
  }

  if (lower.includes('annual review')) {
    return `<strong>Annual review draft outline</strong>\n1. Relationship overview\n2. Facilities and utilization\n3. Financial performance and ratios\n4. Repayment conduct\n5. Collateral and covenant status\n6. AI risk summary\n7. Recommended approval / action.`;
  }

  if (lower.includes('cross')) {
    return `<strong>Cross-sell recommendations</strong>\nFor ${customer.name}: ${customer.opportunities.join(', ')}.\nPriority action: ${customer.nextAction}`;
  }

  if (lower.includes('risk')) {
    return `<strong>Risk explanation</strong>\nRisk movement is driven by: ${customer.aiSignal}. Early warning signals: ${customer.ews.join(', ')}.`;
  }

  if (lower.includes('credit memo')) {
    return `<strong>Credit memo starter</strong>\nCustomer: ${customer.name}\nExposure: ${customer.exposure}\nDeposits: ${customer.deposits}\nInternal Rating: ${customer.internalRating}\nRecommendation: Review facilities based on AI signal - ${customer.aiSignal}.`;
  }

  return `I can help summarise a customer, draft annual review, recommend cross-sell opportunities, explain risk changes or generate a credit memo. Current customer context: ${customer.name}.`;
}

function renderAll() {
  renderDashboard();
  renderPortfolio();
  renderCustomerSelectors();
  renderCustomer360();
  renderCreditPipeline();
  renderSalesPipeline();
  renderTasks();
  renderAlerts();
  renderNotifications();
  renderDashboardAnalytics();
}

async function runScan() {
  const steps = [
    'Ingesting customer, transaction, facility, deposit and document data...',
    'Scanning alerts: large withdrawal, overdue credit, expiring facilities and covenant status...',
    'Identifying cross-sell opportunities across working capital, trade, treasury and cash management...',
    'Re-ranking portfolio by risk, revenue potential and relationship health...',
    'Generating RM actions, risk observations and workflow support...'
  ];

  scanOverlay.classList.remove('hidden');
  progressBar.style.width = '0%';

  for (let i = 0; i < steps.length; i += 1) {
    scanText.textContent = steps[i];
    progressBar.style.width = `${((i + 1) / steps.length) * 100}%`;
    await new Promise(resolve => setTimeout(resolve, 520));
  }

  scanOverlay.classList.add('hidden');
  updateHeaderTime();
  showToast('Portfolio analysis completed. CIMBrain insights refreshed.');
}

function initEvents() {
  loginForm.addEventListener('submit', event => {
    event.preventDefault();

    currentUsername = nameFromEmail(document.getElementById('userId').value);

    loginScreen.classList.add('hidden');
    app.classList.remove('hidden');
    resetPageScroll();

    updateHeaderTime();
    showToast('Login successful. Dashboard loaded.');

    setTimeout(() => {
      drawCustomerCharts();
      drawReportCharts();
    }, 80);
  });

  logoutBtn.addEventListener('click', () => {
    app.classList.add('hidden');
    loginScreen.classList.remove('hidden');
  });

  const ssoButton = document.getElementById("ssoBtn");

  if (ssoButton) {
    ssoButton.addEventListener("click", () => {
      showToast("Corporate SSO authentication completed.");
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      if (item.dataset.view === 'customer360View') c360Mode = 'list';
      showView(item.dataset.view);
      renderCustomer360();
    });
  });

  navGroupToggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      toggle.closest('.nav-group').classList.toggle('collapsed');
    });
  });

  document.querySelectorAll('[data-dashboard-period]').forEach(button => {
    button.addEventListener('click', () => {
      activeDashboardPeriod = button.dataset.dashboardPeriod || 'today';
      activeReportPeriod = activeDashboardPeriod;
      document.querySelectorAll('[data-dashboard-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton === button);
      });
      document.querySelectorAll('[data-report-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton.dataset.reportPeriod === activeReportPeriod);
      });
      renderDashboard();
      renderReports();
    });
  });

  const detailModal = document.getElementById('detailModal');
  const detailModalClose = document.getElementById('detailModalClose');

  if (detailModalClose) {
    detailModalClose.addEventListener('click', closeDetailModal);
  }

  if (detailModal) {
    detailModal.addEventListener('click', event => {
      if (event.target === detailModal) closeDetailModal();
    });
  }

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeDetailModal();
  });

  document.body.addEventListener('click', event => {
    const priorityTarget = event.target.closest('[data-priority-index]');

    if (priorityTarget) {
      openPriorityDetail(Number(priorityTarget.dataset.priorityIndex));
      return;
    }

    const marketTarget = event.target.closest('[data-market-index]');

    if (marketTarget) {
      openMarketDetail(Number(marketTarget.dataset.marketIndex));
      return;
    }

    const targetButton = event.target.closest('[data-view-target]');

    if (targetButton) {
      if (targetButton.dataset.viewTarget === 'customer360View') c360Mode = 'list';
      showView(targetButton.dataset.viewTarget);
      if (targetButton.dataset.viewTarget === 'customer360View') renderCustomer360();
      return;
    }

    const customerTarget = event.target.closest('[data-customer-id]');

    if (customerTarget && customerTarget.dataset.customerId) {
      openCustomer(customerTarget.dataset.customerId);
    }
  });

  document.addEventListener('click', event => {
    if (!event.target.closest('.global-search')) {
      globalSearchResults.classList.add('hidden');
    }

    if (!event.target.closest('.notification-wrap')) {
      notificationPanel.classList.add('hidden');
    }
  });

  globalSearchInput.addEventListener('input', handleGlobalSearch);

  globalSearchResults.addEventListener('click', event => {
    const button = event.target.closest('.search-result');
    if (!button || button.dataset.resultIndex === undefined) return;

    const results = JSON.parse(globalSearchResults.dataset.results || '[]');
    const selected = results[Number(button.dataset.resultIndex)];
    if (!selected) return;

    if (selected.customerId) {
      openCustomer(selected.customerId);
    } else {
      showView(selected.view);
    }

    globalSearchInput.value = '';
    globalSearchResults.classList.add('hidden');
  });

  notificationBtn.addEventListener('click', event => {
    event.stopPropagation();
    notificationPanel.classList.toggle('hidden');
  });

  notificationList.addEventListener('click', event => {
    const item = event.target.closest('[data-notification-view]');
    if (!item) return;
    notificationPanel.classList.add('hidden');
    if (item.dataset.notificationCustomer) {
      openCustomer(item.dataset.notificationCustomer);
    } else {
      showView(item.dataset.notificationView);
    }
  });

  clearNotificationsBtn.addEventListener('click', event => {
    event.stopPropagation();
    alerts = [];
    renderAlerts();
    renderNotifications();
    notificationPanel.classList.add('hidden');
    showToast('Notifications cleared for demo purposes.');
  });

  ['customerSearch', 'segmentFilter', 'industryFilter'].forEach(id => {
    document.getElementById(id).addEventListener('input', renderPortfolio);
  });

  const customerSelect = document.getElementById("customerSelect");

  if (customerSelect) {
    customerSelect.addEventListener("change", event => {
      selectedCustomerId = event.target.value;
      renderAll();
      drawCustomerCharts();
    });
  }

  document.getElementById('runScanBtn').addEventListener('click', runScan);

  document.getElementById('generateBriefBtn').addEventListener('click', () => {
    const customer = selectedCustomer();
    showToast(`Meeting brief generated for ${customer.name}. Open AI Copilot for draft output.`);
    showView('copilotView');
    addChatMessage(copilotResponse(`Summarise ${customer.name}`));
  });

  document.getElementById('markAlertsBtn').addEventListener('click', () => {
    showToast('Alerts marked as reviewed for demo purposes.');
  });

  document.querySelectorAll('.quick-prompts button').forEach(button => {
    button.addEventListener('click', () => {
      const prompt = button.dataset.prompt;
      addChatMessage(prompt, 'user');
      setTimeout(() => addChatMessage(copilotResponse(prompt)), 250);
    });
  });

  document.getElementById('chatForm').addEventListener('submit', event => {
    event.preventDefault();

    const input = document.getElementById('chatInput');
    const prompt = input.value.trim();

    if (!prompt) return;

    addChatMessage(prompt, 'user');
    input.value = '';

    setTimeout(() => addChatMessage(copilotResponse(prompt)), 250);
  });

  window.addEventListener('resize', () => {
    drawCustomerCharts();
    drawReportCharts();
  });

  const newCustomerBtn = document.getElementById("newCustomerBtn");

  if (newCustomerBtn) {
    newCustomerBtn.addEventListener("click", () => {
      showToast("New customer onboarding form opened for demo.");
    });
  }

  const sideCopilotBtn = document.getElementById("sideCopilotBtn");

  if (sideCopilotBtn) {
    sideCopilotBtn.addEventListener("click", () => {
      showView("copilotView");
    });
  }

  const quickActionsBtn = document.getElementById("quickActionsBtn");
  const quickActionsPanel = document.getElementById("quickActionsPanel");

  if (quickActionsBtn && quickActionsPanel) {
    quickActionsBtn.addEventListener("click", event => {
      event.stopPropagation();
      quickActionsPanel.classList.toggle("hidden");
    });

    quickActionsPanel.addEventListener("click", event => {
      const actionButton = event.target.closest("button");

      if (!actionButton) return;

      handleQuickAction(actionButton.dataset.action);
      quickActionsPanel.classList.add("hidden");
    });
  }

  document.addEventListener("click", event => {
    if (!event.target.closest(".global-search")) {
      globalSearchResults.classList.add("hidden");
    }

    if (!event.target.closest(".notification-wrap")) {
      notificationPanel.classList.add("hidden");
    }

    if (!event.target.closest(".quick-actions-wrap")) {
      const quickActionsPanel = document.getElementById("quickActionsPanel");
      if (quickActionsPanel) quickActionsPanel.classList.add("hidden");
    }
  });

  const topTasksBtn = document.getElementById("topTasksBtn");
  const topAlertsBtn = document.getElementById("topAlertsBtn");

  if (topTasksBtn) {
    topTasksBtn.addEventListener("click", () => {
      showView("calendarView");
      renderTasks();
    });
  }

  if (topAlertsBtn) {
    topAlertsBtn.addEventListener("click", () => {
      showView("alertsView");
    });
  }

    rotateSearchPlaceholder();
}

/* ================================
   REFINEMENT PASS OVERRIDES
================================ */

let activeCustomer360Period = 'today';
let activeReportPeriod = 'today';
let activeCalendarView = 'week';
let c360Mode = 'list';

if (!customers.some(customer => customer.id === 'pqr')) {
  customers.push(
    {
      id: 'pqr',
      name: 'PQR Logistics Sdn. Bhd.',
      brn: '201601778899',
      segment: 'Commercial',
      industry: 'Logistics',
      relationshipValue: 'Medium',
      riskRating: 'Watchlist / Moderate',
      revenue: 'RM 64m',
      revenueValue: 64,
      ebitda: 'RM 7.4m',
      exposure: 'RM 14.6m',
      exposureValue: 14.6,
      deposits: 'RM 5.7m',
      depositValue: 5.7,
      lastContact: '3 days ago',
      health: 79,
      status: 'Monitor',
      companyProfile: 'Fleet and warehousing operator serving domestic manufacturing customers.',
      groupStructure: 'Operating company with 2 fleet subsidiaries.',
      ubo: 'Wong Chee Meng, 58% direct ownership',
      rm: 'Qian Tong, Commercial RM',
      onboarding: 'Completed / Insurance schedules due Aug 2026',
      internalRating: 'CRR 5 - Acceptable',
      products: [
        ['Facilities', 'RM14.6m approved; RM9.2m utilized'],
        ['Deposits', 'RM5.7m average balance'],
        ['CASA', 'Payroll and operating account active'],
        ['Trade Finance', 'Limited'],
        ['Treasury', 'Not active'],
        ['Asset Finance', 'Fleet HP facility']
      ],
      financials: [51, 56, 60, 64],
      repayment: [94, 93, 95, 94, 92, 93],
      ratios: [['Current Ratio', '1.21x'], ['Debt / EBITDA', '2.9x'], ['DSCR', '1.18x'], ['Gross Margin', '18%']],
      creditInfo: [
        ['Credit Limits', 'RM14.6m approved limit'],
        ['Utilisation', '63% current utilization'],
        ['Collateral', 'Vehicle debenture and insurance assignment'],
        ['Repayment History', 'Minor delays during fleet replacement cycle']
      ],
      aiSummary: [
        ['Fleet replacement cycle approaching', 'Several vehicles are due for replacement within 9 months.'],
        ['Operating balances stable', 'Payroll and customer collection flows remain active.'],
        ['Insurance document follow-up needed', 'Updated insurance schedules are pending.'],
        ['Cash management opportunity', 'Multiple collection accounts can be consolidated.']
      ],
      nextAction: 'Review fleet financing and cash management structure.',
      aiSignal: 'Fleet renewal cycle + fragmented collections',
      ews: ['Insurance schedule pending', 'Fleet replacement funding need'],
      churn: 'Low',
      opportunities: ['Asset Finance', 'Cash Management', 'Payroll']
    },
    {
      id: 'stu',
      name: 'STU Packaging Sdn. Bhd.',
      brn: '201301445566',
      segment: 'SME Commercial',
      industry: 'Packaging',
      relationshipValue: 'Medium',
      riskRating: 'Good / Stable',
      revenue: 'RM 46m',
      revenueValue: 46,
      ebitda: 'RM 5.9m',
      exposure: 'RM 8.8m',
      exposureValue: 8.8,
      deposits: 'RM 4.4m',
      depositValue: 4.4,
      lastContact: '1 week ago',
      health: 83,
      status: 'Healthy',
      companyProfile: 'Packaging supplier to food and consumer goods manufacturers.',
      groupStructure: 'Single operating entity with related trading company.',
      ubo: 'Koh Siew Lan, 64% direct ownership',
      rm: 'Qian Tong, SME Commercial RM',
      onboarding: 'Completed / KYC refreshed Jun 2026',
      internalRating: 'CRR 4 - Acceptable',
      products: [
        ['Facilities', 'RM8.8m approved; RM4.5m utilized'],
        ['Deposits', 'RM4.4m average balance'],
        ['CASA', 'Operating account active'],
        ['Trade Finance', 'Supplier payments via TT'],
        ['Treasury', 'Not active'],
        ['FX', 'Recurring USD raw material payments']
      ],
      financials: [38, 41, 44, 46],
      repayment: [98, 97, 98, 97, 98, 98],
      ratios: [['Current Ratio', '1.49x'], ['Debt / EBITDA', '1.7x'], ['DSCR', '1.44x'], ['Gross Margin', '21%']],
      creditInfo: [
        ['Credit Limits', 'RM8.8m approved limit'],
        ['Utilisation', '51% current utilization'],
        ['Collateral', 'Debenture + director guarantee'],
        ['Repayment History', 'Clean repayment record']
      ],
      aiSummary: [
        ['Stable repayment conduct', 'No overdue repayments or covenant issues detected.'],
        ['FX need emerging', 'Raw material purchases show recurring USD payments.'],
        ['Trade line renewal due', 'Existing trade line should be renewed before supplier peak.'],
        ['Deposit retention opportunity', 'Operating balances can be linked to cash management.']
      ],
      nextAction: 'Prepare trade line renewal and FX discussion.',
      aiSignal: 'USD supplier payments + trade renewal window',
      ews: ['Trade line renewal due'],
      churn: 'Low',
      opportunities: ['Trade Finance', 'Treasury FX', 'Cash Management']
    },
    {
      id: 'vwx',
      name: 'VWX Healthcare Supplies Sdn. Bhd.',
      brn: '201901223344',
      segment: 'Commercial',
      industry: 'Healthcare Supplies',
      relationshipValue: 'High',
      riskRating: 'Watchlist / Moderate',
      revenue: 'RM 118m',
      revenueValue: 118,
      ebitda: 'RM 12.2m',
      exposure: 'RM 22.4m',
      exposureValue: 22.4,
      deposits: 'RM 9.1m',
      depositValue: 9.1,
      lastContact: 'Yesterday',
      health: 68,
      status: 'Monitor',
      companyProfile: 'Distributor of medical consumables with hospital receivables concentration.',
      groupStructure: 'Holding company with 1 procurement subsidiary.',
      ubo: 'Dr. Azman Rahim, 52% effective ownership',
      rm: 'Qian Tong, Commercial RM',
      onboarding: 'Completed / Public-sector receivable documents pending',
      internalRating: 'CRR 6 - Monitor',
      products: [
        ['Facilities', 'RM22.4m approved; RM18.1m utilized'],
        ['Deposits', 'RM9.1m average balance'],
        ['CASA', 'Collection account active'],
        ['Trade Finance', 'Import LC active'],
        ['Treasury', 'Low penetration'],
        ['Receivables', 'Invoice financing suitable']
      ],
      financials: [91, 104, 112, 118],
      repayment: [96, 95, 93, 94, 92, 91],
      ratios: [['Current Ratio', '1.16x'], ['Debt / EBITDA', '3.1x'], ['DSCR', '1.11x'], ['Gross Margin', '15%']],
      creditInfo: [
        ['Credit Limits', 'RM22.4m approved limit'],
        ['Utilisation', '81% current utilization'],
        ['Collateral', 'Receivables assignment + debenture'],
        ['Repayment History', 'Collections occasionally delayed']
      ],
      aiSummary: [
        ['Receivables cycle lengthening', 'Hospital collections are taking longer than previous quarter.'],
        ['Invoice financing opportunity', 'Eligible invoices can reduce working-capital pressure.'],
        ['Utilisation above comfort range', 'Facility usage is above 80%.'],
        ['Document follow-up required', 'Public-sector receivable ageing is pending.']
      ],
      nextAction: 'Request receivable ageing and propose invoice financing.',
      aiSignal: 'Receivable ageing + high utilisation',
      ews: ['Receivable ageing pending', 'Utilisation above 80%'],
      churn: 'Medium',
      opportunities: ['Invoice Financing', 'Trade Finance', 'Cash Management']
    },
    {
      id: 'yza',
      name: 'YZA Engineering Sdn. Bhd.',
      brn: '200801556677',
      segment: 'Commercial',
      industry: 'Engineering Services',
      relationshipValue: 'Medium',
      riskRating: 'High Risk',
      revenue: 'RM 54m',
      revenueValue: 54,
      ebitda: 'RM 3.8m',
      exposure: 'RM 18.7m',
      exposureValue: 18.7,
      deposits: 'RM 2.8m',
      depositValue: 2.8,
      lastContact: '18 days ago',
      health: 57,
      status: 'At Risk',
      companyProfile: 'Engineering contractor exposed to project certification and collection delays.',
      groupStructure: 'Operating company with 3 project joint ventures.',
      ubo: 'Leong Kai Jun, 49% direct ownership',
      rm: 'Qian Tong, Commercial RM',
      onboarding: 'Completed / Covenant review due',
      internalRating: 'CRR 7 - Watchlist',
      products: [
        ['Facilities', 'RM18.7m approved; RM16.9m utilized'],
        ['Deposits', 'RM2.8m average balance'],
        ['CASA', 'Project operating accounts'],
        ['Trade Finance', 'Performance guarantees active'],
        ['Treasury', 'Not active'],
        ['FX', 'Not active']
      ],
      financials: [62, 59, 56, 54],
      repayment: [91, 88, 86, 84, 82, 80],
      ratios: [['Current Ratio', '0.98x'], ['Debt / EBITDA', '4.4x'], ['DSCR', '0.96x'], ['Gross Margin', '10%']],
      creditInfo: [
        ['Credit Limits', 'RM18.7m approved limit'],
        ['Utilisation', '90% current utilization'],
        ['Collateral', 'Project proceeds assignment + guarantee'],
        ['Repayment History', 'Several late settlements detected']
      ],
      aiSummary: [
        ['Covenant watch required', 'DSCR is close to internal breach level.'],
        ['Project claims delayed', 'Collections are behind planned certification dates.'],
        ['Deposit balances declining', 'Operating balances have dropped for 3 consecutive months.'],
        ['Credit review needed', 'High utilisation and repayment slippage require RM validation.']
      ],
      nextAction: 'Schedule credit review and validate project claim status.',
      aiSignal: 'Project collection delay + high utilisation',
      ews: ['Covenant watch', 'Late settlements', 'Declining deposits'],
      churn: 'High',
      opportunities: ['Restructuring Review', 'Guarantee Review']
    },
    {
      id: 'bcd',
      name: 'BCD Agro Trading Sdn. Bhd.',
      brn: '201501334455',
      segment: 'SME Commercial',
      industry: 'Agro Trading',
      relationshipValue: 'Medium',
      riskRating: 'Watchlist / Moderate',
      revenue: 'RM 39m',
      revenueValue: 39,
      ebitda: 'RM 4.3m',
      exposure: 'RM 7.6m',
      exposureValue: 7.6,
      deposits: 'RM 3.6m',
      depositValue: 3.6,
      lastContact: '6 days ago',
      health: 75,
      status: 'Monitor',
      companyProfile: 'Agro commodities trader with seasonal inventory and supplier concentration.',
      groupStructure: 'Family-owned trading entity with related plantation supplier.',
      ubo: 'Cheah Family Trust, 61% effective ownership',
      rm: 'Qian Tong, SME Commercial RM',
      onboarding: 'Completed / Supplier concentration note required',
      internalRating: 'CRR 6 - Monitor',
      products: [
        ['Facilities', 'RM7.6m approved; RM5.9m utilized'],
        ['Deposits', 'RM3.6m average balance'],
        ['CASA', 'Operating account active'],
        ['Trade Finance', 'Supplier payment support'],
        ['Treasury', 'Not active'],
        ['FX', 'Occasional USD payments']
      ],
      financials: [35, 37, 38, 39],
      repayment: [95, 94, 93, 94, 92, 93],
      ratios: [['Current Ratio', '1.12x'], ['Debt / EBITDA', '2.7x'], ['DSCR', '1.14x'], ['Gross Margin', '14%']],
      creditInfo: [
        ['Credit Limits', 'RM7.6m approved limit'],
        ['Utilisation', '78% current utilization'],
        ['Collateral', 'Inventory assignment + guarantee'],
        ['Repayment History', 'Acceptable with seasonal pressure']
      ],
      aiSummary: [
        ['Seasonal inventory need detected', 'Purchasing cycle will peak over the next 45 days.'],
        ['Supplier concentration noted', 'Payments are concentrated to two main suppliers.'],
        ['Trade support opportunity', 'Structured supplier payment support may reduce pressure.'],
        ['Monitor margin movement', 'Commodity price changes may affect gross margin.']
      ],
      nextAction: 'Discuss seasonal trade financing before inventory peak.',
      aiSignal: 'Seasonal inventory cycle + supplier concentration',
      ews: ['Supplier concentration', 'Seasonal utilisation pressure'],
      churn: 'Medium',
      opportunities: ['Trade Finance', 'Working Capital', 'Cash Management']
    }
  );
}

const periodNames = {
  today: 'Today',
  mtd: 'MTD',
  ytd: 'YTD',
  '3m': '3M',
  '6m': '6M',
  last6: 'Last 6 Months',
  last3y: 'Last 3 Years'
};

const customerIdentifiers = {
  abc: '202001234567',
  def: '201701998877',
  ghi: '199801112233',
  jkl: '201403456789',
  mno: '200901765432',
  pqr: '201601778899',
  stu: '201301445566',
  vwx: '201901223344',
  yza: '200801556677',
  bcd: '201501334455'
};

customers.forEach(customer => {
  customer.brn = customerIdentifiers[customer.id] || 'N/A';
});

dashboardPeriodMetrics.today.kpis.totalCustomers = [String(customers.length), 'Customers in active portfolio', '+2 reviewed today', 'trend-up'];
dashboardPeriodMetrics.mtd.kpis.totalCustomers = [String(customers.length), 'Customers in active portfolio', `${customers.length} reviewed MTD`, 'trend-up'];
dashboardPeriodMetrics.ytd.kpis.totalCustomers = [String(customers.length), 'Customers in active portfolio', '+1 net new YTD', 'trend-up'];

Object.assign(marketSignals[0], {
  icon: 'FP',
  summary: 'Palm-based input costs are a live watch item for food manufacturers. The practical RM concern is not the headline price alone, but whether higher purchase costs are being passed through fast enough to protect margin.',
  clients: 'JKL Food Processing',
  clientIds: ['jkl'],
  impact: 'If raw material purchases remain elevated while selling prices lag, JKL may draw more heavily on working-capital lines and delay supplier payments.',
  actions: ['Review current purchase orders and inventory days', 'Check whether JKL has passed cost increases to key buyers', 'Reconfirm working-capital headroom before the next annual review']
});

Object.assign(marketSignals[1], {
  icon: 'FX',
  summary: 'Currency movement is relevant for exporters and importers, but the action should be based on actual receivable and payable timing rather than a generic FX view.',
  clients: 'GHI Exporters, ABC Manufacturing',
  clientIds: ['ghi', 'abc'],
  impact: 'GHI has USD receivables while ABC has recurring USD supplier payments, so both need different hedging conversations.',
  actions: ['Map the next 90 days of USD inflows and outflows', 'Prepare simple hedge scenarios for CFO discussion', 'Link the client to Treasury only after exposure timing is confirmed']
});

Object.assign(marketSignals[2], {
  icon: 'CT',
  summary: 'Construction borrowers are sensitive to material, labour and collection delays. The key credit question is whether project claims are being certified and paid on schedule.',
  clients: 'MNO Construction',
  clientIds: ['mno'],
  impact: 'Margin pressure or slow project collections could worsen MNO repayment capacity and increase covenant pressure.',
  actions: ['Request latest project progress and claim schedule', 'Check overdue repayment status before renewal', 'Arrange site visit with credit notes prepared']
});

Object.assign(marketSignals[3], {
  icon: 'RT',
  summary: 'Retail recovery can be uneven across categories. For a trading client, the RM should watch inventory build-up, merchant settlement flows and campaign-driven cash needs.',
  clients: 'DEF Retail Trading',
  clientIds: ['def'],
  impact: 'DEF may require temporary inventory support before campaigns, but higher stock levels can also increase repayment risk if sell-through slows.',
  actions: ['Review inventory ageing and merchant settlement trend', 'Assess short-term financing before campaign peak', 'Set a post-campaign repayment check-in']
});

Object.assign(marketSignals[4], {
  icon: 'TF',
  summary: 'Shipment delays mainly affect cash conversion timing. The risk is longer stock holding and delayed customer collection rather than a one-off logistics issue.',
  clients: 'ABC Manufacturing, GHI Exporters',
  clientIds: ['abc', 'ghi'],
  impact: 'Import-heavy or export-heavy clients may need extra working-capital buffer if delivery and collection cycles stretch.',
  actions: ['Check open import LC and export bill maturities', 'Review whether receivables financing is suitable', 'Flag delayed shipments in next credit update']
});

if (!creditDeals.some(deal => deal.customer === 'PQR Logistics')) {
  creditDeals.push(
    { status: 'Draft', customer: 'PQR Logistics', product: 'Fleet HP Facility', value: 'RM 6.2m', date: '20 Jul 2026', probability: 32 },
    { status: 'Submitted', customer: 'STU Packaging', product: 'Trade Line Renewal', value: 'RM 4.8m', date: '24 Jul 2026', probability: 54 },
    { status: 'Credit Review', customer: 'VWX Healthcare Supplies', product: 'Invoice Financing', value: 'RM 9.0m', date: '29 Jul 2026', probability: 72 },
    { status: 'Additional Information Required', customer: 'YZA Engineering', product: 'Term Loan', value: 'RM 11.5m', date: '31 Jul 2026', probability: 47 },
    { status: 'Approved', customer: 'DEF Retail Trading', product: 'Inventory Facility', value: 'RM 2.8m', date: '08 Jul 2026', probability: 88 },
    { status: 'Disbursed', customer: 'JKL Food Processing', product: 'Working Capital Renewal', value: 'RM 4.0m', date: '03 Jul 2026', probability: 100 }
  );
}

if (!salesOpps.some(opp => opp.customer === 'PQR Logistics')) {
  salesOpps.push(
    { stage: 'Prospect', customer: 'PQR Logistics', product: 'Cash Management', value: 'RM 65k', revenue: 'RM 18k', probability: 22 },
    { stage: 'Qualified', customer: 'STU Packaging', product: 'Trade Finance', value: 'RM 140k', revenue: 'RM 42k', probability: 48 },
    { stage: 'Proposal', customer: 'VWX Healthcare Supplies', product: 'Payroll + CASA', value: 'RM 95k', revenue: 'RM 28k', probability: 61 },
    { stage: 'Negotiation', customer: 'DEF Retail Trading', product: 'Merchant Settlement', value: 'RM 110k', revenue: 'RM 35k', probability: 74 }
  );
}

if (!tasks.some(task => task[1] === 'Review DEF campaign cash-flow forecast')) {
  tasks.push(
    ['Review', 'Review DEF campaign cash-flow forecast', 'Today, 4:15 PM', 'Medium'],
    ['Check-in', 'ABC Manufacturing supplier payment follow-up', 'Today, 5:00 PM', 'Low'],
    ['Preparation', 'Prepare GHI receivables discussion note', 'Tomorrow, 9:00 AM', 'Medium']
  );
}

function periodLabel(value) {
  return periodNames[value] || 'Today';
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function probabilityClass(probability) {
  if (probability >= 80) return 'prob-high';
  if (probability >= 50) return 'prob-medium';
  return 'prob-low';
}

function meetingSuccessClass(success) {
  if (success >= 80) return 'success-high';
  if (success >= 50) return 'success-medium';
  return 'success-low';
}

function confidenceClass(customer) {
  if (customer.health >= 80) return 'good';
  if (customer.health >= 60) return 'warn';
  return 'risk';
}

function getCustomerByNameFragment(value) {
  const clean = value.toLowerCase();
  return customers.find(customer =>
    customer.name.toLowerCase().includes(clean) ||
    getCustomerShortName(customer).toLowerCase().includes(clean)
  );
}

function renderCustomerLinks(ids) {
  return (ids || [])
    .map(id => {
      const customer = customers.find(item => item.id === id);
      if (!customer) return '';
      return `<button type="button" class="inline-customer-link" data-customer-id="${customer.id}">${getCustomerShortName(customer)}</button>`;
    })
    .join('');
}

function companyInitials(customer) {
  return getCustomerShortName(customer)
    .replace(/[^a-zA-Z ]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(word => word.charAt(0))
    .join('')
    .toUpperCase();
}

function renderCustomerLogoStack(ids) {
  return `
    <div class="client-logo-stack">
      ${(ids || []).map(id => {
        const customer = customers.find(item => item.id === id);
        if (!customer) return '';
        return `
          <button type="button" class="client-logo-chip" data-customer-id="${customer.id}" title="${customer.name}" aria-label="Open ${customer.name}">
            <span>${companyInitials(customer)}</span>
          </button>
        `;
      }).join('')}
    </div>
  `;
}

function renderDashboardKpis() {
  const { kpis } = getActiveDashboardMetrics();

  setDashboardKpi('Total Customers', kpis.totalCustomers);
  setDashboardKpi('Total Credit Exposure', kpis.creditExposure);
  setDashboardKpi('Deposit Balance', kpis.depositBalance);
  setDashboardKpi('Portfolio Health', kpis.portfolioHealth);
  setDashboardKpi('Revenue Contribution', kpis.revenueContribution);

  const label = document.getElementById('dashboardViewLabel');
  if (label) {
    label.querySelector('strong').textContent = periodLabel(activeDashboardPeriod);
  }
}

function renderDashboard() {
  const getRiskBadge = customer => {
    if (customer.health >= 80) return `<span class="risk-dot-badge good">Healthy</span>`;
    if (customer.health >= 60) return `<span class="risk-dot-badge warn">Watchlist</span>`;
    return `<span class="risk-dot-badge risk">High Risk</span>`;
  };

  const rows = [...customers]
    .sort((a, b) => a.health - b.health)
    .map(customer => `
      <tr data-customer-id="${customer.id}">
        <td>
          <button class="customer-button" data-customer-id="${customer.id}">
            <div class="customer-name-block">
              <strong>${customer.name}</strong>
              <small>BRN ${customer.brn} · ${customer.industry}</small>
            </div>
          </button>
        </td>
        <td>${customer.exposure}</td>
        <td>${getRiskBadge(customer)}</td>
        <td>
          <div class="next-action-clean">
            <strong>${customer.nextAction}</strong>
            <span class="ai-confidence-subtle ${confidenceClass(customer)}">AI Confidence ${customer.health >= 80 ? '94' : customer.health >= 60 ? '76' : '58'}%</span>
          </div>
        </td>
      </tr>
    `)
    .join('');

  document.getElementById('dashboardCustomerRows').innerHTML = rows;

  renderDashboardKpis();
  renderDashboardPriorities();
  renderMarketSignals();
  renderDashboardMeetings();
  renderDashboardAnalytics();
}

function renderMarketSignals() {
  const target = document.getElementById('recentActivities');
  if (!target) return;

  target.innerHTML = marketSignals
    .map((item, index) => `
      <div class="market-signal-item">
        <div class="market-signal-industry">
          <span class="market-signal-icon">${item.icon}</span>
          <span>${item.industry}</span>
        </div>
        <div class="market-signal-body">
          <strong>${item.title}</strong>
          <p>${item.text}</p>
        </div>
        <div class="market-signal-actions">
          <button type="button" class="market-detail-btn" data-market-index="${index}">Details</button>
          <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="market-source-link">Source</a>
        </div>
      </div>
    `)
    .join('');
}

function openMarketDetail(index) {
  const item = marketSignals[index];
  if (!item) return;

  openDetailModal({
    kicker: 'Market Intelligence',
    title: item.title,
    body: `
      <section class="detail-section">
        <strong>Simple summary</strong>
        <p>${item.summary}</p>
      </section>
      <section class="detail-section">
        <strong>Clients affected</strong>
        <div class="linked-client-list">${renderCustomerLinks(item.clientIds)}</div>
      </section>
      <section class="detail-section">
        <strong>How it impacts client</strong>
        <p>${item.impact}</p>
      </section>
      <section class="detail-section">
        <strong>Recommended actions</strong>
        ${renderDetailList(item.actions)}
      </section>
    `
  });
}

function renderDashboardMeetings() {
  const target = document.getElementById('dashboardMeetings');
  if (!target) return;

  const meetings = [
    { ...upcomingMeetings[0], time: 'Today - 10:30 AM', success: 91 },
    { ...upcomingMeetings[1], time: 'Tomorrow - 3:00 PM', success: 72 }
  ];

  target.innerHTML = meetings
    .map(meeting => `
      <div class="clean-meeting-card dashboard-meeting-card ${meetingSuccessClass(meeting.success)}">
        <div class="meeting-success-bubble">
          <strong>${meeting.success}%</strong>
          <span>Success</span>
        </div>
        <div class="meeting-card-top">
          <div>
            <small>${meeting.time}</small>
            <h4>${meeting.customer}</h4>
          </div>
        </div>
        <div class="meeting-success-progress" aria-label="Estimated success ${meeting.success}%">
          <div style="width:${meeting.success}%"></div>
        </div>
        <div class="meeting-stats">
          <div>
            <span>Relationship Value</span>
            <strong>${meeting.relationshipValue}</strong>
          </div>
          <div>
            <span>Recommended Focus</span>
            <strong>${meeting.focus}</strong>
          </div>
        </div>
        <div class="meeting-topic-tags">
          ${meeting.tags.map(tag => `<span>${tag}</span>`).join('')}
        </div>
        <p>${meeting.note}</p>
      </div>
    `)
    .join('');
}

let navigationTimer = null;

function setNavigationLoading(isLoading, viewId = 'dashboardView') {
  const overlay = document.getElementById('navigationOverlay');
  const title = document.getElementById('navigationOverlayTitle');
  if (!overlay) return;

  if (title) {
    const meta = pageMeta[viewId] || pageMeta.dashboardView;
    title.textContent = `Loading ${meta[0]}`;
  }

  overlay.classList.toggle('hidden', !isLoading);
}

function resetPageScroll() {
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  const main = document.querySelector('.main');
  if (main) main.scrollTop = 0;
}

function applyView(viewId) {
  views.forEach(view => view.classList.toggle('active', view.id === viewId));
  navItems.forEach(item => item.classList.toggle('active', item.dataset.view === viewId));

  const meta = pageMeta[viewId] || pageMeta.dashboardView;

  pageTitle.textContent = meta[0];
  pageSubtitle.textContent = meta[1];

  const dashboardPeriodSwitch = document.querySelector('.dashboard-period-switch');
  const dashboardViewLabel = document.getElementById('dashboardViewLabel');
  if (dashboardPeriodSwitch) dashboardPeriodSwitch.classList.toggle('hidden', viewId !== 'dashboardView');
  if (dashboardViewLabel) dashboardViewLabel.classList.toggle('hidden', viewId !== 'dashboardView');

  if (viewId === 'customer360View') setTimeout(drawCustomerCharts, 80);
  if (viewId === 'reportsView') setTimeout(drawReportCharts, 80);

  globalSearchResults.classList.add('hidden');
  resetPageScroll();
}

function showView(viewId, options = {}) {
  const activeView = document.querySelector('.view.active');
  const shouldDelay = !options.skipDelay && app && !app.classList.contains('hidden') && activeView && activeView.id !== viewId;

  clearTimeout(navigationTimer);

  if (!shouldDelay) {
    setNavigationLoading(false, viewId);
    applyView(viewId);
    return;
  }

  setNavigationLoading(true, viewId);
  navigationTimer = setTimeout(() => {
    applyView(viewId);
    setNavigationLoading(false, viewId);
  }, 1200);
}

function renderCustomerSelectors() {
  const input = document.getElementById('customer360Search');
  const query = input ? input.value.trim().toLowerCase() : '';
  let filtered = customers.filter(customer => {
    const haystack = `${customer.name} ${customer.brn} ${customer.industry} ${customer.segment} ${customer.rm}`.toLowerCase();
    return !query || haystack.includes(query);
  });

  if (!filtered.some(customer => customer.id === selectedCustomerId)) {
    filtered = [selectedCustomer(), ...filtered];
  }

  const options = filtered
    .map(customer => `<option value="${customer.id}">${customer.name} · BRN ${customer.brn}</option>`)
    .join('');

  const customerSelect = document.getElementById('customerSelect');
  if (customerSelect) {
    customerSelect.innerHTML = options;
    customerSelect.value = selectedCustomerId;
  }
}

function customerRiskTier(customer) {
  if (customer.health >= 80) return 'Healthy';
  if (customer.health >= 60) return 'Watchlist';
  return 'High Risk';
}

function populateSelectOptions(select, values, allLabel) {
  if (!select) return;

  const currentValue = select.value || 'All';
  select.innerHTML = [
    `<option value="All">${allLabel}</option>`,
    ...values.map(value => `<option value="${value}">${value}</option>`)
  ].join('');
  select.value = values.includes(currentValue) ? currentValue : 'All';
}

function renderCustomerSelectors() {
  const input = document.getElementById('customer360Search');
  const industrySelect = document.getElementById('c360IndustryFilter');
  const riskSelect = document.getElementById('c360RiskFilter');
  const productSelect = document.getElementById('c360ProductFilter');

  populateSelectOptions(
    industrySelect,
    [...new Set(customers.map(customer => customer.industry))].sort(),
    'All industries'
  );
  populateSelectOptions(riskSelect, ['Healthy', 'Watchlist', 'High Risk'], 'All risk tiers');
  populateSelectOptions(
    productSelect,
    [...new Set(customers.flatMap(customer => customer.products.map(([product]) => product)))].sort(),
    'All products'
  );

  const query = input ? input.value.trim().toLowerCase() : '';
  const industryValue = industrySelect?.value || 'All';
  const riskValue = riskSelect?.value || 'All';
  const productValue = productSelect?.value || 'All';

  let filtered = customers.filter(customer => {
    const haystack = `${customer.name} ${customer.brn} ${customer.industry} ${customer.segment} ${customer.rm}`.toLowerCase();
    const matchesSearch = !query || haystack.includes(query);
    const matchesIndustry = industryValue === 'All' || customer.industry === industryValue;
    const matchesRisk = riskValue === 'All' || customerRiskTier(customer) === riskValue;
    const matchesProduct = productValue === 'All' || customer.products.some(([product]) => product === productValue);
    return matchesSearch && matchesIndustry && matchesRisk && matchesProduct;
  });

  if (!filtered.length) filtered = [selectedCustomer()];
  if (!filtered.some(customer => customer.id === selectedCustomerId)) {
    selectedCustomerId = filtered[0].id;
  }

  const options = filtered
    .map(customer => `<option value="${customer.id}">${customer.name} / BRN ${customer.brn}</option>`)
    .join('');

  const customerSelect = document.getElementById('customerSelect');
  if (customerSelect) {
    customerSelect.innerHTML = options;
    customerSelect.value = selectedCustomerId;
  }
}

function setCustomer360Mode(mode = c360Mode) {
  c360Mode = mode;
  const listPanel = document.getElementById('c360CustomerListPanel');
  const detailPanel = document.getElementById('c360DetailContent');
  const generateBtn = document.getElementById('generateBriefBtn');
  const downloadBtn = document.getElementById('downloadC360Btn');
  const actionRow = document.querySelector('.c360-action-row');

  if (listPanel) listPanel.classList.toggle('hidden', mode !== 'list');
  if (detailPanel) detailPanel.classList.toggle('hidden', mode !== 'detail');
  if (actionRow) actionRow.classList.toggle('hidden', mode !== 'detail');
  [generateBtn, downloadBtn].forEach(button => {
    if (button) button.classList.toggle('hidden', mode !== 'detail');
  });
}

function getWalletShareData() {
  return {
    currentValue: 'RM25m',
    totalWallet: 'RM250m',
    walletShare: '10%',
    untapped: 'RM225m',
    confidence: '72%',
    confidenceLabel: 'Medium',
    badge: 'Low Share',
    signals: [
      'High recurring supplier payments detected through transaction history',
      'Low deposit balance compared with transaction volume',
      'FX-related payments suggest treasury opportunity',
      'No payroll or cash management product detected',
      'Trade finance usage appears below industry benchmark',
      'Current facility utilisation is healthy but product penetration remains low'
    ],
    actions: [
      ['Offer Cash Management Package', 'Customer has recurring inflows and outflows that may benefit from account structuring, collections and payment automation.', 'High Impact'],
      ['Propose Treasury FX Solution', 'Recurring USD supplier payments indicate potential FX hedging and treasury advisory opportunity.', 'Revenue Opportunity'],
      ['Explore Trade Finance Facility', 'Transaction patterns suggest import/export-related flows that may support trade finance cross-sell.', 'Growth Opportunity']
    ]
  };
}

function renderWalletShareOptimization() {
  const target = document.getElementById('walletShareContent');
  const compact = document.getElementById('walletSummaryCompact');
  if (!target && !compact) return;

  const wallet = getWalletShareData();

  if (compact) {
    compact.innerHTML = `
      <span><b>Estimated Wallet Share</b>${wallet.walletShare}</span>
      <span><b>Untapped Opportunity</b>${wallet.untapped}</span>
      <span><b>AI Confidence</b>${wallet.confidence}</span>
    `;
  }

  if (!target) return;

  target.innerHTML = `
    <div class="wallet-summary-grid">
      <article><span>Current Relationship Value</span><strong>${wallet.currentValue}</strong><p>Current exposure, deposits and active product holdings with the bank.</p></article>
      <article><span>Estimated Total Banking Wallet</span><strong>${wallet.totalWallet}</strong><p>AI-estimated total financial relationship size across banking providers.</p></article>
      <article><span>Estimated Wallet Share</span><strong>${wallet.walletShare}</strong><p>Estimated share currently captured by the bank.</p><b class="ops-badge ops-badge-red">${wallet.badge}</b></article>
      <article><span>Untapped Opportunity</span><strong>${wallet.untapped}</strong><p>Potential additional wallet available for growth opportunities.</p></article>
    </div>

    <div class="wallet-diagnosis-card">
      <div class="wallet-gauge-block">
        <div class="wallet-gauge" style="--wallet-share: 10">
          <strong>${wallet.walletShare}</strong>
          <span>Estimated Wallet Share</span>
        </div>
        <div class="wallet-confidence">
          <span>AI Confidence</span>
          <strong>${wallet.confidence} ${wallet.confidenceLabel}</strong>
          <p>Confidence is based on transaction volume, recurring payment patterns, product penetration and available customer data.</p>
        </div>
      </div>

      <div class="wallet-signal-block">
        <h4>Key Signals Detected</h4>
        ${renderDetailList(wallet.signals)}
      </div>
    </div>

    <div class="wallet-action-grid">
      ${wallet.actions.map(([title, text, impact]) => `
        <article>
          <b class="ops-badge ${impact === 'High Impact' ? 'ops-badge-red' : impact === 'Revenue Opportunity' ? 'ops-badge-amber' : 'ops-badge-green'}">${impact}</b>
          <strong>${title}</strong>
          <p>${text}</p>
        </article>
      `).join('')}
    </div>

    <p class="wallet-disclaimer">Wallet share is AI-estimated and should be validated by the RM through customer engagement and supporting documents.</p>
  `;
}

function renderCustomer360() {
  const customer = selectedCustomer();

  setCustomer360Mode();

  document.getElementById('customerName').textContent = customer.name;
  document.getElementById('customerHealthBadge').textContent = `${customer.status} · ${customer.health}`;
  document.getElementById('customerHealthBadge').className = `badge ${badgeClass(customer)}`;

  const brnEl = document.getElementById('businessRegistration');
  if (brnEl) brnEl.textContent = customer.brn;

  document.getElementById('companyProfile').textContent = customer.companyProfile;
  document.getElementById('groupStructure').textContent = customer.groupStructure;
  const uboEl = document.getElementById('ubo');
  if (uboEl) uboEl.textContent = customer.ubo;
  document.getElementById('relationshipManager').textContent = customer.rm;
  document.getElementById('onboardingStatus').textContent = customer.onboarding;
  document.getElementById('internalRating').textContent = customer.internalRating;

  document.getElementById('aiSummaryList').innerHTML = customer.aiSummary
    .map(([title, text]) => `<div class="insight-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  document.getElementById('bankingProducts').innerHTML = customer.products
    .map(([title, text]) => `<div class="product-card"><strong>${title}</strong><span>${text}</span></div>`)
    .join('');

  document.getElementById('creditInfo').innerHTML = customer.creditInfo
    .map(([title, text]) => `<div class="metric-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  const relationshipMetrics = [
    ...customer.ratios,
    ['Revenue', customer.revenue],
    ['Outstanding Facilities', customer.exposure],
    ['Deposit Holdings', customer.deposits],
    ['Relationship Value', customer.relationshipValue],
    ['Wallet Share', getWalletShareData().walletShare],
    ['Untapped Opportunity', getWalletShareData().untapped]
  ];

  document.getElementById('ratioCards').innerHTML = relationshipMetrics
    .map(([title, value]) => `<div><strong>${value}</strong><span>${title}</span></div>`)
    .join('');

  const selectorEl = document.getElementById('customerSelect');
  if (selectorEl) selectorEl.value = selectedCustomerId;

  renderCustomerMarketIntelligence();
  renderCustomerInteractions();
  renderCustomerDocuments();
  renderCustomerDocumentRequests();
  renderWalletShareOptimization();
}

function renderCustomerMarketIntelligence() {
  const customer = selectedCustomer();
  const target = document.getElementById('customerMarketIntelligence');
  if (!target) return;

  const related = marketSignals.filter(signal => (signal.clientIds || []).includes(customer.id));

  target.innerHTML = related.length
    ? related.map(signal => {
        const index = marketSignals.indexOf(signal);
        return `
          <div class="customer-market-item">
            <b>${signal.icon}</b>
            <div>
              <strong>${signal.title}</strong>
              <p>${signal.impact}</p>
              <button type="button" data-market-index="${index}">Details</button>
            </div>
          </div>
        `;
      }).join('')
    : `<div class="customer-market-item"><b>INFO</b><div><strong>No immediate market signal</strong><p>No sector-specific market intelligence is tagged to this customer today.</p></div></div>`;
}

function getCustomerPeriodValues(customer, type) {
  const base = type === 'repayment' ? customer.repayment : customer.financials;
  const last = base[base.length - 1];
  const modifiers = {
    today: base.slice(-4).map((value, index) => Math.max(1, value - 3 + index)),
    mtd: base.slice(-4).map((value, index) => Math.max(1, value - 2 + index)),
    last6: Array.from({ length: 6 }, (_, index) => {
      const start = base[0];
      const end = last;
      return Math.round(start + ((end - start) / 5) * index);
    }),
    ytd: base.slice(-4).map(value => Math.round(value * 1.02)),
    last3y: type === 'repayment'
      ? [base[0] - 3, base[1] - 2, base[2] - 1, base[base.length - 1]]
      : [base[0], base[1], base[2], base[base.length - 1]]
  };

  return modifiers[activeCustomer360Period] || base;
}

function getCustomerPeriodLabels() {
  const labelMap = {
    today: ['9 AM', '12 PM', '3 PM', '6 PM'],
    mtd: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    last6: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    ytd: ['Q1', 'Q2', 'Q3', 'Q4'],
    last3y: ['FY2023', 'FY2024', 'FY2025', 'FY2026']
  };

  return labelMap[activeCustomer360Period] || labelMap.today;
}

function renderChartFigures(targetId, values, formatter) {
  const target = document.getElementById(targetId);
  if (!target) return;

  target.innerHTML = '';
}

function drawCustomerCharts() {
  const customer = selectedCustomer();
  const label = periodLabel(activeCustomer360Period);
  const periodLabels = getCustomerPeriodLabels();
  const financialValues = getCustomerPeriodValues(customer, 'financial');
  const repaymentValues = getCustomerPeriodValues(customer, 'repayment');

  renderChartFigures('financialFigures', financialValues, value => `RM${value}m`);
  renderChartFigures('repaymentFigures', repaymentValues, value => `${value}/100`);

  drawLineChart('financialChart', financialValues, `Revenue trend: ${label}`, {
    labels: periodLabels,
    xAxisLabel: 'Period',
    yAxisLabel: 'Revenue (RM million)',
    valuePrefix: 'RM',
    valueSuffix: 'm'
  });

  drawLineChart('repaymentChart', repaymentValues, `Repayment behaviour: ${label}`, {
    labels: periodLabels,
    xAxisLabel: 'Period',
    yAxisLabel: 'Behaviour score',
    valueSuffix: '/100'
  });
}

function openExpandedCustomerChart(type) {
  const customer = selectedCustomer();
  const label = periodLabel(activeCustomer360Period);
  const isRepayment = type === 'repayment';
  const values = getCustomerPeriodValues(customer, isRepayment ? 'repayment' : 'financial');
  const labels = getCustomerPeriodLabels();
  const canvasId = `expanded${isRepayment ? 'Repayment' : 'Financial'}Chart`;
  const title = isRepayment ? `Repayment behaviour: ${label}` : `Revenue trend: ${label}`;

  openDetailModal({
    kicker: 'Customer 360 Analytics',
    title: isRepayment ? 'Expanded repayment behaviour' : 'Expanded revenue and EBITDA trend',
    body: `
      <section class="expanded-chart-modal">
        <p>Hover over each point to view the period value.</p>
        <canvas id="${canvasId}" width="980" height="420"></canvas>
      </section>
    `
  });

  requestAnimationFrame(() => {
    drawLineChart(canvasId, values, title, {
      labels,
      valuePrefix: isRepayment ? '' : 'RM',
      valueSuffix: isRepayment ? '/100' : 'm'
    });
  });
}

function renderCustomerDocuments() {
  const customer = selectedCustomer();
  const shortName = getCustomerShortName(customer);

  const customerDocs = documents.filter(doc => {
    const docCustomer = doc[1];
    return shortName.includes(docCustomer) || docCustomer.includes(shortName);
  });

  const target = document.getElementById('customerDocumentsList');
  if (!target) return;

  target.innerHTML = `
    <div class="table-wrap c360-doc-table-wrap">
      <table class="c360-doc-table">
        <thead>
          <tr>
            <th>Document</th>
            <th>Type</th>
            <th>Status</th>
            <th>Updated</th>
            <th>Owner</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${customerDocs.length ? customerDocs.map(([fileName, , category, status, date, owner]) => `
            <tr>
              <td><strong>${fileName}</strong></td>
              <td>${category}</td>
              <td><span class="badge ${status.includes('Review') || status.includes('Draft') ? 'medium' : 'good'}">${status}</span></td>
              <td>${date}</td>
              <td>${owner}</td>
              <td><button type="button" class="download-icon-btn" title="Download">↓</button></td>
            </tr>
          `).join('') : `
            <tr>
              <td colspan="6">No repository items are currently tagged to this customer.</td>
            </tr>
          `}
        </tbody>
      </table>
    </div>
  `;
}

function renderWorkflowStrip(targetId, stages, activeIndex = 0) {
  const target = document.getElementById(targetId);
  if (!target) return;

  target.innerHTML = stages
    .map((stage, index) => `
      <div class="workflow-step ${index <= activeIndex ? 'active' : ''}">
        <span>${String(index + 1).padStart(2, '0')}</span>
        <strong>${stage}</strong>
      </div>
    `)
    .join('');
}

function renderCreditPipeline() {
  const statuses = ['Draft', 'Submitted', 'Credit Review', 'Additional Information Required', 'Approved', 'Rejected', 'Disbursed'];
  renderWorkflowStrip('creditWorkflow', statuses, 3);

  document.getElementById('creditPipeline').innerHTML = statuses.map(status => {
    const cards = creditDeals
      .filter(deal => deal.status === status)
      .map(deal => {
        const customer = getCustomerByNameFragment(deal.customer);
        return `
          <div class="pipeline-card">
            <strong>${customer ? `<button class="customer-button" data-customer-id="${customer.id}">${deal.customer}</button>` : deal.customer}</strong>
            <span>Product: ${deal.product}</span>
            <span>Deal Value: ${deal.value}</span>
            <span>Expected Approval: ${deal.date}</span>
            <span>Probability: <b class="${probabilityClass(deal.probability)}-text">${deal.probability}%</b></span>
            <div class="probability ${probabilityClass(deal.probability)}"><div style="width:${deal.probability}%"></div></div>
          </div>
        `;
      })
      .join('') || '<p class="table-note">No deals</p>';

    return `<div class="pipeline-column"><h4>${status}</h4>${cards}</div>`;
  }).join('');
}

function renderSalesPipeline() {
  const stages = ['Prospect', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
  renderWorkflowStrip('salesWorkflow', stages, 3);

  const pipelineNote = document.getElementById('salesPipelineCoverage');
  if (pipelineNote) {
    const newToBankCount = salesOpps.filter(opp => newToBankOpportunityNames.includes(opp.customer)).length;
    const existingCount = salesOpps.length - newToBankCount;
    pipelineNote.textContent = `Includes ${existingCount} existing relationship opportunities and ${newToBankCount} new-to-bank prospects.`;
  }

  document.getElementById('salesPipeline').innerHTML = stages.map(stage => {
    const cards = salesOpps
      .filter(opp => opp.stage === stage)
      .map(opp => {
        const customer = getCustomerByNameFragment(opp.customer);
        const isNewToBank = newToBankOpportunityNames.includes(opp.customer) || !customer;
        return `
          <div class="opportunity-card">
            <strong>${customer ? `<button class="customer-button" data-customer-id="${customer.id}">${opp.customer}</button>` : opp.customer}</strong>
            <span class="opportunity-type-badge ${isNewToBank ? 'new' : 'existing'}">${isNewToBank ? 'New-to-bank prospect' : 'Existing customer'}</span>
            <span>Product: ${opp.product}</span>
            <span>Opportunity Value: ${opp.value}</span>
            <span>Expected Revenue: ${opp.revenue}</span>
            <span>Probability: <b class="${probabilityClass(opp.probability)}-text">${opp.probability}%</b></span>
            <div class="probability ${probabilityClass(opp.probability)}"><div style="width:${opp.probability}%"></div></div>
          </div>
        `;
      })
      .join('') || '<p class="table-note">No opportunities</p>';

    return `<div class="kanban-column"><h4>${stage}</h4>${cards}</div>`;
  }).join('');
}

function getTaskParts(task) {
  const [type, title, time, priority] = task;
  const parts = time.split(',');
  return {
    type,
    title,
    date: parts[0] || 'Today',
    time: (parts[1] || '').trim() || 'All day',
    priority
  };
}

const todayForCalendar = new Date();
let relationshipCalendarCursor = new Date(todayForCalendar.getFullYear(), todayForCalendar.getMonth(), 1);
let selectedRelationshipDate = dateKey(todayForCalendar);

const relationshipAppointments = [
  { date: dateKey(todayForCalendar), time: '10:30 AM', type: 'Meeting', title: 'ABC Manufacturing FX proposal call', customerId: 'abc', priority: 'High' },
  { date: dateKey(todayForCalendar), time: '2:30 PM', type: 'Site Visit', title: 'MNO Construction project status review', customerId: 'mno', priority: 'High' },
  { date: dateKey(new Date(todayForCalendar.getFullYear(), todayForCalendar.getMonth(), todayForCalendar.getDate() + 1)), time: '11:00 AM', type: 'Review', title: 'GHI Exporters receivables financing note', customerId: 'ghi', priority: 'Medium' },
  { date: dateKey(new Date(todayForCalendar.getFullYear(), todayForCalendar.getMonth(), todayForCalendar.getDate() + 3)), time: '9:30 AM', type: 'Annual Review', title: 'JKL Food Processing statements follow-up', customerId: 'jkl', priority: 'High' },
  { date: dateKey(new Date(todayForCalendar.getFullYear(), todayForCalendar.getMonth(), todayForCalendar.getDate() + 5)), time: '3:00 PM', type: 'Proposal', title: 'DEF Retail inventory financing proposal', customerId: 'def', priority: 'Medium' },
  { date: dateKey(new Date(todayForCalendar.getFullYear(), todayForCalendar.getMonth(), todayForCalendar.getDate() + 8)), time: '10:00 AM', type: 'Check-in', title: 'VWX receivable ageing collection', customerId: 'vwx', priority: 'Medium' }
];

function dateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function parseDateKey(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function formatCalendarDate(value) {
  return parseDateKey(value).toLocaleDateString('en-MY', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
}

function appointmentsForDate(value) {
  return relationshipAppointments
    .filter(appointment => appointment.date === value)
    .sort((a, b) => a.time.localeCompare(b.time));
}

function renderDashboardCalendar() {
  const target = document.getElementById('dashboardCalendar');
  if (!target) return;

  const year = relationshipCalendarCursor.getFullYear();
  const month = relationshipCalendarCursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlanks = firstDay.getDay();
  const todayKey = dateKey(new Date());
  const monthLabel = firstDay.toLocaleDateString('en-MY', { month: 'long', year: 'numeric' });
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const cells = [];

  for (let index = 0; index < leadingBlanks; index += 1) {
    cells.push('<div class="calendar-date-cell is-empty"></div>');
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const cellDate = new Date(year, month, day);
    const key = dateKey(cellDate);
    const items = appointmentsForDate(key);
    cells.push(`
      <button type="button" class="calendar-date-cell ${key === todayKey ? 'is-today' : ''} ${key === selectedRelationshipDate ? 'is-selected' : ''} ${items.length ? 'has-events' : ''}" data-calendar-date="${key}">
        <b>${day}</b>
        ${items.slice(0, 2).map(item => `<span>${item.time} ${item.type}</span>`).join('')}
        ${items.length > 2 ? `<span class="calendar-more-count">+${items.length - 2} more</span>` : ''}
      </button>
    `);
  }

  const selectedItems = appointmentsForDate(selectedRelationshipDate);
  target.innerHTML = `
    <div class="calendar-month-head">
      <div>
        <span>Selected month</span>
        <strong>${monthLabel}</strong>
      </div>
      <div class="calendar-month-controls">
        <button type="button" data-calendar-month="prev" aria-label="Previous month">&lt;</button>
        <button type="button" data-calendar-month="today">Today</button>
        <button type="button" data-calendar-month="next" aria-label="Next month">&gt;</button>
      </div>
    </div>
    <div class="calendar-weekday-row">
      ${weekdays.map(day => `<span>${day}</span>`).join('')}
    </div>
    <div class="calendar-date-grid">
      ${cells.join('')}
    </div>
    <div class="calendar-day-agenda">
      <div class="agenda-head">
        <span>Planned for</span>
        <strong>${formatCalendarDate(selectedRelationshipDate)}</strong>
      </div>
      ${selectedItems.length ? selectedItems.map(item => {
        const customer = customerById(item.customerId);
        return `
          <div class="agenda-item priority-${item.priority.toLowerCase()}">
            <time>${item.time}</time>
            <div>
              <strong>${item.title}</strong>
              <span>${item.type} / ${getCustomerShortName(customer)} / ${item.priority}</span>
            </div>
          </div>
        `;
      }).join('') : '<p class="table-note">No appointments planned for this day.</p>'}
    </div>
  `;
}

function renderDashboardMeetingPrep() {
  const target = document.getElementById('dashboardMeetingPrep');
  if (!target) return;

  target.innerHTML = '';
}

function renderCalendarCallPacks() {
  const target = document.getElementById('calendarCallPacks');
  if (!target) return;

  target.innerHTML = callPackItems.map(item => {
    const customer = customerById(item.clientId);
    return `
      <article class="compact-review-card call-pack-card">
        <div class="compact-review-top">
          <span class="ops-severity ${item.status === 'Ready' ? 'info' : 'warning'}">${item.label}</span>
          <span class="ops-badge ${statusBadgeClass(item.status)}">${item.status}</span>
        </div>
        <div class="call-pack-title-row">
          <strong>${getCustomerShortName(customer)}</strong>
          <button type="button" class="call-pack-link-icon" data-customer-id="${customer.id}" title="Open customer call pack">
            <svg class="icon"><use href="#i-documents"></use></svg>
          </button>
        </div>
        <p>${item.note}</p>
        <small>${item.detail}</small>
      </article>
    `;
  }).join('');
}

function renderCustomerDocumentRequests() {
  const target = document.getElementById('customerDocumentRequests');
  if (!target) return;

  const requests = customerDocumentRequestItems.filter(item => item.clientId === selectedCustomerId);

  target.innerHTML = requests.length ? `
    <div class="ops-table-wrap">
      <table class="ops-table">
        <thead>
          <tr>
            <th>Document</th>
            <th>Status</th>
            <th>Owner</th>
            <th>Purpose</th>
          </tr>
        </thead>
        <tbody>
          ${requests.map(item => `
            <tr>
              <td>${item.document}</td>
              <td><span class="ops-badge ${statusBadgeClass(item.status)}">${item.status}</span></td>
              <td>${item.owner}</td>
              <td>${item.purpose}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  ` : '<p class="table-note">No open document requests for this customer.</p>';
}

function renderAlertSupportSections() {
  const target = document.getElementById('alertsSupportSections');
  if (!target) return;

  target.innerHTML = `
    <section class="embedded-alert-section">
      <div class="embedded-tool-header">
        <div>
          <span>Facility Renewals</span>
          <strong>Expiring limits and repricing actions</strong>
        </div>
      </div>
      <div class="ops-table-wrap">
        <table class="ops-table">
          <thead>
            <tr>
              <th>Client</th>
              <th>Facility</th>
              <th>Exposure</th>
              <th>Due</th>
              <th>RM action</th>
            </tr>
          </thead>
          <tbody>
            ${facilityRenewalItems.map(item => {
              const customer = customerById(item.clientId);
              return `
                <tr>
                  <td><button class="ops-link" data-customer-id="${customer.id}">${getCustomerShortName(customer)}</button></td>
                  <td>${item.facility}</td>
                  <td>${item.exposure}</td>
                  <td>${item.due}</td>
                  <td>${item.action}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </section>
    <section class="embedded-alert-section">
      <div class="embedded-tool-header">
        <div>
          <span>Covenant Tracker</span>
          <strong>Financial submissions and covenant watchlist</strong>
        </div>
      </div>
      <div class="ops-table-wrap">
        <table class="ops-table">
          <thead>
            <tr>
              <th>Client</th>
              <th>Covenant / Control</th>
              <th>Status</th>
              <th>Due</th>
              <th>Next step</th>
            </tr>
          </thead>
          <tbody>
            ${covenantTrackerItems.map(item => {
              const customer = customerById(item.clientId);
              return `
                <tr>
                  <td><button class="ops-link" data-customer-id="${customer.id}">${getCustomerShortName(customer)}</button></td>
                  <td>${item.control}</td>
                  <td><span class="ops-badge ${statusBadgeClass(item.status)}">${item.status}</span></td>
                  <td>${item.due}</td>
                  <td>${item.action}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </section>
  `;
}

function renderTasks() {
  const taskList = document.getElementById('taskList');
  if (!taskList) return;

  const today = new Date();
  const dateText = today.toLocaleDateString('en-MY', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' });

  taskList.innerHTML = `
    <div class="task-date-banner">
      <span>Today</span>
      <strong>${dateText}</strong>
    </div>
    ${tasks.map(task => {
      const item = getTaskParts(task);
      return `
        <div class="task-item task-priority-${item.priority.toLowerCase()}">
          <span class="task-priority-pill">${item.priority}</span>
          <div class="task-time-block">
            <strong>${item.date}</strong>
            <b>${item.time}</b>
          </div>
          <div>
            <strong>${item.type}: ${item.title}</strong>
            <p>Linked module: <button type="button" class="inline-customer-link" data-view-target="customer360View">Customer 360</button></p>
          </div>
        </div>
      `;
    }).join('')}
  `;

  renderCalendarView();
  renderCalendarCallPacks();
}

function renderCalendarView() {
  const target = document.getElementById('calendarGrid');
  if (!target) return;

  const viewButtons = ['today', 'week', 'month', 'year']
    .map(view => `<button type="button" class="${activeCalendarView === view ? 'active' : ''}" data-calendar-view="${view}">${view.charAt(0).toUpperCase() + view.slice(1)}</button>`)
    .join('');

  const todayTasks = tasks.map(getTaskParts).filter(task => task.date.toLowerCase().includes('today'));
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

  let body = '';
  if (activeCalendarView === 'today') {
    body = `<div class="calendar-agenda">${todayTasks.map(task => `<div class="calendar-event"><strong>${task.time}</strong><br>${task.title}</div>`).join('')}</div>`;
  } else if (activeCalendarView === 'month') {
    body = `<div class="calendar-month-grid">${Array.from({ length: 30 }, (_, index) => `<div class="${index === 2 ? 'today-cell' : ''}"><b>${index + 1}</b>${index < 6 ? '<span>RM follow-up</span>' : ''}</div>`).join('')}</div>`;
  } else if (activeCalendarView === 'year') {
    body = `<div class="calendar-year-grid">${['Q1', 'Q2', 'Q3', 'Q4'].map((q, index) => `<div><strong>${q}</strong><span>${18 + index * 4} client actions</span></div>`).join('')}</div>`;
  } else {
    body = weekDays.map((day, index) => {
      const dayTasks = tasks.filter((_, taskIndex) => taskIndex % 5 === index);
      return `
        <div class="calendar-day">
          <h4>${day}</h4>
          ${dayTasks.map(task => `<div class="calendar-event"><strong>${getTaskParts(task).time}</strong><br>${task[1]}</div>`).join('')}
        </div>
      `;
    }).join('');
  }

  target.innerHTML = `
    <div class="calendar-toolbar">${viewButtons}</div>
    <div class="calendar-body calendar-${activeCalendarView}">${body}</div>
  `;
}

function renderAlerts() {
  const severityMeta = {
    critical: ['Needs action now', 'bad', 'Contact customer or escalate today'],
    warning: ['Review today', 'medium', 'Validate and assign owner'],
    info: ['Awareness', 'neutral', 'Track in next RM touchpoint']
  };

  const groups = ['critical', 'warning', 'info'];
  const total = alerts.length;
  const customerForAlert = text => {
    const match = customers.find(customer => text.includes(getCustomerShortName(customer)) || text.includes(customer.name.split(' ')[0]));
    return match || selectedCustomer();
  };

  document.getElementById('alertsList').innerHTML = `
    <div class="alerts-overview">
      ${groups.map(group => {
        const count = alerts.filter(([, , severity]) => severity === group).length;
        return `<div class="alert-summary ${group}"><strong>${count}</strong><span>${severityMeta[group][0]}</span></div>`;
      }).join('')}
    </div>
    <div class="ops-table-wrap alert-compact-wrap">
      <table class="ops-table alert-compact-table">
        <thead>
          <tr>
            <th>Priority</th>
            <th>Customer / Trigger</th>
            <th>Impact</th>
            <th>Next action</th>
          </tr>
        </thead>
        <tbody>
          ${alerts.map(([title, text, severity]) => {
            const customer = customerForAlert(text);
            return `
              <tr>
                <td><span class="ops-severity ${severity}">${severity}</span></td>
                <td>
                  <button type="button" class="ops-link" data-customer-id="${customer.id}">${getCustomerShortName(customer)}</button>
                  <small>${title}</small>
                </td>
                <td>${text}</td>
                <td>${severityMeta[severity][2]}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
      <p class="table-note">${total} active alerts sorted by RM urgency.</p>
    </div>
  `;

  renderAlertSupportSections();
}

function buildMeetingBrief(customer) {
  return `Meeting Brief: ${customer.name}

Relationship snapshot:
- Segment: ${customer.segment}
- Industry: ${customer.industry}
- BRN: ${customer.brn}
- Exposure: ${customer.exposure}
- Deposits: ${customer.deposits}
- Internal rating: ${customer.internalRating}

Key AI observations:
${customer.aiSummary.map(([title, text]) => `- ${title}: ${text}`).join('\n')}

Recommended meeting agenda:
1. Confirm latest cash-flow and transaction pattern.
2. Discuss next best action: ${customer.nextAction}
3. Validate market intelligence relevant to ${customer.industry}.
4. Agree owner and timeline for documents, facility review or product proposal.

Suggested RM follow-up:
- Update call note immediately after meeting.
- Create a follow-up action for the next agreed step.
- Escalate credit or Treasury support if customer confirms need.`;
}

function openMeetingBriefModal() {
  const customer = selectedCustomer();
  const brief = buildMeetingBrief(customer);

  openDetailModal({
    kicker: 'Customer 360',
    title: `Meeting brief for ${getCustomerShortName(customer)}`,
    body: `
      <button type="button" class="modal-copy-btn" data-copy-text="${escapeHtml(brief)}">Copy to clipboard</button>
      <section class="detail-section">
        <strong>Summary</strong>
        <p>${customer.companyProfile}</p>
      </section>
      <section class="detail-section">
        <strong>Prepared brief</strong>
        <pre class="meeting-brief-preview">${escapeHtml(brief)}</pre>
      </section>
    `
  });
}

function buildC360ExportPreview(customer) {
  return `
    <section class="c360-export-preview">
      <div class="export-summary-head">
        <div>
          <span>Customer 360 Preview</span>
          <h4>${customer.name}</h4>
          <p>BRN ${customer.brn} / ${customer.segment} / ${customer.industry}</p>
        </div>
        <strong>${customer.status} ${customer.health}</strong>
      </div>

      <div class="export-metric-grid">
        <div><span>Exposure</span><strong>${customer.exposure}</strong></div>
        <div><span>Deposits</span><strong>${customer.deposits}</strong></div>
        <div><span>Revenue</span><strong>${customer.revenue}</strong></div>
        <div><span>Internal rating</span><strong>${customer.internalRating}</strong></div>
      </div>

      <section class="detail-section">
        <strong>Company profile</strong>
        <p>${customer.companyProfile}</p>
      </section>

      <section class="detail-section">
        <strong>Financial ratios</strong>
        <div class="export-ratio-row">
          ${customer.ratios.map(([label, value]) => `<span><b>${value}</b>${label}</span>`).join('')}
        </div>
      </section>

      <section class="detail-section">
        <strong>Risk and relationship observations</strong>
        ${renderDetailList(customer.aiSummary.map(([title, text]) => `${title}: ${text}`))}
      </section>

      <section class="detail-section">
        <strong>Recommended RM action</strong>
        <p>${customer.nextAction}</p>
      </section>
    </section>
  `;
}

function openC360DownloadModal() {
  const customer = selectedCustomer();

  openDetailModal({
    kicker: 'Customer 360 Export',
    title: `Download preview for ${getCustomerShortName(customer)}`,
    body: `
      ${buildC360ExportPreview(customer)}
      <div class="modal-action-row">
        <button type="button" class="btn secondary" data-modal-cancel>Cancel</button>
        <button type="button" class="btn primary" data-save-c360-pdf>Save as PDF</button>
      </div>
    `
  });
}

function openComposeEmailModal() {
  const customer = selectedCustomer();
  openDetailModal({
    kicker: 'Customer Communication',
    title: `Compose email to ${getCustomerShortName(customer)}`,
    body: `
      <form class="modal-form" data-modal-form="email">
        <label>To<input name="to" value="${getCustomerShortName(customer)} CFO" required></label>
        <label>Subject<input name="subject" value="Follow-up from CIMBrain relationship review" required></label>
        <label>Message<textarea name="message" rows="8">Dear Customer,\n\nFollowing our latest relationship review, I would like to schedule a short discussion on your current banking needs, cash-flow priorities and potential opportunities identified by CIMBrain.\n\nRegards,\nQian Tong</textarea></label>
        <div class="modal-action-row">
          <button type="button" class="btn secondary" data-modal-cancel>Cancel</button>
          <button class="btn primary" type="submit">Save Email Draft</button>
        </div>
      </form>
    `
  });
}

function openCopilotLibrary() {
  openDetailModal({
    kicker: 'CIMBrain Library',
    title: 'Access uploaded customer documents, financial statements, images and analysis files.',
    body: `
      <div class="library-tabs">
        ${['All Files', 'Customer Documents', 'Financial Statements', 'Credit Papers', 'Images', 'Recently Used'].map((tab, index) => `<button class="${index === 0 ? 'active' : ''}" type="button">${tab}</button>`).join('')}
      </div>
      <div class="library-file-list">
        ${[
          ['Apex_Meridian_FY2026_Financials.pdf', 'PDF', '6 Jul 2026', 'Apex Meridian Industries', 'Qian Tong', 'Analysed'],
          ['Global_Halcyon_Trade_Transactions.xlsx', 'Excel', '5 Jul 2026', 'Global Halcyon Exports', 'Qian Tong', 'Analysed'],
          ['Jelita_Kencana_Credit_Review.docx', 'Word', '4 Jul 2026', 'Jelita Kencana Foods', 'Credit Team', 'Not Analysed'],
          ['DayaVista_Store_Visit_Image.png', 'Image', '2 Jul 2026', 'DayaVista Retail', 'Qian Tong', 'Analysed'],
          ['Portfolio_Risk_Report_Q2.pdf', 'PDF', '30 Jun 2026', 'Portfolio', 'CIMBrain', 'Analysed']
        ].map(file => `
          <article class="library-file-item">
            <div><strong>${file[0]}</strong><span>${file[1]} / ${file[2]} / ${file[3]}</span></div>
            <small>Uploaded by ${file[4]}</small>
            <b class="ops-badge ${file[5] === 'Analysed' ? 'ops-badge-green' : 'ops-badge-amber'}">${file[5]}</b>
            <div class="library-actions"><button>Open</button><button>Analyse</button><button>Attach to Chat</button><button>Link to Customer 360</button><button>Delete</button></div>
          </article>
        `).join('')}
      </div>
    `
  });
}

function addAttachmentChips(files) {
  const target = document.getElementById('attachmentChips');
  if (!target) return;

  Array.from(files || []).forEach(file => {
    const chip = document.createElement('span');
    chip.className = 'attachment-chip';
    const size = file.size ? `${Math.max(1, Math.round(file.size / 1024))} KB` : 'Demo file';
    chip.innerHTML = `<svg class="icon"><use href="#i-documents"></use></svg><b>${file.name}</b><small>${size}</small><button type="button" aria-label="Remove attachment">x</button>`;
    chip.querySelector('button').addEventListener('click', () => chip.remove());
    target.appendChild(chip);
  });
}

function openCreditRequestForm() {
  openDetailModal({
    kicker: 'Credit Pipeline',
    title: 'New credit request',
    body: `
      <form class="modal-form" data-modal-form="credit">
        <label>Customer<input name="customer" required placeholder="Customer name"></label>
        <label>Product<input name="product" required placeholder="Working capital, term loan..."></label>
        <label>Deal value<input name="value" required placeholder="RM 5.0m"></label>
        <label>Expected approval<input name="date" required placeholder="30 Jul 2026"></label>
        <label>Probability<input name="probability" type="number" min="0" max="100" value="45"></label>
        <button class="btn primary" type="submit">Add request</button>
      </form>
    `
  });
}

function openNewCustomerForm() {
  openDetailModal({
    kicker: 'Quick Actions',
    title: 'New customer onboarding',
    body: `
      <form class="modal-form" data-modal-form="newCustomer">
        <label>Customer name<input name="customer" required placeholder="Customer company name"></label>
        <label>Business registration no.<input name="brn" required placeholder="202601234567"></label>
        <label>Industry<input name="industry" required placeholder="Manufacturing, trade, services..."></label>
        <label>Relationship manager<input name="rm" required value="QT"></label>
        <button class="btn primary" type="submit">Create onboarding draft</button>
      </form>
    `
  });
}

function openOpportunityForm() {
  openDetailModal({
    kicker: 'Sales Opportunities',
    title: 'Create opportunity',
    body: `
      <form class="modal-form" data-modal-form="opportunity">
        <label>Customer<input name="customer" required placeholder="Customer name"></label>
        <label>Product<input name="product" required placeholder="Cash management, FX..."></label>
        <label>Opportunity value<input name="value" required placeholder="RM 120k"></label>
        <label>Expected revenue<input name="revenue" required placeholder="RM 38k"></label>
        <label>Probability<input name="probability" type="number" min="0" max="100" value="35"></label>
        <button class="btn primary" type="submit">Create opportunity</button>
      </form>
    `
  });
}

function openTaskForm() {
  openDetailModal({
    kicker: 'Relationship Calendar',
    title: 'Add follow-up action',
    body: `
      <form class="modal-form" data-modal-form="task">
        <label>Type<input name="type" required placeholder="Call, meeting, review..."></label>
        <label>Follow-up title<input name="title" required placeholder="Follow up with CFO"></label>
        <label>Date and time<input name="time" required placeholder="Today, 3:30 PM"></label>
        <label>Priority<select name="priority"><option>High</option><option>Medium</option><option>Low</option></select></label>
        <button class="btn primary" type="submit">Add follow-up</button>
      </form>
    `
  });
}

function openAppointmentForm(defaults = {}) {
  const customerOptions = customers
    .map(customer => `<option value="${customer.id}">${getCustomerShortName(customer)}</option>`)
    .join('');
  const appointmentTitle = defaults.title || '';
  const appointmentType = defaults.type || 'Meeting';
  const typeOptions = ['Meeting', 'Call', 'Site Visit', 'Annual Review', 'Credit Review']
    .map(type => `<option ${type === appointmentType ? 'selected' : ''}>${type}</option>`)
    .join('');

  openDetailModal({
    kicker: 'Relationship Calendar',
    title: defaults.modalTitle || 'Create appointment / task',
    body: `
      <form class="modal-form" data-modal-form="appointment">
        <label>Customer<select name="customerId">${customerOptions}</select></label>
        <label>Appointment / task title<input name="title" required value="${escapeHtml(appointmentTitle)}" placeholder="Customer call, review, site visit..."></label>
        <label>Date<input name="date" type="date" required value="${selectedRelationshipDate}"></label>
        <label>Time<input name="time" required placeholder="10:30 AM"></label>
        <label>Type<select name="type">${typeOptions}</select></label>
        <label>Priority<select name="priority"><option>High</option><option>Medium</option><option>Low</option></select></label>
        <button class="btn primary" type="submit">Create appointment / task</button>
      </form>
    `
  });
}

function openCreditMemoQuickAction() {
  const response = copilotResponse('Generate credit memo');
  showView('copilotView');
  setTimeout(() => {
    addChatMessage('Generate credit memo', 'user');
    addChatMessage(response);
  }, 1300);
}

function handleQuickAction(action) {
  if (action === 'New Customer') {
    openNewCustomerForm();
    return;
  }
  if (action === 'Credit Application') {
    openCreditRequestForm();
    return;
  }
  if (action === 'Schedule Meeting') {
    openAppointmentForm({ type: 'Meeting', modalTitle: 'Schedule meeting' });
    return;
  }
  if (action === 'Customer Visit') {
    openAppointmentForm({ type: 'Site Visit', title: 'Customer site visit', modalTitle: 'Schedule customer visit' });
    return;
  }
  if (action === 'Generate Credit Memo') {
    openCreditMemoQuickAction();
  }
}

async function copyTextToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('Copied to clipboard.');
  } catch (error) {
    const helper = document.createElement('textarea');
    helper.value = text;
    document.body.appendChild(helper);
    helper.select();
    document.execCommand('copy');
    helper.remove();
    showToast('Copied to clipboard.');
  }
}

function getPortfolioGrowthRecommendations() {
  return [
    {
      customer: getCustomerShortName(customerById('abc')),
      product: 'Treasury FX Package',
      currentValue: 'RM25m',
      incremental: 'RM3.5m',
      uplift: '+1.4%',
      confidence: '86%',
      impact: 'High',
      reason: 'Recurring USD supplier payments detected.'
    },
    {
      customer: getCustomerShortName(customerById('ghi')),
      product: 'Trade Finance Facility',
      currentValue: 'RM42m',
      incremental: 'RM8.0m',
      uplift: '+2.1%',
      confidence: '91%',
      impact: 'High',
      reason: 'Export transaction volume is increasing and current trade facility usage is low.'
    },
    {
      customer: getCustomerShortName(customerById('def')),
      product: 'Cash Management Solution',
      currentValue: 'RM9.4m',
      incremental: 'RM2.2m',
      uplift: '+0.8%',
      confidence: '78%',
      impact: 'Medium',
      reason: 'High transaction frequency and fragmented payment flows suggest cash management opportunity.'
    }
  ];
}

function renderPortfolioGrowthImpact() {
  const target = document.getElementById('portfolioGrowthImpact');
  if (!target) return;

  const recommendations = getPortfolioGrowthRecommendations();
  target.innerHTML = `
    <div class="growth-summary-grid">
      <div><span>Total Potential Portfolio Uplift</span><strong>+6.8%</strong></div>
      <div><span>Estimated Incremental Value</span><strong>RM29.8m</strong></div>
      <div><span>High Confidence Opportunities</span><strong>5</strong></div>
    </div>
    <div class="growth-card-list">
      ${recommendations.map(item => `
        <article class="growth-impact-card">
          <div>
            <span>Recommended Cross-sell</span>
            <h4>${item.product}</h4>
          </div>
          <dl>
            <div><dt>Customer</dt><dd>${item.customer}</dd></div>
            <div><dt>Current Relationship Value</dt><dd>${item.currentValue}</dd></div>
            <div><dt>Estimated Incremental Portfolio Value</dt><dd>${item.incremental}</dd></div>
            <div><dt>Portfolio Uplift</dt><dd>${item.uplift}</dd></div>
            <div><dt>AI Confidence</dt><dd>${item.confidence}</dd></div>
            <div><dt>Impact Level</dt><dd>${item.impact}</dd></div>
          </dl>
          <p>Based on transaction history, product gaps and customer wallet share, CIMBrain estimates this cross-sell could increase the RM’s portfolio by ${item.uplift} if successfully converted. ${item.reason}</p>
          <div class="growth-actions">
            <button type="button">Generate Pitch</button>
            <button type="button">Add to Pipeline</button>
            <button type="button">Schedule Follow-up</button>
          </div>
        </article>
      `).join('')}
    </div>
  `;
}

function setCopilotGrowthImpactVisible(visible) {
  const panel = document.querySelector('.copilot-growth-impact');
  if (panel) panel.classList.toggle('hidden', !visible);
}

function renderCopilotContextSelector() {
  const select = document.getElementById('copilotContextCustomerSelect');
  if (!select) return;

  select.innerHTML = customers
    .map(customer => `<option value="${customer.id}">${customer.name}</option>`)
    .join('');
  select.value = selectedCustomerId;
}

function copilotResponse(prompt) {
  const lower = prompt.toLowerCase();
  const customer = selectedCustomer();
  const relatedSignals = marketSignals.filter(signal => (signal.clientIds || []).includes(customer.id));

  if (lower.includes('annual review')) {
    return `<strong>Annual review draft outline for ${getCustomerShortName(customer)}</strong>

1. Relationship overview: ${customer.segment}, ${customer.industry}, exposure ${customer.exposure}, deposits ${customer.deposits}.
2. Financial and repayment conduct: revenue ${customer.revenue}, EBITDA ${customer.ebitda}, health score ${customer.health}.
3. Credit position: ${customer.creditInfo.map(item => item.join(' - ')).join('; ')}.
4. Risk view: ${customer.aiSignal}; early warning signals include ${customer.ews.join(', ')}.
5. Recommendation: proceed with RM follow-up on "${customer.nextAction}" and update credit notes after the next customer conversation.`;
  }

  if (lower.includes('cross') || lower.includes('opportunit')) {
    const topImpact = getPortfolioGrowthRecommendations()[0];
    const opportunityRationale = customer.opportunities.map(product => {
      const productLower = product.toLowerCase();
      if (productLower.includes('fx') || productLower.includes('treasury')) {
        return `- ${product}: justified by recurring USD flows, timing mismatch between collections and payments, and a clear need to reduce margin volatility.`;
      }
      if (productLower.includes('receivable') || productLower.includes('invoice')) {
        return `- ${product}: justified by collection-cycle pressure and the need to convert confirmed receivables into earlier cash flow.`;
      }
      if (productLower.includes('trade')) {
        return `- ${product}: justified by supplier payment patterns, import or inventory cycles, and the opportunity to make drawdowns more structured.`;
      }
      if (productLower.includes('cash') || productLower.includes('payroll')) {
        return `- ${product}: justified by fragmented operating balances and the chance to improve deposit stickiness through transaction banking.`;
      }
      if (productLower.includes('working capital') || productLower.includes('asset')) {
        return `- ${product}: justified by utilisation trends, seasonal funding needs, or upcoming asset replacement cycles.`;
      }
      return `- ${product}: justified by the customer's current relationship profile, risk signal, and next-best-action fit.`;
    }).join('\n');

    return `<strong>Cross-sell recommendation</strong>

For ${customer.name}, CIMBrain sees the strongest fit in ${customer.opportunities.join(', ')}.

<section class="copilot-inline-impact">
  <h4>Portfolio Growth Impact</h4>
  <p><strong>Recommended Cross-sell: ${topImpact.product}</strong></p>
  <ul>
    <li>Customer: ${topImpact.customer}</li>
    <li>Current Relationship Value: ${topImpact.currentValue}</li>
    <li>Estimated Incremental Portfolio Value: ${topImpact.incremental}</li>
    <li>Portfolio Uplift: ${topImpact.uplift}</li>
    <li>AI Confidence: ${topImpact.confidence}</li>
    <li>Impact Level: ${topImpact.impact}</li>
  </ul>
  <p>Based on transaction history, product gaps and customer wallet share, CIMBrain estimates this cross-sell could increase the RM’s portfolio by ${topImpact.uplift} if successfully converted.</p>
</section>

Why these recommendations fit:
${opportunityRationale}

Customer evidence:
- Current signal: ${customer.aiSignal}
- Exposure and deposits: ${customer.exposure} exposure / ${customer.deposits} deposits
- Relationship conduct: ${customer.aiSummary.map(([title]) => title).slice(0, 3).join('; ')}

Conversation approach:
Start from the customer cash-flow pattern rather than the product. If supplier payments, receivable timing, or deposit leakage is driving the signal, lead with that business issue first, then position the product as the way to reduce friction, risk, or cost.

Suggested next step:
${customer.nextAction}`;
  }

  if (lower.includes('risk') || lower.includes('alert')) {
    return `<strong>Risk explanation</strong>

The current signal for ${getCustomerShortName(customer)} is: ${customer.aiSignal}.

What CIMBrain is watching:
- Facility utilisation and repayment pattern
- Deposit movement and retained operating balances
- Document readiness for annual review
- Market signal: ${relatedSignals.length ? relatedSignals.map(signal => signal.title).join(', ') : 'No sector-specific signal tagged today'}

Recommended action: validate the signal with a customer call or site visit before escalating to Credit Risk.`;
  }

  if (lower.includes('credit memo')) {
    return `<strong>Credit memo starter</strong>

Customer: ${customer.name}
BRN: ${customer.brn}
Exposure: ${customer.exposure}
Deposits: ${customer.deposits}
Internal rating: ${customer.internalRating}

Credit angle:
${customer.aiSummary.map(([title, text]) => `- ${title}: ${text}`).join('\n')}

Recommended RM note:
Review facilities based on the AI signal "${customer.aiSignal}" and confirm whether updated financials or collateral information is required before submission.`;
  }

  return `<strong>${customer.name} summary</strong>

${customer.companyProfile}

Portfolio status:
- Health score: ${customer.health} (${customer.status})
- Exposure: ${customer.exposure}
- Deposits: ${customer.deposits}
- Next best action: ${customer.nextAction}

Market intelligence:
${relatedSignals.length ? relatedSignals.map(signal => `- ${signal.title}: ${signal.impact}`).join('\n') : '- No immediate customer-specific market signal tagged today.'}

Recommended RM move:
Prepare a short customer call note, confirm whether the AI signal matches the latest customer conversation, and create a follow-up action from the agreed next step.`;
}

function addCopilotLoading() {
  const chatWindow = document.getElementById('chatWindow');
  const div = document.createElement('div');
  div.className = 'message bot copilot-loading';
  div.innerHTML = '<strong>CIMBrain is analysing portfolio context...</strong><span></span>';
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return div;
}

function sendCopilotPrompt(prompt) {
  if (!prompt) return;
  const isCrossSellPrompt = /cross[-\s]?sell/i.test(prompt);
  setCopilotGrowthImpactVisible(isCrossSellPrompt);
  addChatMessage(prompt, 'user');
  const loading = addCopilotLoading();
  setTimeout(() => {
    loading.remove();
    addChatMessage(copilotResponse(prompt));
  }, 3000);
}

async function runScan() {
  const steps = [
    'Ingesting customer, transaction, facility, deposit and document data...',
    'Scanning alerts: withdrawals, overdue credit, expiring facilities and covenant status...',
    'Identifying cross-sell opportunities across working capital, trade, treasury and cash management...',
    'Re-ranking portfolio by risk, revenue potential and relationship health...',
    'Generating RM actions, risk observations and workflow support...'
  ];

  scanOverlay.classList.remove('hidden');
  progressBar.style.width = '0%';

  for (let i = 0; i < steps.length; i += 1) {
    scanText.textContent = steps[i];
    progressBar.style.width = `${((i + 1) / steps.length) * 100}%`;
    await new Promise(resolve => setTimeout(resolve, 520));
  }

  scanOverlay.classList.add('hidden');
  updateHeaderTime();

  openDetailModal({
    kicker: 'Portfolio Analysis',
    title: 'Portfolio scan summary',
    body: `
      <section class="detail-section">
        <strong>Portfolio reviewed</strong>
        <p>${customers.length} active customers were scanned across exposure, deposits, repayment behaviour, documents and market signals.</p>
      </section>
      <section class="detail-section">
        <strong>Needs attention</strong>
        <p>2 customers require priority follow-up: ${getCustomerShortName(customerById('mno'))} for credit stress and ${getCustomerShortName(customerById('jkl'))} for high utilisation and missing financial statements.</p>
      </section>
      <section class="detail-section">
        <strong>Opportunities</strong>
        <p>${getCustomerShortName(customerById('abc'))} and ${getCustomerShortName(customerById('ghi'))} show treasury or receivables opportunities linked to USD flows.</p>
      </section>
      <section class="detail-section">
        <strong>Recommended RM actions</strong>
        ${renderDetailList(['Call high-risk customers today', `Prepare FX discussion for ${getCustomerShortName(customerById('abc'))} and ${getCustomerShortName(customerById('ghi'))}`, 'Update credit review status for pending applications', 'Create follow-up actions for missing documents'])}
      </section>
    `
  });
}

function renderAll() {
  renderDashboard();
  renderPortfolio();
  renderCustomerSelectors();
  renderCustomer360();
  renderCreditPipeline();
  renderSalesPipeline();
  renderTasks();
  renderAlerts();
  renderNotifications();
  renderReports();
  renderDashboardAnalytics();
  renderDashboardCalendar();
  renderDashboardMeetingPrep();
  renderCustomerDocumentRequests();
  renderAlertSupportSections();
  renderPortfolioGrowthImpact();
  renderCopilotContextSelector();
}

function setupEnhancedInteractions() {
  document.querySelectorAll('[data-dashboard-period]').forEach(button => {
    button.addEventListener('click', () => {
      const label = document.getElementById('dashboardViewLabel');
      if (label) label.querySelector('strong').textContent = periodLabel(button.dataset.dashboardPeriod);
      activeReportPeriod = button.dataset.dashboardPeriod || 'today';
      document.querySelectorAll('[data-report-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton.dataset.reportPeriod === activeReportPeriod);
      });
      renderReports();
    });
  });

  document.querySelectorAll('[data-c360-period]').forEach(button => {
    button.addEventListener('click', () => {
      activeCustomer360Period = button.dataset.c360Period || 'today';
      document.querySelectorAll('[data-c360-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton === button);
      });
      drawCustomerCharts();
    });
  });

  document.querySelectorAll('[data-report-period]').forEach(button => {
    button.addEventListener('click', () => {
      activeReportPeriod = button.dataset.reportPeriod || 'ytd';
      document.querySelectorAll('[data-report-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton === button);
      });
      renderReports();
    });
  });

  const customer360Search = document.getElementById('customer360Search');
  if (customer360Search) {
    customer360Search.addEventListener('input', renderCustomerSelectors);
    customer360Search.addEventListener('keydown', event => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      const customerSelect = document.getElementById('customerSelect');
      if (!customerSelect || !customerSelect.value) return;
      selectedCustomerId = customerSelect.value;
      renderAll();
      drawCustomerCharts();
    });
  }

  ['c360IndustryFilter', 'c360RiskFilter', 'c360ProductFilter'].forEach(id => {
    const filter = document.getElementById(id);
    if (!filter) return;
    filter.addEventListener('change', () => {
      renderCustomerSelectors();
      const customerSelect = document.getElementById('customerSelect');
      if (customerSelect?.value) selectedCustomerId = customerSelect.value;
      renderCustomer360();
      drawCustomerCharts();
    });
  });

  const dashboardRiskFilter = document.getElementById('dashboardRiskFilter');
  if (dashboardRiskFilter) dashboardRiskFilter.addEventListener('change', renderDashboard);

  ['exceptionSeverityFilter', 'exceptionStatusFilter'].forEach(id => {
    const filter = document.getElementById(id);
    if (filter) filter.addEventListener('change', renderDashboardPriorities);
  });

  const globalSearchBtn = document.getElementById('globalSearchBtn');
  if (globalSearchBtn) {
    globalSearchBtn.addEventListener('click', () => {
      if (!globalSearchInput.value.trim()) {
        globalSearchInput.focus();
        return;
      }
      handleGlobalSearch();
      const results = JSON.parse(globalSearchResults.dataset.results || '[]');
      if (!results.length) return;
      const selected = results[0];
      if (selected.customerId) {
        openCustomer(selected.customerId);
      } else {
        showView(selected.view);
      }
      globalSearchResults.classList.add('hidden');
    });
  }

  const generateBriefBtn = document.getElementById('generateBriefBtn');
  if (generateBriefBtn) {
    generateBriefBtn.addEventListener('click', event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      openMeetingBriefModal();
    }, true);
  }

  const downloadC360Btn = document.getElementById('downloadC360Btn');
  if (downloadC360Btn) {
    downloadC360Btn.addEventListener('click', event => {
      event.preventDefault();
      openC360DownloadModal();
    });
  }

  const composeEmailBtn = document.getElementById('composeEmailBtn');
  if (composeEmailBtn) {
    composeEmailBtn.addEventListener('click', event => {
      event.preventDefault();
      openComposeEmailModal();
    });
  }

  document.querySelectorAll('.kpi-card[data-kpi-key]').forEach(card => {
    card.addEventListener('click', () => openKpiDetail(card.dataset.kpiKey));
    card.addEventListener('keydown', event => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      event.preventDefault();
      openKpiDetail(card.dataset.kpiKey);
    });
  });

  const modelDescriptions = {
    'CIMBrain Standard': 'General RM assistant for customer queries, summaries and daily tasks.',
    'CIMBrain Advanced': 'Deeper reasoning for complex portfolio and customer analysis.',
    'CIMBrain Credit Analyst': 'Specialised for credit reviews, financial statements and risk assessment.',
    'CIMBrain Portfolio Optimizer': 'Specialised for wallet share, cross-sell, portfolio growth and revenue opportunities.',
    'CIMBrain Meeting Assistant': 'Specialised for meeting briefs, talking points and follow-up actions.'
  };
  const copilotModelSelect = document.getElementById('copilotModelSelect');
  if (copilotModelSelect) {
    copilotModelSelect.addEventListener('change', () => {
      const desc = document.getElementById('copilotModelDescription');
      if (desc) desc.textContent = modelDescriptions[copilotModelSelect.value] || 'Optimised for commercial RM workflow';
    });
  }

  const copilotContextSelect = document.getElementById('copilotContextCustomerSelect');
  if (copilotContextSelect) {
    copilotContextSelect.addEventListener('change', () => {
      selectedCustomerId = copilotContextSelect.value || selectedCustomerId;
      renderCustomerSelectors();
      renderCustomer360();
      renderCopilotContextSelector();
      showToast(`Copilot context changed to ${selectedCustomer().name}.`);
    });
  }

  const chatHistorySearch = document.getElementById('chatHistorySearch');
  if (chatHistorySearch) {
    chatHistorySearch.addEventListener('input', () => {
      const query = chatHistorySearch.value.trim().toLowerCase();
      document.querySelectorAll('.chat-history-groups button[data-chat-prompt]').forEach(button => {
        const haystack = `${button.textContent} ${button.dataset.chatPrompt}`.toLowerCase();
        button.classList.toggle('hidden', query && !haystack.includes(query));
      });
      document.querySelectorAll('.chat-history-groups > div').forEach(group => {
        const hasVisibleButton = Array.from(group.querySelectorAll('button')).some(button => !button.classList.contains('hidden'));
        group.classList.toggle('hidden', query && !hasVisibleButton);
      });
    });
  }

  document.querySelectorAll('.chat-history-groups button[data-chat-prompt]').forEach(button => {
    button.addEventListener('click', () => {
      sendCopilotPrompt(button.dataset.chatPrompt || button.textContent.trim());
    });
  });

  document.querySelectorAll('[data-library-open]').forEach(button => {
    button.addEventListener('click', openCopilotLibrary);
  });

  const fileInput = document.getElementById('copilotFileInput');
  const imageInput = document.getElementById('copilotImageInput');
  document.getElementById('fileUploadBtn')?.addEventListener('click', () => fileInput?.click());
  document.getElementById('imageUploadBtn')?.addEventListener('click', () => imageInput?.click());
  fileInput?.addEventListener('change', event => addAttachmentChips(event.target.files));
  imageInput?.addEventListener('change', event => addAttachmentChips(event.target.files));
  document.getElementById('voiceInputBtn')?.addEventListener('click', () => showToast('Voice input is ready for demo narration.'));
  document.getElementById('newChatBtn')?.addEventListener('click', () => {
    const chatWindow = document.getElementById('chatWindow');
    const welcome = document.getElementById('copilotWelcome');
    if (chatWindow) {
      chatWindow.querySelectorAll('.message, .copilot-loading, .ai-message-actions').forEach(message => message.remove());
    }
    if (welcome) welcome.classList.remove('hidden');
    document.getElementById('attachmentChips').innerHTML = '';
    setCopilotGrowthImpactVisible(false);
  });

  const newCreditRequestBtn = document.getElementById('newCreditRequestBtn');
  if (newCreditRequestBtn) newCreditRequestBtn.addEventListener('click', openCreditRequestForm);

  const createOpportunityBtn = document.getElementById('createOpportunityBtn');
  if (createOpportunityBtn) createOpportunityBtn.addEventListener('click', openOpportunityForm);

  const addTaskBtn = document.getElementById('addTaskBtn');
  if (addTaskBtn) addTaskBtn.addEventListener('click', openTaskForm);

  const createAppointmentBtn = document.getElementById('createAppointmentBtn');
  if (createAppointmentBtn) createAppointmentBtn.addEventListener('click', openAppointmentForm);

  const calendarCreateAppointmentBtn = document.getElementById('calendarCreateAppointmentBtn');
  if (calendarCreateAppointmentBtn) calendarCreateAppointmentBtn.addEventListener('click', openAppointmentForm);

  const c360ScheduleFollowUpBtn = document.getElementById('c360ScheduleFollowUpBtn');
  if (c360ScheduleFollowUpBtn) {
    c360ScheduleFollowUpBtn.addEventListener('click', event => {
      event.preventDefault();
      openAppointmentForm({
        modalTitle: 'Schedule customer follow-up',
        title: `${getCustomerShortName(selectedCustomer())} follow-up`,
        type: 'Call'
      });
    });
  }

  const detailModal = document.getElementById('detailModal');
  if (detailModal) {
    detailModal.addEventListener('click', event => {
      const copyBtn = event.target.closest('[data-copy-text]');
      if (copyBtn) copyTextToClipboard(copyBtn.dataset.copyText || '');

      const exceptionTarget = event.target.closest('[data-exception-index]');
      if (exceptionTarget) {
        openExceptionDetail(Number(exceptionTarget.dataset.exceptionIndex));
        return;
      }

      const expandTarget = event.target.closest('[data-expand-chart]');
      if (expandTarget) {
        openExpandedCustomerChart(expandTarget.dataset.expandChart);
        return;
      }

      if (event.target.closest('[data-modal-cancel]')) {
        closeDetailModal();
        return;
      }

      if (event.target.closest('[data-save-c360-pdf]')) {
        showToast('Opening print preview. Choose Save as PDF.');
        window.print();
      }
    });

    detailModal.addEventListener('submit', event => {
      const form = event.target.closest('[data-modal-form]');
      if (!form) return;
      event.preventDefault();

      const data = new FormData(form);
      const formType = form.dataset.modalForm;

      if (formType === 'credit') {
        creditDeals.unshift({
          status: 'Draft',
          customer: data.get('customer'),
          product: data.get('product'),
          value: data.get('value'),
          date: data.get('date'),
          probability: Number(data.get('probability') || 0)
        });
        renderCreditPipeline();
        closeDetailModal();
        showToast('Credit request added to Draft.');
      }

      if (formType === 'opportunity') {
        salesOpps.unshift({
          stage: 'Prospect',
          customer: data.get('customer'),
          product: data.get('product'),
          value: data.get('value'),
          revenue: data.get('revenue'),
          probability: Number(data.get('probability') || 0)
        });
        renderSalesPipeline();
        closeDetailModal();
        showToast('Opportunity created in Prospect.');
      }

      if (formType === 'newCustomer') {
        closeDetailModal();
        showToast(`${data.get('customer')} onboarding draft created for RM review.`);
      }

      if (formType === 'task') {
        tasks.unshift([data.get('type'), data.get('title'), data.get('time'), data.get('priority')]);
        renderTasks();
        closeDetailModal();
        showToast('Follow-up added to the relationship calendar.');
      }

      if (formType === 'appointment') {
        const dateValue = data.get('date') || selectedRelationshipDate;
        relationshipAppointments.push({
          date: dateValue,
          time: data.get('time') || 'All day',
          type: data.get('type') || 'Meeting',
          title: data.get('title') || 'Customer appointment',
          customerId: data.get('customerId') || selectedCustomerId,
          priority: data.get('priority') || 'Medium'
        });
        selectedRelationshipDate = dateValue;
        relationshipCalendarCursor = new Date(parseDateKey(dateValue).getFullYear(), parseDateKey(dateValue).getMonth(), 1);
        renderDashboardCalendar();
        closeDetailModal();
        showToast('Appointment created on the dashboard calendar.');
      }

      if (formType === 'email') {
        closeDetailModal();
        showToast('Email draft saved for RM review.');
      }
    });
  }

  document.body.addEventListener('click', event => {
    const exportReportTarget = event.target.closest('[data-export-report]');
    if (exportReportTarget) {
      event.preventDefault();
      showToast(`${exportReportTarget.dataset.exportReport} export prepared.`);
      return;
    }

    const exceptionTarget = event.target.closest('[data-exception-index]');
    if (exceptionTarget) {
      openExceptionDetail(Number(exceptionTarget.dataset.exceptionIndex));
      return;
    }

    const expandTarget = event.target.closest('[data-expand-chart]');
    if (expandTarget) {
      openExpandedCustomerChart(expandTarget.dataset.expandChart);
      return;
    }

    const modalCustomerLink = event.target.closest('.inline-customer-link[data-customer-id]');
    if (modalCustomerLink) {
      event.preventDefault();
      event.stopImmediatePropagation();
      closeDetailModal();
      openCustomer(modalCustomerLink.dataset.customerId);
      return;
    }

    const marketRow = event.target.closest('[data-market-row-index]');
    if (marketRow && !event.target.closest('a, button')) {
      openMarketDetail(Number(marketRow.dataset.marketRowIndex));
      return;
    }

    const calendarButton = event.target.closest('[data-calendar-view]');
    if (calendarButton) {
      activeCalendarView = calendarButton.dataset.calendarView || 'week';
      renderCalendarView();
    }

    const dateButton = event.target.closest('[data-calendar-date]');
    if (dateButton) {
      selectedRelationshipDate = dateButton.dataset.calendarDate;
      renderDashboardCalendar();
      return;
    }

    const monthButton = event.target.closest('[data-calendar-month]');
    if (monthButton) {
      const action = monthButton.dataset.calendarMonth;
      if (action === 'prev') {
        relationshipCalendarCursor = new Date(relationshipCalendarCursor.getFullYear(), relationshipCalendarCursor.getMonth() - 1, 1);
      } else if (action === 'next') {
        relationshipCalendarCursor = new Date(relationshipCalendarCursor.getFullYear(), relationshipCalendarCursor.getMonth() + 1, 1);
      } else {
        const now = new Date();
        relationshipCalendarCursor = new Date(now.getFullYear(), now.getMonth(), 1);
        selectedRelationshipDate = dateKey(now);
      }
      renderDashboardCalendar();
    }
  });

  document.body.addEventListener('keydown', event => {
    const marketRow = event.target.closest?.('[data-market-row-index]');
    if (!marketRow || (event.key !== 'Enter' && event.key !== ' ')) return;
    event.preventDefault();
    openMarketDetail(Number(marketRow.dataset.marketRowIndex));
  });

  const promptWrap = document.querySelector('.quick-prompts');
  if (promptWrap) {
    promptWrap.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      sendCopilotPrompt(button.dataset.prompt || button.textContent.trim());
    }, true);
  }

  const chatForm = document.getElementById('chatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const input = document.getElementById('chatInput');
      const prompt = input.value.trim();
      input.value = '';
      sendCopilotPrompt(prompt);
    }, true);
  }
}

/* ================================
   PROFESSIONAL BANKING OPERATIONS VIEW
================================ */

const opsExceptionQueue = [
  { severity: 'critical', queue: 'Credit Risk', item: 'Overdue repayment and covenant pressure', clientId: 'mno', sla: '2h 10m', owner: 'Credit Risk', status: 'Escalated' },
  { severity: 'warning', queue: 'Annual Review', item: 'Audited financial statements pending', clientId: 'jkl', sla: 'Today', owner: 'RM Team', status: 'Open' },
  { severity: 'warning', queue: 'Facility Renewal', item: 'Renewal actions due before month-end', clientId: 'stu', sla: 'This week', owner: 'Commercial RM', status: 'Open' },
  { severity: 'warning', queue: 'Treasury', item: 'Unhedged USD payment exposure', clientId: 'abc', sla: '1 day', owner: 'Treasury', status: 'In review' },
  { severity: 'info', queue: 'Sales Control', item: 'Receivables financing proposal awaiting customer confirmation', clientId: 'ghi', sla: '3 days', owner: 'Commercial RM', status: 'Pending' }
];

const opsApprovalQueue = [
  { type: 'Credit', clientId: 'ghi', product: 'Receivables Financing', amount: 'RM12.0m', probability: 68, stage: 'Credit Review', sla: '18 Jul 2026' },
  { type: 'Credit', clientId: 'jkl', product: 'Limit Renewal', amount: 'RM15.2m', probability: 42, stage: 'Info Required', sla: '22 Jul 2026' },
  { type: 'Sales', clientId: 'abc', product: 'Trade Finance', amount: 'RM220k', probability: 78, stage: 'Negotiation', sla: 'This week' },
  { type: 'Credit', clientId: 'def', product: 'Inventory Financing', amount: 'RM3.5m', probability: 50, stage: 'Submitted', sla: '15 Jul 2026' }
];

const opsRelationshipActions = [
  ['Today', 'Call high-risk borrowers', 'MNO Construction and YZA Engineering require repayment and project-status validation'],
  ['Today', 'Collect annual review documents', 'JKL Food Processing audited statements and VWX receivable ageing are still pending'],
  ['This week', 'Prepare Treasury discussion', 'ABC Manufacturing, GHI Exporters and STU Packaging show USD flow opportunities'],
  ['This week', 'Review renewal pipeline', 'DEF Retail Trading and STU Packaging have renewal actions before month-end']
];

const meetingPrepItems = [
  { clientId: 'abc', meeting: 'Treasury FX proposal', when: 'Today 10:30 AM', focus: 'Bring latest USD receivable trend and hedge utilisation.' },
  { clientId: 'jkl', meeting: 'Annual review', when: 'Today 2:00 PM', focus: 'Confirm audited financial statements and limit renewal gap.' },
  { clientId: 'mno', meeting: 'Project site visit', when: 'Tomorrow', focus: 'Validate progress claims, repayment plan and covenant pressure.' }
];

const callPackItems = [
  { clientId: 'abc', status: 'Ready', label: 'Prep', note: 'Open with receivables volatility, then position FX forward cover and cash visibility.', detail: '2 product angles' },
  { clientId: 'jkl', status: 'Needs docs', label: 'Gap', note: 'Anchor conversation on annual review documents before discussing working-capital buffer.', detail: 'Audited FS pending' }
];

const facilityRenewalItems = [
  { clientId: 'jkl', facility: 'Limit Renewal', exposure: 'RM15.2m', due: '22 Jul 2026', action: 'Collect audited FS and update repayment assumptions.' },
  { clientId: 'def', facility: 'Inventory Financing', exposure: 'RM3.5m', due: '15 Jul 2026', action: 'Confirm campaign inventory cycle and sell-through forecast.' },
  { clientId: 'stu', facility: 'Trade Line Renewal', exposure: 'RM4.8m', due: '24 Jul 2026', action: 'Prepare renewal terms and trade utilisation summary.' },
  { clientId: 'abc', facility: 'Trade Finance', exposure: 'RM220k', due: 'This week', action: 'Prepare renewal terms with FX package recommendation.' }
];

const covenantTrackerItems = [
  { clientId: 'mno', control: 'DSCR and repayment conduct', status: 'Breach risk', due: 'Today', action: 'Arrange urgent site visit and credit review.' },
  { clientId: 'jkl', control: 'Annual financial submission', status: 'Pending', due: '3 days', action: 'Chase audited statements before renewal memo.' },
  { clientId: 'vwx', control: 'Receivable ageing', status: 'Monitor', due: 'Next review', action: 'Request updated ageing and payer concentration split.' }
];

const customerDocumentRequestItems = [
  { clientId: 'jkl', document: 'Audited financial statements', status: 'Pending', owner: 'Client CFO', purpose: 'Annual review and limit renewal.' },
  { clientId: 'mno', document: 'Progress claim certificate', status: 'Required', owner: 'Project director', purpose: 'Credit validation before drawdown decision.' },
  { clientId: 'abc', document: 'Board resolution', status: 'Draft received', owner: 'Relationship team', purpose: 'Treasury onboarding pack.' },
  { clientId: 'vwx', document: 'Receivable ageing schedule', status: 'Pending', owner: 'Finance manager', purpose: 'Invoice financing review.' }
];

const newToBankOpportunityNames = ['PQR Logistics', 'STU Packaging', 'VWX Healthcare Supplies', 'YZA Engineering', 'BCD Digital Services'];

const customerNameOverrides = {
  abc: ['Apex Meridian Industries Sdn. Bhd.', 'Apex Meridian Industries'],
  def: ['DayaVista Retail Holdings Sdn. Bhd.', 'DayaVista Retail'],
  ghi: ['Global Halcyon Exports Berhad', 'Global Halcyon Exports'],
  jkl: ['Jelita Kencana Foods Sdn. Bhd.', 'Jelita Kencana Foods'],
  mno: ['Murni Nusantara Construction Sdn. Bhd.', 'Murni Nusantara Construction'],
  pqr: ['Pacific Quest Logistics Sdn. Bhd.', 'Pacific Quest Logistics'],
  stu: ['Straits United Packaging Sdn. Bhd.', 'Straits United Packaging'],
  vwx: ['VistaWell Healthcare Supplies Sdn. Bhd.', 'VistaWell Healthcare Supplies'],
  yza: ['Yakin Zaman Engineering Sdn. Bhd.', 'Yakin Zaman Engineering'],
  bcd: ['Borneo Crest Agro Trading Sdn. Bhd.', 'Borneo Crest Agro Trading']
};

const legacyCustomerNamePairs = [
  ['ABC Manufacturing Sdn. Bhd.', 'Apex Meridian Industries Sdn. Bhd.'],
  ['ABC Manufacturing', 'Apex Meridian Industries'],
  ['ABC Sdn Bhd', 'Apex Meridian Industries'],
  ['ABC Berhad', 'Apex Meridian Industries'],
  ['DEF Retail Trading Sdn. Bhd.', 'DayaVista Retail Holdings Sdn. Bhd.'],
  ['DEF Retail Trading', 'DayaVista Retail'],
  ['DEF Retail', 'DayaVista Retail'],
  ['GHI Exporters Berhad', 'Global Halcyon Exports Berhad'],
  ['GHI Exporters', 'Global Halcyon Exports'],
  ['JKL Food Processing Sdn. Bhd.', 'Jelita Kencana Foods Sdn. Bhd.'],
  ['JKL Food Processing', 'Jelita Kencana Foods'],
  ['MNO Construction Group Sdn. Bhd.', 'Murni Nusantara Construction Sdn. Bhd.'],
  ['MNO Construction', 'Murni Nusantara Construction'],
  ['PQR Logistics Sdn. Bhd.', 'Pacific Quest Logistics Sdn. Bhd.'],
  ['PQR Logistics', 'Pacific Quest Logistics'],
  ['STU Packaging Sdn. Bhd.', 'Straits United Packaging Sdn. Bhd.'],
  ['STU Packaging', 'Straits United Packaging'],
  ['VWX Healthcare Supplies Sdn. Bhd.', 'VistaWell Healthcare Supplies Sdn. Bhd.'],
  ['VWX Healthcare Supplies', 'VistaWell Healthcare Supplies'],
  ['YZA Engineering Sdn. Bhd.', 'Yakin Zaman Engineering Sdn. Bhd.'],
  ['YZA Engineering', 'Yakin Zaman Engineering'],
  ['BCD Agro Trading Sdn. Bhd.', 'Borneo Crest Agro Trading Sdn. Bhd.'],
  ['BCD Digital Services', 'Borneo Crest Digital Services'],
  ['BCD Agro Trading', 'Borneo Crest Agro Trading']
];

function remapLegacyCustomerText(value) {
  return legacyCustomerNamePairs.reduce(
    (text, [legacy, replacement]) => text.replaceAll(legacy, replacement),
    String(value)
  );
}

function remapLegacyCustomerValue(value) {
  if (typeof value === 'string') return remapLegacyCustomerText(value);
  if (Array.isArray(value)) return value.map(remapLegacyCustomerValue);
  if (value && typeof value === 'object') {
    Object.keys(value).forEach(key => {
      value[key] = remapLegacyCustomerValue(value[key]);
    });
  }
  return value;
}

customers.forEach(customer => {
  remapLegacyCustomerValue(customer);
  const override = customerNameOverrides[customer.id];
  if (override) {
    customer.name = override[0];
    customer.shortName = override[1];
  }
});

[
  creditDeals,
  salesOpps,
  tasks,
  alerts,
  documents,
  activities,
  dashboardPriorityItems,
  marketSignals,
  upcomingMeetings,
  opsExceptionQueue,
  opsApprovalQueue,
  opsRelationshipActions,
  meetingPrepItems,
  callPackItems,
  facilityRenewalItems,
  covenantTrackerItems,
  customerDocumentRequestItems,
  relationshipAppointments
].forEach(remapLegacyCustomerValue);

newToBankOpportunityNames.splice(
  0,
  newToBankOpportunityNames.length,
  ...newToBankOpportunityNames.map(remapLegacyCustomerText)
);

function customerById(id) {
  return customers.find(customer => customer.id === id) || customers[0];
}

function statusBadgeClass(value) {
  const clean = String(value).toLowerCase();
  if (clean.includes('escalated') || clean.includes('critical') || clean.includes('high')) return 'ops-badge-red';
  if (clean.includes('review') || clean.includes('open') || clean.includes('pending') || clean.includes('warning')) return 'ops-badge-amber';
  return 'ops-badge-green';
}

function setKpiByLabel(label, values) {
  const [value, helperText, trendText, trendClass] = values;
  const card = findDashboardKpiCard(label);
  if (!card) return;
  const valueEl = card.querySelector('strong');
  const helperEl = card.querySelector('p');
  const trendEl = card.querySelector('.kpi-bottom small');
  if (valueEl) valueEl.textContent = value;
  if (helperEl) helperEl.textContent = helperText;
  if (trendEl) {
    trendEl.textContent = trendText;
    trendEl.className = trendClass;
  }
}

function renderDashboardKpis() {
  const metrics = {
    today: {
      customers: [String(customers.length), 'Active commercial customers', '2 exceptions open', 'trend-down'],
      exposure: ['RM194.7m', 'Approved exposure monitored', 'RM49.7m high-risk', 'trend-down'],
      deposits: ['RM70.9m', 'Operating balances', '-RM2.1m today', 'trend-down'],
      health: ['74 / 100', 'Weighted portfolio risk score', 'Watchlist bias', 'trend-down'],
      revenue: ['RM0.42m', 'Revenue booked today', '3 pending fee events', 'trend-light']
    },
    mtd: {
      customers: [String(customers.length), 'Customers reviewed MTD', `${customers.length} / ${customers.length} completed`, 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+RM4.2m MTD', 'trend-up'],
      deposits: ['RM70.9m', 'Average operating balances', '-1.8% MTD', 'trend-down'],
      health: ['76 / 100', 'Weighted portfolio risk score', '2 watchlist cases', 'trend-down'],
      revenue: ['RM4.8m', 'Relationship revenue MTD', '+7.2% vs run-rate', 'trend-light']
    },
    ytd: {
      customers: [String(customers.length), 'Active commercial customers', '+1 net new YTD', 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+6.2% YTD', 'trend-up'],
      deposits: ['RM70.9m', 'CASA and deposits', '-3.0% YTD', 'trend-down'],
      health: ['78 / 100', 'Weighted portfolio risk score', 'Stable trend', 'trend-up'],
      revenue: ['RM18.7m', 'Relationship revenue YTD', '+8.5% YTD', 'trend-light']
    }
  }[activeDashboardPeriod] || {};

  setKpiByLabel('Total Customers', metrics.customers);
  setKpiByLabel('Total Credit Exposure', metrics.exposure);
  setKpiByLabel('Deposit Balance', metrics.deposits);
  setKpiByLabel('Portfolio Health', metrics.health);
  setKpiByLabel('Revenue Contribution', metrics.revenue);

  const label = document.getElementById('dashboardViewLabel');
  if (label) label.querySelector('strong').textContent = periodLabel(activeDashboardPeriod);
}

function renderCustomerKpiRows(list = customers) {
  return `
    <div class="kpi-detail-table">
      ${list.map(customer => `
        <button type="button" class="kpi-detail-row" data-customer-id="${customer.id}">
          <span>${getCustomerShortName(customer)}</span>
          <small>${customer.industry} / ${customer.segment}</small>
          <b>${customer.status} ${customer.health}</b>
        </button>
      `).join('')}
    </div>
  `;
}

function renderExceptionSummaryRows(limit = 2) {
  return `
    <div class="kpi-detail-table">
      ${opsExceptionQueue.slice(0, limit).map((item, index) => {
        const customer = customerById(item.clientId);
        return `
          <button type="button" class="kpi-detail-row" data-exception-index="${index}">
            <span>${getCustomerShortName(customer)}</span>
            <small>${item.queue}: ${item.item}</small>
            <b>${item.sla}</b>
          </button>
        `;
      }).join('')}
    </div>
  `;
}

function sumCustomerValue(field) {
  return customers.reduce((sum, customer) => sum + Number(customer[field] || 0), 0).toFixed(1);
}

function openKpiDetail(key) {
  const highRiskCustomers = customers.filter(customer => customer.health < 60);
  const watchlistCustomers = customers.filter(customer => customer.health >= 60 && customer.health < 80);
  const healthyCustomers = customers.filter(customer => customer.health >= 80);

  const details = {
    customers: {
      title: 'Total Customers',
      intro: `${customers.length} active commercial customers are currently monitored in this RM portfolio.`,
      body: `
        <section class="detail-section">
          <strong>Customer summary</strong>
          ${renderCustomerKpiRows(customers)}
        </section>
        <section class="detail-section">
          <strong>2 exception focus items</strong>
          ${renderExceptionSummaryRows(2)}
        </section>
      `
    },
    exposure: {
      title: 'Total Credit Exposure',
      intro: `Approved exposure monitored across the portfolio is RM${sumCustomerValue('exposureValue')}m.`,
      body: `
        <section class="detail-section">
          <strong>Largest exposure customers</strong>
          ${renderCustomerKpiRows([...customers].sort((a, b) => b.exposureValue - a.exposureValue).slice(0, 5))}
        </section>
        <section class="detail-section">
          <strong>Credit watch points</strong>
          ${renderDetailList(['RM49.7m is linked to high-risk or at-risk customers.', 'Facilities above 80% utilisation should be reviewed before renewal.', 'Credit and document exceptions are routed to the exception queue.'])}
        </section>
      `
    },
    deposits: {
      title: 'Deposit Balance',
      intro: `Operating balances total RM${sumCustomerValue('depositValue')}m across active customers.`,
      body: `
        <section class="detail-section">
          <strong>Deposit holdings by customer</strong>
          ${renderCustomerKpiRows([...customers].sort((a, b) => b.depositValue - a.depositValue).slice(0, 5))}
        </section>
        <section class="detail-section">
          <strong>Balance movement notes</strong>
          ${renderDetailList(['ABC Manufacturing shows fast outbound supplier payments after collections.', 'Construction and engineering customers have weaker retained balances.', 'Treasury and cash-management opportunities should be reviewed with deposit attrition.'])}
        </section>
      `
    },
    health: {
      title: 'Portfolio Health',
      intro: `Current health mix: ${healthyCustomers.length} healthy, ${watchlistCustomers.length} watchlist, ${highRiskCustomers.length} high risk.`,
      body: `
        <div class="export-metric-grid exception-detail-grid">
          <div><span>Healthy</span><strong>${healthyCustomers.length}</strong></div>
          <div><span>Watchlist</span><strong>${watchlistCustomers.length}</strong></div>
          <div><span>High risk</span><strong>${highRiskCustomers.length}</strong></div>
          <div><span>Weighted score</span><strong>74 / 100</strong></div>
        </div>
        <section class="detail-section">
          <strong>Customers requiring attention</strong>
          ${renderCustomerKpiRows([...highRiskCustomers, ...watchlistCustomers].slice(0, 6))}
        </section>
      `
    },
    revenue: {
      title: 'Revenue Contribution',
      intro: 'Revenue contribution is tracked by product activity, booked fees and relationship value uplift.',
      body: `
        <div class="export-metric-grid exception-detail-grid">
          <div><span>Today</span><strong>RM0.42m</strong></div>
          <div><span>MTD</span><strong>RM4.8m</strong></div>
          <div><span>YTD</span><strong>RM18.7m</strong></div>
          <div><span>Pending fees</span><strong>3</strong></div>
        </div>
        <section class="detail-section">
          <strong>Revenue drivers</strong>
          ${renderDetailList(['Treasury FX package for ABC Manufacturing.', 'Receivables financing opportunity for GHI Exporters.', 'Cash management and inventory financing for DEF Retail Trading.'])}
        </section>
      `
    }
  };

  const detail = details[key];
  if (!detail) return;

  openDetailModal({
    kicker: 'Dashboard KPI',
    title: detail.title,
    body: `
      <section class="detail-section">
        <p>${detail.intro}</p>
      </section>
      ${detail.body}
    `
  });
}

function renderDashboardPriorities() {
  const target = document.getElementById('dashboardInsights');
  if (!target) return;
  const severityFilter = document.getElementById('exceptionSeverityFilter')?.value || 'All';
  const statusFilter = document.getElementById('exceptionStatusFilter')?.value || 'All';
  const filteredItems = opsExceptionQueue.filter(item => {
    const severityMatch = severityFilter === 'All' || item.severity === severityFilter;
    const statusMatch = statusFilter === 'All' || item.status === statusFilter;
    return severityMatch && statusMatch;
  });

  target.innerHTML = `
    <div class="compact-review-list">
      ${filteredItems.length ? filteredItems.map(item => {
        const customer = customerById(item.clientId);
        const index = opsExceptionQueue.indexOf(item);
        return `
          <button type="button" class="compact-review-card exception-review-card" data-exception-index="${index}">
            <div class="compact-review-top">
              <span class="ops-severity ${item.severity}">${item.severity}</span>
              <span class="ops-badge ${statusBadgeClass(item.status)}">${item.status}</span>
            </div>
            <strong>${getCustomerShortName(customer)}</strong>
            <p>${item.queue}: ${item.item}</p>
            <small>SLA ${item.sla}</small>
          </button>
        `;
      }).join('') : '<p class="table-note">No review items match the selected filters.</p>'}
    </div>
  `;
}

function openExceptionDetail(index) {
  const item = opsExceptionQueue[index];
  if (!item) return;

  const customer = customerById(item.clientId);
  openDetailModal({
    kicker: 'Exception Queue',
    title: `${item.queue}: ${getCustomerShortName(customer)}`,
    body: `
      <section class="detail-section">
        <strong>Item requiring review</strong>
        <p>${item.item}</p>
      </section>
      <div class="export-metric-grid exception-detail-grid">
        <div><span>Customer</span><strong>${customer.name}</strong></div>
        <div><span>SLA</span><strong>${item.sla}</strong></div>
        <div><span>Owner</span><strong>${item.owner}</strong></div>
        <div><span>Status</span><strong>${item.status}</strong></div>
      </div>
      <section class="detail-section">
        <strong>Risk context</strong>
        <p>${customer.aiSignal}. Current exposure is ${customer.exposure}; deposit holdings are ${customer.deposits}; internal rating is ${customer.internalRating}.</p>
      </section>
      <section class="detail-section">
        <strong>Recommended actions</strong>
        ${renderDetailList([customer.nextAction, 'Record RM call note after customer contact', 'Escalate to Credit Risk if the customer confirms additional stress indicators'])}
      </section>
      <div class="modal-action-row">
        <button type="button" class="btn secondary" data-modal-cancel>Close</button>
        <button type="button" class="btn primary" data-customer-id="${customer.id}">Open Customer 360</button>
      </div>
    `
  });
}

function renderMarketSignals() {
  const target = document.getElementById('recentActivities');
  if (!target) return;

  const expandOperationalImpact = text => String(text)
    .replace(/\bJKL\b/g, 'Jelita Kencana Foods')
    .replace(/\bGHI\b/g, 'Global Halcyon Exports')
    .replace(/\bABC\b/g, 'Apex Meridian Industries')
    .replace(/\bDEF\b/g, 'DayaVista Retail')
    .replace(/\bMNO\b/g, 'Murni Nusantara Construction');

  target.innerHTML = `
    <div class="ops-table-wrap">
      <table class="ops-table">
        <thead>
          <tr>
            <th>Signal</th>
            <th>Affected Clients</th>
            <th>Operational Impact</th>
            <th>Source</th>
          </tr>
        </thead>
        <tbody>
          ${marketSignals.slice(0, 5).map((signal, index) => `
            <tr class="market-signal-row" data-market-row-index="${index}" tabindex="0">
              <td>
                <strong>${signal.title}</strong>
                <small class="signal-sector">${signal.industry}</small>
              </td>
              <td>${renderCustomerLogoStack(signal.clientIds)}</td>
              <td>${expandOperationalImpact(signal.impact)}</td>
              <td>
                <a class="source-icon-box" href="${signal.url}" target="_blank" rel="noopener noreferrer" aria-label="Open source for ${signal.title}">&#8599;</a>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderDashboardMeetings() {
  const target = document.getElementById('dashboardMeetings');
  if (!target) return;

  target.innerHTML = `
    <div class="ops-table-wrap">
      <table class="ops-table ops-approval-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Client</th>
            <th>Product</th>
            <th>Amount</th>
            <th>Stage</th>
            <th>Probability</th>
            <th>SLA</th>
          </tr>
        </thead>
        <tbody>
          ${opsApprovalQueue.map(item => {
            const customer = customerById(item.clientId);
            return `
              <tr>
                <td>${item.type}</td>
                <td><button class="ops-link" data-customer-id="${customer.id}">${getCustomerShortName(customer)}</button></td>
                <td>${item.product}</td>
                <td>${item.amount}</td>
                <td><span class="ops-badge ${statusBadgeClass(item.stage)}">${item.stage}</span></td>
                <td>
                  <span class="${probabilityClass(item.probability)}-text">${item.probability}%</span>
                  <div class="ops-progress ${probabilityClass(item.probability)}"><div style="width:${item.probability}%"></div></div>
                </td>
                <td>${item.sla}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderDashboardAnalytics() {
  const riskCounts = customers.reduce((acc, customer) => {
    if (customer.health >= 80) acc.Healthy += 1;
    else if (customer.health >= 60) acc.Watchlist += 1;
    else acc['High Risk'] += 1;
    return acc;
  }, { Healthy: 0, Watchlist: 0, 'High Risk': 0 });
  const totalCustomers = customers.length || 1;
  const riskDistribution = [
    ['Healthy', riskCounts.Healthy, (riskCounts.Healthy / totalCustomers) * 100],
    ['Watchlist', riskCounts.Watchlist, (riskCounts.Watchlist / totalCustomers) * 100],
    ['High Risk', riskCounts['High Risk'], (riskCounts['High Risk'] / totalCustomers) * 100]
  ];
  const exposure = [['Working Capital', 'RM41.5m', 34], ['Term Loan', 'RM31.0m', 25], ['Trade Finance', 'RM26.4m', 22], ['Treasury / FX', 'RM8.2m', 7]];
  const workflow = [['Draft', 3], ['Submitted', 3], ['Credit Review', 2], ['Info Required', 2], ['Approved', 2], ['Disbursed', 2]];

  const portfolioMixEl = document.getElementById('dashboardPortfolioMix');
  if (portfolioMixEl) {
    portfolioMixEl.innerHTML = riskDistribution.map(([label, count, value]) => `
      <div class="ops-metric-row">
        <span>${label}</span>
        <strong>${count}</strong>
        <div class="ops-progress ${label === 'High Risk' ? 'prob-low' : label === 'Watchlist' ? 'prob-medium' : 'prob-high'}"><div style="width:${value}%"></div></div>
      </div>
    `).join('');
  }

  const productExposureEl = document.getElementById('dashboardProductExposure');
  if (productExposureEl) {
    productExposureEl.innerHTML = exposure.map(([label, amount, value]) => `
      <div class="ops-metric-row">
        <span>${label}</span>
        <strong>${amount}</strong>
        <div class="ops-progress prob-high"><div style="width:${value}%"></div></div>
      </div>
    `).join('');
  }

  const dealMovementEl = document.getElementById('dashboardDealMovement');
  if (dealMovementEl) {
    const maxWorkflow = Math.max(...workflow.map(([, count]) => count));
    dealMovementEl.innerHTML = workflow.map(([label, count]) => `
      <div class="ops-stage-row">
        <div>
          <span>${label}</span>
          <strong>${count}</strong>
        </div>
        <div class="ops-progress ${count >= 3 ? 'prob-high' : count === 2 ? 'prob-medium' : 'prob-low'}"><div style="width:${(count / maxWorkflow) * 100}%"></div></div>
      </div>
    `).join('');
  }

  const rmPerformanceEl = document.getElementById('dashboardRMPerformance');
  if (rmPerformanceEl) {
    rmPerformanceEl.innerHTML = opsRelationshipActions.map(([time, action, detail]) => `
      <div class="ops-audit-row">
        <time>${time}</time>
        <div><strong>${action}</strong><span>${detail}</span></div>
      </div>
    `).join('');
  }
}

function renderDashboard() {
  renderDashboardKpis();

  const riskFilter = document.getElementById('dashboardRiskFilter')?.value || 'All';
  const dashboardCustomers = [...customers]
    .filter(customer => {
      if (riskFilter === 'High Risk') return customer.health < 60;
      if (riskFilter === 'Watchlist') return customer.health >= 60 && customer.health < 80;
      if (riskFilter === 'Healthy') return customer.health >= 80;
      return true;
    });

  document.getElementById('dashboardCustomerRows').innerHTML = dashboardCustomers
    .sort((a, b) => a.health - b.health)
    .map(customer => `
      <tr data-customer-id="${customer.id}">
        <td>
          <button class="customer-button ops-link" data-customer-id="${customer.id}">
            <div class="customer-name-block">
              <strong>${getCustomerShortName(customer)}</strong>
              <small>BRN ${customer.brn} / ${customer.industry}</small>
            </div>
          </button>
        </td>
        <td>${customer.exposure}</td>
        <td><span class="ops-badge ${customer.health < 60 ? 'ops-badge-red' : customer.health < 80 ? 'ops-badge-amber' : 'ops-badge-green'}">${customer.status} ${customer.health}</span></td>
        <td>
          <div class="next-action-clean">
            <strong>${customer.nextAction}</strong>
          </div>
        </td>
      </tr>
    `)
    .join('') || '<tr><td colspan="4">No customers match the selected risk tier.</td></tr>';

  renderDashboardPriorities();
  renderMarketSignals();
  renderDashboardMeetings();
  renderDashboardAnalytics();
}

function rotateSearchPlaceholder() {
  const prompts = [
    'Search customer, case, alert or document...',
    'Search BRN or customer name',
    'Find overdue approvals',
    'Show high-risk customers',
    'Search expiring facilities',
    'Find pending documents'
  ];

  let index = 0;

  setInterval(() => {
    if (!globalSearchInput) return;
    if (document.activeElement === globalSearchInput) return;

    index = (index + 1) % prompts.length;
    globalSearchInput.placeholder = prompts[index];
  }, 2600);
}

function openMarketDetail(index) {
  const item = marketSignals[index];
  if (!item) return;
  const affectedCustomers = (item.clientIds || [])
    .map(id => customerById(id))
    .filter(Boolean);
  const impact = item.impact || item.text || item.summary;
  const customerImpactRows = affectedCustomers.length
    ? affectedCustomers.map(customer => `
      <div class="market-impact-row">
        <strong>${customer.name}</strong>
        <span>${customer.industry} / ${customer.segment}</span>
        <p>${customer.aiSignal}</p>
      </div>
    `).join('')
    : `<p>${item.clients || 'No specific client tagged.'}</p>`;

  openDetailModal({
    kicker: 'Market & Risk Signals',
    title: item.title,
    body: `
      <section class="detail-section">
        <strong>News detail</strong>
        <p>${item.summary}</p>
        <p>${item.text || ''}</p>
      </section>
      <section class="detail-section">
        <strong>Portfolio clients affected</strong>
        <div class="linked-client-list">${renderCustomerLinks(item.clientIds)}</div>
      </section>
      <section class="detail-section">
        <strong>Operational impact</strong>
        <p>${impact}</p>
        <div class="market-impact-list">${customerImpactRows}</div>
      </section>
      <section class="detail-section">
        <strong>Credit and relationship considerations</strong>
        ${renderDetailList([
          `Industry affected: ${item.industry}.`,
          'Check whether the signal changes customer cash-flow timing, margin pressure or facility utilisation.',
          'Prioritise outreach where the signal overlaps with a renewal, document request, FX exposure or declining deposits.',
          'Document RM validation before escalating as a formal credit concern.'
        ])}
      </section>
      <section class="detail-section">
        <strong>Recommended actions</strong>
        ${renderDetailList(item.actions)}
      </section>
    `
  });
}

function customerRiskLabel(customer) {
  if (customer.health >= 80) return 'Healthy';
  if (customer.health >= 70) return 'Monitor';
  if (customer.health >= 55) return 'At Risk';
  return 'High Risk';
}

function riskToneClass(customerOrLabel) {
  const label = typeof customerOrLabel === 'string' ? customerOrLabel : customerRiskLabel(customerOrLabel);
  const lower = label.toLowerCase();
  if (lower.includes('healthy') || lower.includes('stable')) return 'risk-green';
  if (lower.includes('monitor') || lower.includes('watchlist')) return 'risk-orange';
  return 'risk-red';
}

function renderDashboardKpis() {
  const metrics = {
    today: {
      customers: [String(customers.length), 'Active commercial customers', '2 exceptions open', 'trend-down'],
      exposure: ['RM194.7m', 'Approved exposure monitored', 'RM49.7m high-risk', 'trend-down'],
      deposits: ['RM70.9m', 'Operating balances', '-RM2.1m today', 'trend-down'],
      health: ['74 / 100', 'Weighted portfolio risk score', 'Watchlist bias', 'trend-down'],
      revenue: ['RM0.42m', 'Revenue booked today', '3 pending fee events', 'trend-light']
    },
    mtd: {
      customers: [String(customers.length), 'Customers reviewed MTD', `${customers.length} / ${customers.length} completed`, 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+RM4.2m MTD', 'trend-up'],
      deposits: ['RM70.9m', 'Average operating balances', '-1.8% MTD', 'trend-down'],
      health: ['76 / 100', 'Weighted portfolio risk score', '2 watchlist cases', 'trend-down'],
      revenue: ['RM4.8m', 'Relationship revenue MTD', '+7.2% vs run-rate', 'trend-light']
    },
    '3m': {
      customers: [String(customers.length), 'Customers reviewed over 3M', '8 high-touch customers', 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+RM9.8m over 3M', 'trend-up'],
      deposits: ['RM70.9m', 'Average operating balances', '-2.4% over 3M', 'trend-down'],
      health: ['77 / 100', 'Weighted portfolio risk score', '3 monitor cases', 'trend-down'],
      revenue: ['RM7.4m', 'Relationship revenue 3M', '+6.4% vs prior 3M', 'trend-light']
    },
    '6m': {
      customers: [String(customers.length), 'Customers reviewed over 6M', '6 reviews completed', 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+RM14.6m over 6M', 'trend-up'],
      deposits: ['RM70.9m', 'CASA and deposits', '-3.0% over 6M', 'trend-down'],
      health: ['77 / 100', 'Weighted portfolio risk score', 'Stable with watchlist bias', 'trend-down'],
      revenue: ['RM18.7m', 'Revenue over 6M', '+8.5% vs prior 6M', 'trend-light']
    },
    ytd: {
      customers: [String(customers.length), 'Active commercial customers', '+1 net new YTD', 'trend-up'],
      exposure: ['RM194.7m', 'Approved exposure monitored', '+6.2% YTD', 'trend-up'],
      deposits: ['RM70.9m', 'CASA and deposits', '-3.0% YTD', 'trend-down'],
      health: ['78 / 100', 'Weighted portfolio risk score', 'Stable trend', 'trend-up'],
      revenue: ['RM18.7m', 'Relationship revenue YTD', '+8.5% YTD', 'trend-light']
    }
  }[activeDashboardPeriod] || {};

  setKpiByLabel('Total Customers', metrics.customers);
  setKpiByLabel('Total Credit Exposure', metrics.exposure);
  setKpiByLabel('Deposit Balance', metrics.deposits);
  setKpiByLabel('Portfolio Health', metrics.health);
  setKpiByLabel('Revenue Contribution', metrics.revenue);

  const label = document.getElementById('dashboardViewLabel');
  if (label) label.querySelector('strong').textContent = periodLabel(activeDashboardPeriod);
}

function renderCustomerKpiRows(list = customers, amountField = '') {
  return `
    <div class="kpi-detail-table">
      ${list.map(customer => {
        const amount = amountField ? `<em>${amountField === 'exposureValue' ? customer.exposure : customer.deposits}</em>` : '';
        const riskLabel = `${customerRiskLabel(customer)} ${customer.health}`;
        return `
          <button type="button" class="kpi-detail-row" data-customer-id="${customer.id}">
            <span>${getCustomerShortName(customer)}</span>
            <small>${customer.industry} / ${customer.segment}</small>
            ${amount}
            <b class="${riskToneClass(customer)}">${riskLabel}</b>
          </button>
        `;
      }).join('')}
    </div>
  `;
}

function openKpiDetail(key) {
  const highRiskCustomers = customers.filter(customer => customer.health < 60);
  const watchlistCustomers = customers.filter(customer => customer.health >= 60 && customer.health < 80);
  const healthyCustomers = customers.filter(customer => customer.health >= 80);
  const feeItems = [
    ['Apex Meridian Industries', 'Treasury onboarding fee', 'RM120k'],
    ['Global Halcyon Exports', 'Receivables financing arrangement fee', 'RM180k'],
    ['DayaVista Retail', 'Cash management setup fee', 'RM120k']
  ];

  const details = {
    customers: {
      title: 'Total Customers',
      intro: `${customers.length} active commercial customers are currently monitored in this RM portfolio.`,
      body: `
        <section class="detail-section">
          <strong>Customer summary</strong>
          ${renderCustomerKpiRows(customers)}
        </section>
        <section class="detail-section">
          <strong>2 exception focus items</strong>
          ${renderExceptionSummaryRows(2)}
        </section>
      `
    },
    exposure: {
      title: 'Total Credit Exposure',
      intro: `Approved exposure monitored across the portfolio is RM${sumCustomerValue('exposureValue')}m.`,
      body: `
        <section class="detail-section">
          <strong>Largest exposure customers</strong>
          ${renderCustomerKpiRows([...customers].sort((a, b) => b.exposureValue - a.exposureValue).slice(0, 5), 'exposureValue')}
        </section>
        <section class="detail-section">
          <strong>Credit watch points</strong>
          ${renderDetailList(['RM49.7m is linked to high-risk or at-risk customers.', 'Facilities above 80% utilisation should be reviewed before renewal.', 'Credit and document exceptions are routed to the exception queue.'])}
        </section>
      `
    },
    deposits: {
      title: 'Deposit Balance',
      intro: `Operating balances total RM${sumCustomerValue('depositValue')}m across active customers.`,
      body: `
        <section class="detail-section">
          <strong>Deposit holdings by customer</strong>
          ${renderCustomerKpiRows([...customers].sort((a, b) => b.depositValue - a.depositValue).slice(0, 5), 'depositValue')}
        </section>
        <section class="detail-section">
          <strong>Balance movement notes</strong>
          ${renderDetailList(['Apex Meridian Industries shows fast outbound supplier payments after collections.', 'Construction and engineering customers have weaker retained balances.', 'Treasury and cash-management opportunities should be reviewed with deposit attrition.'])}
        </section>
      `
    },
    health: {
      title: 'Portfolio Health',
      intro: `Current health mix: ${healthyCustomers.length} healthy, ${watchlistCustomers.length} monitor/watchlist, ${highRiskCustomers.length} high risk.`,
      body: `
        <div class="export-metric-grid exception-detail-grid">
          <div><span>Healthy</span><strong>${healthyCustomers.length}</strong></div>
          <div><span>Monitor</span><strong>${watchlistCustomers.length}</strong></div>
          <div><span>High risk</span><strong>${highRiskCustomers.length}</strong></div>
          <div><span>Weighted score</span><strong>74 / 100</strong></div>
        </div>
        <section class="detail-section">
          <strong>Customers requiring attention</strong>
          ${renderCustomerKpiRows([...highRiskCustomers, ...watchlistCustomers].slice(0, 6))}
        </section>
      `
    },
    revenue: {
      title: 'Revenue Contribution',
      intro: 'Revenue contribution is tracked by product activity, booked fees and relationship value uplift.',
      body: `
        <div class="export-metric-grid exception-detail-grid">
          <div><span>Today</span><strong>RM0.42m</strong></div>
          <div><span>MTD</span><strong>RM4.8m</strong></div>
          <div><span>YTD</span><strong>RM18.7m</strong></div>
          <div><span>Pending fees</span><strong>3</strong></div>
        </div>
        <section class="detail-section">
          <strong>Pending fee events</strong>
          <div class="kpi-detail-table">
            ${feeItems.map(([company, fee, amount]) => `
              <div class="kpi-detail-row static-row">
                <span>${company}</span>
                <small>${fee}</small>
                <em>${amount}</em>
              </div>
            `).join('')}
          </div>
        </section>
        <section class="detail-section">
          <strong>Revenue drivers</strong>
          ${renderDetailList(['Treasury FX package for Apex Meridian Industries.', 'Receivables financing opportunity for Global Halcyon Exports.', 'Cash management and inventory financing for DayaVista Retail.'])}
        </section>
      `
    }
  };

  const detail = details[key];
  if (!detail) return;

  openDetailModal({
    kicker: 'Dashboard KPI',
    title: detail.title,
    body: `<section class="detail-section"><p>${detail.intro}</p></section>${detail.body}`
  });
}

function getNextBestDealItems() {
  return [
    {
      customerId: 'abc',
      deal: 'Treasury FX Package',
      value: 'RM3.5m',
      uplift: '+1.4%',
      type: 'Cross-sell',
      priority: 'High Priority',
      confidence: '86%',
      why: 'Recurring USD supplier payments detected, no existing FX hedging product, and estimated wallet share remains low at 10%.',
      step: 'Schedule FX advisory discussion before next supplier payment cycle.'
    },
    {
      customerId: 'ghi',
      deal: 'Trade Finance Facility',
      value: 'RM8.0m',
      uplift: '+2.1%',
      type: 'Trade Finance',
      priority: 'High Priority',
      confidence: '91%',
      why: 'Export transaction volume has increased, but current trade finance usage remains below industry benchmark.',
      step: 'Prepare trade facility proposal and add opportunity to pipeline.'
    },
    {
      customerId: 'def',
      deal: 'Cash Management Solution',
      value: 'RM2.2m',
      uplift: '+0.8%',
      type: 'Cash Management',
      priority: 'Medium Priority',
      confidence: '78%',
      why: 'High transaction frequency and fragmented payment flows suggest potential for payment automation and collections solution.',
      step: 'Generate cash management pitch and schedule follow-up meeting.'
    },
    {
      customerId: 'jkl',
      deal: 'Working Capital Renewal',
      value: 'RM5.5m',
      uplift: '+1.2%',
      type: 'Renewal',
      priority: 'High Priority',
      confidence: '82%',
      why: 'Facility renewal is due within 45 days and utilisation remains healthy, with potential to expand limit based on transaction activity.',
      step: 'Start renewal discussion and prepare updated credit review.'
    }
  ];
}

function getSortedNextBestDealItems() {
  return getNextBestDealItems()
    .map((item, sourceIndex) => ({
      ...item,
      sourceIndex,
      confidenceValue: Number(String(item.confidence).replace('%', '')) || 0,
      priorityRank: item.priority.includes('High') ? 2 : item.priority.includes('Medium') ? 1 : 0
    }))
    .sort((a, b) => (b.priorityRank - a.priorityRank) || (b.confidenceValue - a.confidenceValue));
}

function renderNextBestClientDeals() {
  const summaryTarget = document.getElementById('nextBestDealSummary');
  const listTarget = document.getElementById('nextBestDealList');
  if (!summaryTarget || !listTarget) return;

  const items = getSortedNextBestDealItems();
  summaryTarget.innerHTML = `
    <article><span>Total Pipeline Opportunity</span><strong>RM19.2m</strong></article>
    <article><span>Potential Portfolio Uplift</span><strong>+5.5%</strong></article>
    <article><span>High Priority Deals</span><strong>3</strong></article>
  `;

  listTarget.innerHTML = items.map((item, index) => {
    const customer = customerById(item.customerId);
    return `
      <article class="next-best-deal-card" data-next-best-index="${index}">
        <div class="next-best-card-head">
          <div>
            <strong>${customer.name}</strong>
            <span>${item.deal}</span>
          </div>
          <b>${item.value}</b>
        </div>
        <dl class="next-best-meta">
          <div><dt>Priority</dt><dd>${item.priority}</dd></div>
          <div><dt>AI Confidence</dt><dd>${item.confidence}</dd></div>
          <div><dt>Portfolio Uplift</dt><dd>${item.uplift}</dd></div>
        </dl>
        <p>${item.why}</p>
        <small>${item.step}</small>
        <div class="next-best-actions">
          <button type="button" data-next-best-action="pitch" data-next-best-index="${index}" title="Generate pitch" aria-label="Generate pitch"><svg class="icon"><use href="#i-documents"></use></svg></button>
          <button type="button" data-next-best-action="pipeline" data-next-best-index="${index}" title="Add to pipeline" aria-label="Add to pipeline"><svg class="icon"><use href="#i-pipeline"></use></svg></button>
          <button type="button" data-next-best-action="meeting" data-next-best-index="${index}" title="Schedule meeting" aria-label="Schedule meeting"><svg class="icon"><use href="#i-calendar"></use></svg></button>
          <button type="button" data-next-best-action="customer" data-next-best-index="${index}" title="View Customer 360" aria-label="View Customer 360"><svg class="icon"><use href="#i-customer"></use></svg></button>
        </div>
      </article>
    `;
  }).join('');
}

function renderDashboardAnalytics() {
  const riskCounts = customers.reduce((acc, customer) => {
    if (customer.health >= 80) acc.Healthy += 1;
    else if (customer.health >= 60) acc.Watchlist += 1;
    else acc['High Risk'] += 1;
    return acc;
  }, { Healthy: 0, Watchlist: 0, 'High Risk': 0 });
  const totalCustomers = customers.length || 1;
  const riskDistribution = [
    ['Healthy', riskCounts.Healthy, (riskCounts.Healthy / totalCustomers) * 100],
    ['Watchlist', riskCounts.Watchlist, (riskCounts.Watchlist / totalCustomers) * 100],
    ['High Risk', riskCounts['High Risk'], (riskCounts['High Risk'] / totalCustomers) * 100]
  ];
  const exposure = [['Working Capital', 'RM41.5m', 34], ['Term Loan', 'RM31.0m', 25], ['Trade Finance', 'RM26.4m', 22], ['Treasury / FX', 'RM8.2m', 7]];
  const workflow = [['Draft', 3], ['Submitted', 3], ['Credit Review', 2], ['Info Required', 2], ['Approved', 2], ['Disbursed', 2]];

  const portfolioMixEl = document.getElementById('dashboardPortfolioMix');
  if (portfolioMixEl) {
    portfolioMixEl.innerHTML = riskDistribution.map(([label, count, value]) => `
      <div class="ops-metric-row">
        <span>${label}</span>
        <strong>${count}</strong>
        <div class="ops-progress ${label === 'High Risk' ? 'prob-low' : label === 'Watchlist' ? 'prob-medium' : 'prob-high'}"><div style="width:${value}%"></div></div>
      </div>
    `).join('');
  }

  const productExposureEl = document.getElementById('dashboardProductExposure');
  if (productExposureEl) {
    productExposureEl.innerHTML = exposure.map(([label, amount, value]) => `
      <div class="ops-metric-row">
        <span>${label}</span>
        <strong>${amount}</strong>
        <div class="ops-progress prob-high"><div style="width:${value}%"></div></div>
      </div>
    `).join('');
  }

  const dealMovementEl = document.getElementById('dashboardDealMovement');
  if (dealMovementEl) {
    const maxWorkflow = Math.max(...workflow.map(([, count]) => count));
    dealMovementEl.innerHTML = workflow.map(([label, count]) => `
      <div class="ops-stage-row">
        <div><span>${label}</span><strong>${count}</strong></div>
        <div class="ops-progress ${count >= 3 ? 'prob-high' : count === 2 ? 'prob-medium' : 'prob-low'}"><div style="width:${(count / maxWorkflow) * 100}%"></div></div>
      </div>
    `).join('');
  }
}

function renderDashboard() {
  renderDashboardKpis();
  renderNextBestClientDeals();
  renderDashboardPriorities();
  renderMarketSignals();
  renderDashboardMeetings();
  renderDashboardAnalytics();
}

function renderPortfolio() {
  const search = document.getElementById('customerSearch')?.value.toLowerCase() || '';
  const segment = document.getElementById('segmentFilter')?.value || 'All';
  const industryValue = document.getElementById('industryFilter')?.value || 'All';
  const relationshipValue = document.getElementById('relationshipValueFilter')?.value || 'All';
  const riskRating = document.getElementById('riskRatingFilter')?.value || 'All';

  const filtered = customers.filter(customer => {
    const riskLabel = customerRiskLabel(customer);
    const matchesSearch = customer.name.toLowerCase().includes(search) || customer.industry.toLowerCase().includes(search) || String(customer.brn || '').includes(search);
    const matchesSegment = segment === 'All' || customer.segment === segment;
    const matchesIndustry = industryValue === 'All' || customer.industry === industryValue;
    const matchesValue = relationshipValue === 'All' || customer.relationshipValue === relationshipValue;
    const matchesRisk = riskRating === 'All' || riskLabel === riskRating || customer.status === riskRating;
    return matchesSearch && matchesSegment && matchesIndustry && matchesValue && matchesRisk;
  });

  const rowsTarget = document.getElementById('portfolioRows');
  if (!rowsTarget) return;

  rowsTarget.innerHTML = filtered.map(customer => `
    <tr data-customer-id="${customer.id}">
      <td><button class="customer-button" data-customer-id="${customer.id}">${customer.name}</button></td>
      <td>${customer.segment}</td>
      <td>${customer.industry}</td>
      <td>${customer.relationshipValue}</td>
      <td><span class="risk-status ${riskToneClass(customer)}">${customerRiskLabel(customer)}</span></td>
      <td>${customer.revenue}</td>
      <td>${customer.exposure}</td>
      <td>${customer.deposits}</td>
      <td>${customer.lastContact}</td>
      <td><span class="badge ${badgeClass(customer)}">${customer.health}</span></td>
    </tr>
  `).join('') || '<tr><td colspan="10">No customers match the selected filters.</td></tr>';
}

function renderCustomerRiskMonitor() {
  const target = document.getElementById('customerRiskMonitorContent');
  if (!target) return;

  const customer = selectedCustomer();
  const status = customerRiskLabel(customer);
  const confidence = customer.health >= 80 ? 88 : customer.health >= 60 ? 84 : 91;
  const utilisation = customer.health >= 80 ? '71%' : customer.health >= 60 ? '84%' : '91%';
  const keySignals = [
    customer.aiSignal,
    `Facility utilisation is currently around ${utilisation}`,
    customer.deposits.includes('RM') ? `Deposit holdings stand at ${customer.deposits}` : 'Deposit trend requires RM validation',
    customer.aiSummary[0]?.[0] || 'Relationship activity is being monitored',
    customer.industry ? `${customer.industry} outlook shows moderate pressure` : 'Industry outlook shows moderate pressure'
  ];
  const warnings = [
    ...(customer.ews || []).slice(0, 3),
    'Facility nearing renewal',
    'Covenant review due soon'
  ].slice(0, 4);
  const actions = [
    customer.nextAction,
    'Review upcoming facility renewal requirements',
    'Request latest management accounts',
    'Monitor repayment and utilisation trend over the next 30 days'
  ];

  target.innerHTML = `
    <div class="customer-risk-summary-grid">
      <article><span>Risk Status</span><strong class="${riskToneClass(customer)}">${status}</strong></article>
      <article><span>Risk Score</span><strong>${customer.health} / 100</strong></article>
      <article><span>AI Risk Confidence</span><strong>${confidence}%</strong></article>
    </div>
    <div class="customer-risk-detail-grid">
      <article>
        <h4>Key Risk Signals</h4>
        ${renderDetailList(keySignals)}
      </article>
      <article>
        <h4>Early Warning Indicators</h4>
        ${renderDetailList(warnings)}
      </article>
      <article>
        <h4>Recommended RM Actions</h4>
        ${renderDetailList(actions)}
      </article>
    </div>
    <p class="risk-disclaimer">Risk indicators are AI-generated and should be validated by the RM before escalation or credit action.</p>
  `;
}

function renderCustomer360() {
  const customer = selectedCustomer();

  setCustomer360Mode();

  document.getElementById('customerName').textContent = customer.name;
  document.getElementById('customerHealthBadge').textContent = `${customer.status} - ${customer.health}`;
  document.getElementById('customerHealthBadge').className = `badge ${badgeClass(customer)}`;

  const brnEl = document.getElementById('businessRegistration');
  if (brnEl) brnEl.textContent = customer.brn;
  document.getElementById('companyProfile').textContent = customer.companyProfile;
  document.getElementById('groupStructure').textContent = customer.groupStructure;
  document.getElementById('relationshipManager').textContent = customer.rm;
  document.getElementById('onboardingStatus').textContent = customer.onboarding;
  document.getElementById('internalRating').textContent = customer.internalRating;

  document.getElementById('aiSummaryList').innerHTML = customer.aiSummary
    .map(([title, text]) => `<div class="insight-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');
  document.getElementById('bankingProducts').innerHTML = customer.products
    .map(([title, text]) => `<div class="product-card"><strong>${title}</strong><span>${text}</span></div>`)
    .join('');
  document.getElementById('creditInfo').innerHTML = customer.creditInfo
    .map(([title, text]) => `<div class="metric-item"><strong>${title}</strong><p>${text}</p></div>`)
    .join('');

  const relationshipMetrics = [
    ...customer.ratios,
    ['Revenue', customer.revenue],
    ['Outstanding Facilities', customer.exposure],
    ['Deposit Holdings', customer.deposits],
    ['Relationship Value', customer.relationshipValue],
    ['Wallet Share', getWalletShareData().walletShare],
    ['Untapped Opportunity', getWalletShareData().untapped]
  ];

  document.getElementById('ratioCards').innerHTML = relationshipMetrics
    .map(([title, value]) => `<div><strong>${value}</strong><span>${title}</span></div>`)
    .join('');

  const selectorEl = document.getElementById('customerSelect');
  if (selectorEl) selectorEl.value = selectedCustomerId;

  renderCustomerMarketIntelligence();
  renderCustomerRiskMonitor();
  renderCustomerInteractions();
  renderCustomerDocuments();
  renderCustomerDocumentRequests();
  renderWalletShareOptimization();
}

function renderCustomerMarketIntelligence() {
  const customer = selectedCustomer();
  const target = document.getElementById('customerMarketIntelligence');
  if (!target) return;

  const primary = customer.opportunities?.[0] || 'Relationship deepening';
  const support = customer.aiSummary?.[1]?.[0] || customer.aiSignal;
  target.innerHTML = `
    <div class="customer-market-item next-action-item">
      <b>NBA</b>
      <div>
        <strong>${customer.nextAction}</strong>
        <p>Suggested because ${customer.aiSignal.toLowerCase()} and ${support.toLowerCase()} indicate a relevant ${primary} conversation.</p>
        <button type="button" data-ai-action="schedule">Schedule follow-up</button>
      </div>
    </div>
    <div class="customer-market-item next-action-item">
      <b>RM</b>
      <div>
        <strong>Validate with customer before execution</strong>
        <p>Confirm cash-flow movement, document readiness and latest business outlook before adding the opportunity to pipeline.</p>
        <button type="button" data-ai-action="pitch">Generate pitch</button>
      </div>
    </div>
  `;
}

function renderRelationshipCalendarMarkup() {
  const year = relationshipCalendarCursor.getFullYear();
  const month = relationshipCalendarCursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlanks = firstDay.getDay();
  const todayKey = dateKey(new Date());
  const monthLabel = firstDay.toLocaleDateString('en-MY', { month: 'long', year: 'numeric' });
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const cells = [];

  for (let index = 0; index < leadingBlanks; index += 1) {
    cells.push('<div class="calendar-date-cell is-empty"></div>');
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const cellDate = new Date(year, month, day);
    const key = dateKey(cellDate);
    const items = appointmentsForDate(key);
    cells.push(`
      <button type="button" class="calendar-date-cell ${key === todayKey ? 'is-today' : ''} ${key === selectedRelationshipDate ? 'is-selected' : ''} ${items.length ? 'has-events' : ''}" data-calendar-date="${key}">
        <b>${day}</b>
        ${items.slice(0, 1).map(item => `<span>${item.time} ${item.type}</span>`).join('')}
      </button>
    `);
  }

  const selectedItems = appointmentsForDate(selectedRelationshipDate);
  return `
    <div class="calendar-month-head">
      <div><span>Selected month</span><strong>${monthLabel}</strong></div>
      <div class="calendar-month-controls">
        <button type="button" data-calendar-month="prev" aria-label="Previous month">&lt;</button>
        <button type="button" data-calendar-month="today">Today</button>
        <button type="button" data-calendar-month="next" aria-label="Next month">&gt;</button>
      </div>
    </div>
    <div class="calendar-weekday-row">${weekdays.map(day => `<span>${day}</span>`).join('')}</div>
    <div class="calendar-date-grid">${cells.join('')}</div>
    <div class="calendar-day-agenda">
      <div class="agenda-head"><span>Planned for</span><strong>${formatCalendarDate(selectedRelationshipDate)}</strong></div>
      ${selectedItems.length ? selectedItems.map(item => {
        const customer = customerById(item.customerId);
        return `
          <button type="button" class="agenda-item priority-${item.priority.toLowerCase()}" data-call-pack-customer="${customer.id}">
            <time>${item.time}</time>
            <div><strong>${item.title}</strong><span>${item.type} / ${getCustomerShortName(customer)} / ${item.priority}</span></div>
          </button>
        `;
      }).join('') : '<p class="table-note">No appointments planned for this day.</p>'}
    </div>
  `;
}

function renderDashboardCalendar() {
  const target = document.getElementById('dashboardCalendar');
  if (target) target.innerHTML = renderRelationshipCalendarMarkup();
}

function renderCalendarView() {
  const target = document.getElementById('calendarGrid');
  if (target) target.innerHTML = renderRelationshipCalendarMarkup();
}

function renderCalendarCallPacks() {
  const target = document.getElementById('calendarCallPacks');
  if (!target) return;

  target.innerHTML = callPackItems.map((item, index) => {
    const customer = customerById(item.clientId);
    return `
      <article class="compact-review-card call-pack-card" data-call-pack-index="${index}" role="button" tabindex="0">
        <div class="compact-review-top">
          <span class="ops-severity ${item.status === 'Ready' ? 'info' : 'warning'}">${item.label}</span>
          <span class="ops-badge ${statusBadgeClass(item.status)}">${item.status}</span>
        </div>
        <div class="call-pack-title-row">
          <strong>${getCustomerShortName(customer)}</strong>
          <button type="button" class="call-pack-link-icon" data-call-pack-index="${index}" title="Open call pack">
            <svg class="icon"><use href="#i-documents"></use></svg>
          </button>
        </div>
        <p>${item.note}</p>
        <small>${item.detail}</small>
      </article>
    `;
  }).join('');
}

function renderCreditPipeline() {
  const statuses = ['Draft', 'Submitted', 'Credit Review', 'Additional Information Required', 'Approved', 'Rejected', 'Disbursed'];
  const target = document.getElementById('creditPipeline');
  if (!target) return;

  target.innerHTML = statuses.map((status, stageIndex) => {
    const cards = creditDeals
      .filter(deal => deal.status === status)
      .map(deal => {
        const customer = getCustomerByNameFragment(deal.customer);
        return `
          <div class="pipeline-card">
            <strong>${customer ? `<button class="customer-button" data-customer-id="${customer.id}">${deal.customer}</button>` : deal.customer}</strong>
            <span>Product: ${deal.product}</span>
            <span>Deal Value: ${deal.value}</span>
            <span>Expected Approval: ${deal.date}</span>
            <span>Probability: <b class="${probabilityClass(deal.probability)}-text">${deal.probability}%</b></span>
            <div class="probability ${probabilityClass(deal.probability)}"><div style="width:${deal.probability}%"></div></div>
          </div>
        `;
      })
      .join('') || '<p class="table-note">No deals</p>';

    return `<div class="pipeline-column"><h4><span>${String(stageIndex + 1).padStart(2, '0')}</span>${status}</h4>${cards}</div>`;
  }).join('');
}

function renderSalesPipeline() {
  const stages = ['Prospect', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
  renderWorkflowStrip('salesWorkflow', stages, 3);

  const pipelineNote = document.getElementById('salesPipelineCoverage');
  if (pipelineNote) {
    const newToBankCount = salesOpps.filter(opp => newToBankOpportunityNames.includes(opp.customer)).length;
    const existingCount = salesOpps.length - newToBankCount;
    pipelineNote.textContent = `Includes ${existingCount} existing relationship opportunities and ${newToBankCount} new-to-bank prospects.`;
  }

  const target = document.getElementById('salesPipeline');
  if (!target) return;

  target.innerHTML = stages.map((stage, stageIndex) => {
    const cards = salesOpps
      .filter(opp => opp.stage === stage)
      .map(opp => {
        const customer = getCustomerByNameFragment(opp.customer);
        const isNewToBank = newToBankOpportunityNames.includes(opp.customer) || !customer;
        return `
          <div class="opportunity-card">
            <strong>${customer ? `<button class="customer-button" data-customer-id="${customer.id}">${opp.customer}</button>` : opp.customer}</strong>
            <span class="opportunity-type-badge ${isNewToBank ? 'new' : 'existing'}">${isNewToBank ? 'New-to-bank prospect' : 'Existing customer'}</span>
            <span>Product: ${opp.product}</span>
            <span>Opportunity Value: ${opp.value}</span>
            <span>Expected Revenue: ${opp.revenue}</span>
            <span>Probability: <b class="${probabilityClass(opp.probability)}-text">${opp.probability}%</b></span>
            <div class="probability ${probabilityClass(opp.probability)}"><div style="width:${opp.probability}%"></div></div>
          </div>
        `;
      })
      .join('') || '<p class="table-note">No opportunities</p>';

    return `<div class="kanban-column"><h4><span>${String(stageIndex + 1).padStart(2, '0')}</span>${stage}</h4>${cards}</div>`;
  }).join('');
}

function renderPortfolioGrowthImpact() {
  const panel = document.querySelector('.copilot-growth-impact');
  if (panel) panel.classList.add('hidden');
}

function setCopilotGrowthImpactVisible() {
  const panel = document.querySelector('.copilot-growth-impact');
  if (panel) panel.classList.add('hidden');
}

function analysisModeForPrompt(prompt = '') {
  const lower = prompt.toLowerCase();
  if (lower.includes('wallet')) return 'Wallet Share Analysis';
  if (lower.includes('cross') || lower.includes('opportunit') || lower.includes('pitch')) return 'Cross-sell Recommendation';
  if (lower.includes('credit')) return 'Credit Review';
  if (lower.includes('meeting') || lower.includes('call')) return 'Meeting Preparation';
  if (lower.includes('risk') || lower.includes('alert')) return 'Risk Review';
  return 'Customer Summary';
}

function updateCopilotAnalysisMode(prompt) {
  const target = document.getElementById('copilotAnalysisMode');
  if (target) target.textContent = analysisModeForPrompt(prompt);
}

function addChatMessage(text, sender = 'bot') {
  const chatWindow = document.getElementById('chatWindow');
  if (!chatWindow) return;
  const div = document.createElement('div');
  const welcome = document.getElementById('copilotWelcome');
  const timestamp = new Date().toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit' });

  div.className = `message ${sender}`;
  if (welcome) welcome.classList.add('hidden');

  if (sender === 'user') {
    div.innerHTML = `${escapeHtml(text).replace(/\n/g, '<br>')}<time>${timestamp}</time>`;
  } else {
    div.innerHTML = `${text.replace(/\n/g, '<br>')}<time>${timestamp}</time>`;
  }

  chatWindow.appendChild(div);
  if (sender !== 'user') {
    const actions = document.createElement('div');
    actions.className = 'ai-message-actions';
    actions.innerHTML = `
      <button type="button" data-ai-action="pitch">Generate Pitch</button>
      <button type="button" data-ai-action="pipeline">Add to Pipeline</button>
      <button type="button" data-ai-action="schedule">Schedule Follow-up</button>
      <button type="button" data-ai-action="export">Export Summary</button>
      <button type="button" data-ai-action="save">Save to Customer 360</button>
      <button type="button" data-ai-prompt="Find cross-sell opportunities">Cross-sell</button>
      <button type="button" data-ai-prompt="Analyse wallet share">Wallet share</button>
      <button type="button" data-ai-prompt="Draft credit review">Credit review</button>
      <button type="button" data-ai-prompt="Prepare customer meeting pitch">Meeting pitch</button>
    `;
    chatWindow.appendChild(actions);
  }
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function copilotResponse(prompt) {
  const lower = prompt.toLowerCase();
  const customer = selectedCustomer();
  const relatedSignals = marketSignals.filter(signal => (signal.clientIds || []).includes(customer.id));

  if (lower.includes('cross') || lower.includes('opportunit') || lower.includes('pitch')) {
    const topImpact = getPortfolioGrowthRecommendations()[0];
    return `
      <strong>Cross-sell recommendation</strong>
      <p>For ${customer.name}, CIMBrain sees the strongest fit in ${customer.opportunities.join(', ')}.</p>
      <p><strong>Recommended product:</strong> ${topImpact.product}</p>
      <p><strong>Estimated incremental value:</strong> ${topImpact.incremental}; <strong>Potential uplift:</strong> ${topImpact.uplift}; <strong>AI confidence:</strong> ${topImpact.confidence}.</p>
      <p><strong>Justification:</strong> ${topImpact.reason} CIMBrain also sees a product gap against the customer profile, current facility usage and transaction pattern. The uplift is AI-estimated and should be validated through customer engagement.</p>
      <p><strong>Evidence to validate:</strong></p>
      ${renderDetailList([
        `Current signal: ${customer.aiSignal}`,
        `Relationship value: ${customer.relationshipValue}; exposure ${customer.exposure}; deposits ${customer.deposits}`,
        `Relevant products already held: ${customer.products.slice(0, 3).map(([title]) => title).join(', ')}`,
        `Opportunity fit: ${customer.opportunities.join(', ')}`
      ])}
      <p><strong>Recommended RM approach:</strong> start with the business issue, confirm timing and cash-flow need, then position the proposed product as a way to reduce friction, improve resilience or capture wallet share.</p>
      <p><strong>Suggested RM action:</strong> ${customer.nextAction}</p>
    `;
  }

  if (lower.includes('risk') || lower.includes('alert')) {
    return `
      <strong>Risk explanation</strong>
      <p>The current signal for ${getCustomerShortName(customer)} is ${customer.aiSignal}.</p>
      ${renderDetailList([
        'Facility utilisation and repayment pattern',
        'Deposit movement and retained operating balances',
        'Document readiness for annual review',
        relatedSignals.length ? `Market signal: ${relatedSignals.map(signal => signal.title).join(', ')}` : 'No sector-specific signal tagged today'
      ])}
      <p><strong>Recommended action:</strong> validate the signal with a customer call or site visit before escalating to Credit Risk.</p>
    `;
  }

  if (lower.includes('credit')) {
    return `
      <strong>Credit memo starter</strong>
      <p><strong>Customer:</strong> ${customer.name}</p>
      <p><strong>Exposure:</strong> ${customer.exposure}; <strong>Deposits:</strong> ${customer.deposits}; <strong>Internal rating:</strong> ${customer.internalRating}.</p>
      <p>${customer.aiSummary.map(([title, text]) => `<b>${title}</b>: ${text}`).join('<br>')}</p>
    `;
  }

  return `
    <strong>${customer.name} summary</strong>
    <p><strong>Business profile:</strong> ${customer.companyProfile}</p>
    <p><strong>Relationship snapshot:</strong> Health score ${customer.health} (${customer.status}); exposure ${customer.exposure}; deposits ${customer.deposits}; relationship value ${customer.relationshipValue}.</p>
    <p><strong>Evidence observed:</strong></p>
    ${renderDetailList([
      customer.aiSignal,
      `Internal rating: ${customer.internalRating}; onboarding status: ${customer.onboardingStatus}.`,
      `Products already held: ${customer.products.slice(0, 4).map(([title]) => title).join(', ')}.`,
      relatedSignals.length ? `Market signal: ${relatedSignals.map(signal => `${signal.title} - ${signal.impact}`).join('; ')}` : 'No immediate customer-specific market signal tagged today.'
    ])}
    <p><strong>Why it matters:</strong> The customer profile suggests the RM should validate operating cash-flow movement before positioning a product. The strongest conversation angle is to connect the recommendation to liquidity, payment timing and wallet share rather than a generic product push.</p>
    <p><strong>Recommended RM action:</strong> ${customer.nextAction}</p>
    <p><strong>Follow-up evidence to request:</strong> latest management accounts, transaction ageing, upcoming supplier or buyer payment schedule, and any renewal documents required for credit review.</p>
  `;
}

function sendCopilotPrompt(prompt) {
  if (!prompt) return;
  updateCopilotAnalysisMode(prompt);
  addChatMessage(prompt, 'user');
  const loading = addCopilotLoading();
  setTimeout(() => {
    loading.remove();
    addChatMessage(copilotResponse(prompt));
  }, 600);
}

function loadCopilotHistory(prompt, label) {
  const chatWindow = document.getElementById('chatWindow');
  const welcome = document.getElementById('copilotWelcome');
  if (!chatWindow) return;
  chatWindow.querySelectorAll('.message, .copilot-loading, .ai-message-actions').forEach(message => message.remove());
  if (welcome) welcome.classList.add('hidden');
  updateCopilotAnalysisMode(prompt);
  addChatMessage(label || prompt, 'user');
  addChatMessage(copilotResponse(prompt), 'bot');
}

function openCallPackModal(index) {
  const item = callPackItems[index];
  if (!item) return;
  const customer = customerById(item.clientId);
  const copyText = `Call Pack: ${customer.name}

Business overview:
${customer.companyProfile}

Call objective:
${item.note}

Talking points:
- Confirm latest operating cash-flow movement.
- Validate the current AI signal: ${customer.aiSignal}.
- Discuss next best action: ${customer.nextAction}.
- Agree owner and timeline for documents or product proposal.`;

  openDetailModal({
    kicker: 'Call Pack',
    title: `${getCustomerShortName(customer)} call pack`,
    body: `
      <div class="modal-icon-actions">
        <button type="button" class="icon-btn" data-copy-text="${escapeHtml(copyText)}" title="Copy call pack"><svg class="icon"><use href="#i-documents"></use></svg></button>
        <button type="button" class="icon-btn" data-save-callpack-pdf title="Save as PDF"><svg class="icon"><use href="#i-download"></use></svg></button>
      </div>
      <section class="detail-section">
        <strong>Business overview</strong>
        <p>${customer.companyProfile}</p>
      </section>
      <section class="detail-section">
        <strong>Call focus</strong>
        <p>${item.note}</p>
      </section>
      <section class="detail-section">
        <strong>Talking points</strong>
        ${renderDetailList(['Confirm latest operating cash-flow movement.', `Validate the current AI signal: ${customer.aiSignal}.`, `Discuss next best action: ${customer.nextAction}.`, 'Agree owner and timeline for documents or product proposal.'])}
      </section>
    `
  });
}

function openDocumentRequestForm() {
  const customer = selectedCustomer();
  openDetailModal({
    kicker: 'Document Request',
    title: `Add request for ${getCustomerShortName(customer)}`,
    body: `
      <form class="modal-form" data-modal-form="documentRequest">
        <label>Document<input name="document" required value="Latest management accounts"></label>
        <label>Status<select name="status"><option>Pending</option><option>Required</option><option>Draft received</option></select></label>
        <label>Owner<input name="owner" required value="Client CFO"></label>
        <label>Purpose<textarea name="purpose" required>Customer 360 review and facility validation.</textarea></label>
        <div class="modal-action-row">
          <button type="button" class="btn secondary" data-modal-cancel>Cancel</button>
          <button type="submit" class="btn primary">Add request</button>
        </div>
      </form>
    `
  });
}

function openReportExportModal(reportTitle) {
  const data = getReportPeriodData(activeReportPeriod);
  const report = data.rmReports.find(item => item.title === reportTitle) || data.rmReports[0];
  openDetailModal({
    kicker: 'RM Performance Export',
    title: report.title,
    body: `
      <section class="detail-section">
        <p>${report.text}</p>
      </section>
      <div class="ops-table-wrap">
        <table class="ops-table">
          <thead><tr><th>Metric</th><th>Value</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>Meetings completed</td><td>24</td><td>On track</td></tr>
            <tr><td>Follow-ups due</td><td>12</td><td>Review today</td></tr>
            <tr><td>Pipeline conversion</td><td>${data.pipelineConversion}</td><td>${data.pipelineConversionNote}</td></tr>
            <tr><td>Revenue booked</td><td>${activeReportPeriod === 'today' ? 'RM0.42m' : activeReportPeriod === 'mtd' ? 'RM4.8m' : 'RM18.7m'}</td><td>Finance ready</td></tr>
          </tbody>
        </table>
      </div>
      <div class="modal-action-row">
        <button type="button" class="btn secondary" data-modal-cancel>Cancel</button>
        <button type="button" class="btn primary" data-download-report>Download</button>
      </div>
    `
  });
}

function renderCustomerSearchSuggestions() {
  const input = document.getElementById('customerSearch');
  const target = document.getElementById('customerSearchSuggestions');
  if (!input || !target) return;
  const query = input.value.trim().toLowerCase();
  if (!query) {
    target.classList.add('hidden');
    target.innerHTML = '';
    return;
  }
  const matches = customers.filter(customer =>
    customer.name.toLowerCase().includes(query) ||
    getCustomerShortName(customer).toLowerCase().includes(query) ||
    customer.industry.toLowerCase().includes(query)
  ).slice(0, 6);

  target.innerHTML = matches.map(customer => `
    <button type="button" data-customer-suggestion="${customer.id}">
      <strong>${customer.name}</strong>
      <span>${customer.industry} / ${customer.segment}</span>
    </button>
  `).join('') || '<span>No matching customer</span>';
  target.classList.remove('hidden');
}

function openNextBestDealDetail(index) {
  const item = getSortedNextBestDealItems()[index];
  if (!item) return;
  const customer = customerById(item.customerId);
  const evidence = [
    `Current relationship value: ${customer.relationshipValue}; exposure ${customer.exposure}; deposits ${customer.deposits}.`,
    `AI signal: ${customer.aiSignal}.`,
    `Recommended deal: ${item.deal}, with AI-estimated value of ${item.value}.`,
    `Portfolio uplift estimate: ${item.uplift}; AI confidence: ${item.confidence}.`,
    `Opportunity type: ${item.type}; priority: ${item.priority}.`
  ];

  openDetailModal({
    kicker: 'Next Best Client & Deal',
    title: `${item.deal} for ${getCustomerShortName(customer)}`,
    body: `
      <section class="detail-section">
        <strong>Recommendation</strong>
        <p>CIMBrain recommends positioning <b>${item.deal}</b> with ${customer.name} as the next relationship growth conversation.</p>
      </section>
      <section class="detail-section">
        <strong>Why this client</strong>
        <p>${item.why}</p>
      </section>
      <section class="detail-section">
        <strong>Evidence and justification</strong>
        ${renderDetailList(evidence)}
      </section>
      <section class="detail-section">
        <strong>Recommended RM move</strong>
        <p>${item.step}</p>
      </section>
      <section class="detail-section">
        <strong>Suggested pitch angle</strong>
        <p>Open with the operating issue, validate the customer’s cash-flow timing, then position the solution as a practical way to protect margin, improve working-capital discipline and capture more wallet share. The impact is AI-estimated and should be confirmed through customer engagement.</p>
      </section>
    `
  });
}

function handleNextBestAction(action, index) {
  const item = getSortedNextBestDealItems()[index];
  if (!item) return;
  const customer = customerById(item.customerId);
  if (action === 'details') {
    openNextBestDealDetail(index);
    return;
  }
  if (action === 'customer') {
    openCustomer(customer.id);
    return;
  }
  if (action === 'meeting') {
    selectedCustomerId = customer.id;
    openAppointmentForm({ modalTitle: 'Schedule client meeting', title: `${getCustomerShortName(customer)} ${item.deal} discussion`, type: 'Meeting' });
    return;
  }
  if (action === 'pipeline') {
    salesOpps.unshift({ stage: 'Prospect', customer: getCustomerShortName(customer), product: item.deal, value: item.value, revenue: 'RM120k', probability: Number(item.confidence.replace('%', '')) });
    renderSalesPipeline();
    showToast(`${item.deal} added to Sales Opportunities.`);
    return;
  }
  const pitchCopy = `${item.deal} pitch for ${customer.name}

Why now:
${item.why}

Relationship context:
- Current opportunity value: ${item.value}
- Estimated portfolio uplift: ${item.uplift}
- AI confidence: ${item.confidence}
- Current signal: ${customer.aiSignal}

Recommended next step:
${item.step}`;

  openDetailModal({
    kicker: 'Generated Pitch',
    title: `${item.deal} pitch for ${getCustomerShortName(customer)}`,
    body: `
      <div class="modal-icon-actions">
        <button type="button" class="modal-copy-btn icon-only-modal-btn" data-copy-text="${escapeHtml(pitchCopy)}" title="Copy pitch">
          <svg class="icon"><use href="#i-documents"></use></svg>
        </button>
      </div>
      <section class="detail-section">
        <strong>Why this client</strong>
        <p>${item.why}</p>
      </section>
      <section class="detail-section">
        <strong>Relationship context</strong>
        <div class="export-metric-grid exception-detail-grid">
          <div><span>Customer</span><strong>${getCustomerShortName(customer)}</strong></div>
          <div><span>Recommended deal</span><strong>${item.deal}</strong></div>
          <div><span>Estimated value</span><strong>${item.value}</strong></div>
          <div><span>AI confidence</span><strong>${item.confidence}</strong></div>
        </div>
      </section>
      <section class="detail-section">
        <strong>Suggested conversation flow</strong>
        ${renderDetailList([
          `Open with the customer signal: ${customer.aiSignal}.`,
          'Confirm whether the current cash-flow pattern is expected to continue over the next 60 to 90 days.',
          `Position ${item.deal} as a practical response to the business issue, not as a standalone product push.`,
          'Agree a follow-up owner, timeline and required documents before adding the deal to pipeline.'
        ])}
      </section>
      <section class="detail-section">
        <strong>Recommended next step</strong>
        <p>${item.step}</p>
      </section>
    `
  });
}

function handleAiAction(action) {
  const customer = selectedCustomer();
  if (action === 'pipeline') {
    salesOpps.unshift({ stage: 'Prospect', customer: getCustomerShortName(customer), product: customer.opportunities?.[0] || 'Relationship Opportunity', value: 'RM3.5m', revenue: 'RM120k', probability: 86 });
    renderSalesPipeline();
    showToast('Opportunity added to pipeline.');
    return;
  }
  if (action === 'schedule') {
    openAppointmentForm({ modalTitle: 'Schedule follow-up', title: `${getCustomerShortName(customer)} follow-up`, type: 'Call' });
    return;
  }
  if (action === 'save') {
    showToast('Summary saved to Customer 360.');
    return;
  }
  if (action === 'export') {
    openDetailModal({
      kicker: 'Copilot Export',
      title: 'AI summary export',
      body: `<section class="detail-section"><p>${customer.name} summary prepared for RM review.</p></section><div class="modal-action-row"><button type="button" class="btn primary" data-save-c360-pdf>Save as PDF</button></div>`
    });
    return;
  }
  openDetailModal({
    kicker: 'Generated Pitch',
    title: `${getCustomerShortName(customer)} customer pitch`,
    body: `<section class="detail-section"><p>Lead with the customer cash-flow issue, validate ${customer.aiSignal.toLowerCase()}, then position ${customer.opportunities?.[0] || 'the recommended solution'} as the lowest-friction next step.</p></section>`
  });
}

function setupLatestUiFixes() {
  document.querySelectorAll('[data-dashboard-period]').forEach(button => {
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      activeDashboardPeriod = button.dataset.dashboardPeriod || 'today';
      activeReportPeriod = activeDashboardPeriod;
      document.querySelectorAll('[data-dashboard-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton === button);
      });
      document.querySelectorAll('[data-report-period]').forEach(periodButton => {
        periodButton.classList.toggle('active', periodButton.dataset.reportPeriod === activeReportPeriod);
      });
      renderDashboard();
      renderReports();
    }, true);
  });

  ['relationshipValueFilter', 'riskRatingFilter', 'segmentFilter', 'industryFilter'].forEach(id => {
    const filter = document.getElementById(id);
    if (filter) filter.addEventListener('change', renderPortfolio);
  });

  const customerSearch = document.getElementById('customerSearch');
  if (customerSearch) {
    customerSearch.addEventListener('input', () => {
      renderPortfolio();
      renderCustomerSearchSuggestions();
    });
  }

  document.querySelectorAll('.chat-history-groups button[data-chat-prompt]').forEach(button => {
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      loadCopilotHistory(button.dataset.chatPrompt || button.textContent.trim(), button.textContent.trim());
    }, true);
  });

  document.body.addEventListener('click', event => {
    const dateButton = event.target.closest('[data-calendar-date]');
    if (dateButton) {
      event.preventDefault();
      event.stopImmediatePropagation();
      selectedRelationshipDate = dateButton.dataset.calendarDate;
      renderDashboardCalendar();
      renderCalendarView();
      return;
    }

    const monthButton = event.target.closest('[data-calendar-month]');
    if (monthButton) {
      event.preventDefault();
      event.stopImmediatePropagation();
      const action = monthButton.dataset.calendarMonth;
      if (action === 'prev') {
        relationshipCalendarCursor = new Date(relationshipCalendarCursor.getFullYear(), relationshipCalendarCursor.getMonth() - 1, 1);
      } else if (action === 'next') {
        relationshipCalendarCursor = new Date(relationshipCalendarCursor.getFullYear(), relationshipCalendarCursor.getMonth() + 1, 1);
      } else {
        const now = new Date();
        relationshipCalendarCursor = new Date(now.getFullYear(), now.getMonth(), 1);
        selectedRelationshipDate = dateKey(now);
      }
      renderDashboardCalendar();
      renderCalendarView();
      return;
    }

    const suggestion = event.target.closest('[data-customer-suggestion]');
    if (suggestion) {
      openCustomer(suggestion.dataset.customerSuggestion);
      document.getElementById('customerSearchSuggestions')?.classList.add('hidden');
      return;
    }

    const nextBest = event.target.closest('[data-next-best-action]');
    if (nextBest) {
      event.preventDefault();
      event.stopImmediatePropagation();
      handleNextBestAction(nextBest.dataset.nextBestAction, Number(nextBest.dataset.nextBestIndex));
      return;
    }

    const nextBestCard = event.target.closest('.next-best-deal-card[data-next-best-index]');
    if (nextBestCard) {
      event.preventDefault();
      event.stopImmediatePropagation();
      openNextBestDealDetail(Number(nextBestCard.dataset.nextBestIndex));
      return;
    }

    const callPack = event.target.closest('[data-call-pack-index]');
    if (callPack) {
      openCallPackModal(Number(callPack.dataset.callPackIndex));
      return;
    }

    const exportReportTarget = event.target.closest('[data-export-report]');
    if (exportReportTarget) {
      event.preventDefault();
      event.stopImmediatePropagation();
      openReportExportModal(exportReportTarget.dataset.exportReport);
      return;
    }

    if (event.target.closest('[data-download-report]')) {
      showToast('Report downloaded for demo review.');
      closeDetailModal();
      return;
    }

    if (event.target.closest('[data-save-callpack-pdf]')) {
      showToast('Opening print preview. Choose Save as PDF.');
      window.print();
      return;
    }

    const aiAction = event.target.closest('[data-ai-action]');
    if (aiAction) {
      event.preventDefault();
      handleAiAction(aiAction.dataset.aiAction);
      return;
    }

    const aiPrompt = event.target.closest('[data-ai-prompt]');
    if (aiPrompt) {
      event.preventDefault();
      event.stopImmediatePropagation();
      sendCopilotPrompt(aiPrompt.dataset.aiPrompt || aiPrompt.textContent.trim());
      return;
    }

    const promptButton = event.target.closest('.copilot-context-panel [data-prompt]');
    if (promptButton) {
      event.preventDefault();
      sendCopilotPrompt(promptButton.dataset.prompt || promptButton.textContent.trim());
    }
  }, true);

  const addDocumentRequestBtn = document.getElementById('addDocumentRequestBtn');
  if (addDocumentRequestBtn) addDocumentRequestBtn.addEventListener('click', openDocumentRequestForm);

  const detailModal = document.getElementById('detailModal');
  if (detailModal) {
    detailModal.addEventListener('submit', event => {
      const form = event.target.closest('[data-modal-form="documentRequest"]');
      if (!form) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      const data = new FormData(form);
      customerDocumentRequestItems.unshift({
        clientId: selectedCustomerId,
        document: data.get('document'),
        status: data.get('status'),
        owner: data.get('owner'),
        purpose: data.get('purpose')
      });
      renderCustomerDocumentRequests();
      closeDetailModal();
      showToast('Document request added.');
    }, true);
  }
}

pageMeta.dashboardView = ['Operations Dashboard', 'Operations command center for credit, risk, fraud, approvals and controlled recommendations.'];
pageMeta.customer360View = ['Customer 360', 'Customer profile, conduct, facilities, documents and risk observations.'];
pageMeta.copilotView = ['Operations Copilot', 'Controlled assistant for customer summaries, credit preparation and RM workflow support.'];
pageMeta.aiInsightsView = ['AI Insights', 'Prioritized relationship actions, growth leads and early warning signals.'];
pageMeta.documentsView = ['Documents', 'Customer statements, credit papers, KYC records and facility documentation.'];
pageMeta.engagementView = ['Relationship Timeline', 'Customer interaction history and RM follow-up records.'];
pageMeta.reportsView = ['Portfolio Analytics', 'Portfolio mix, revenue movement, loan exposure and RM activity trends.'];
pageMeta.alertsView = ['Alerts', 'Concise risk, facility and conduct alerts requiring RM attention.'];
pageMeta.calendarView = ['Relationship Calendar', 'Appointments, call packs and RM follow-up actions.'];
pageMeta.facilityRenewalsView = ['Facility Renewals', 'Upcoming renewals, expiries and repricing actions by customer.'];
pageMeta.covenantTrackerView = ['Covenant Tracker', 'Covenant status, financial submission gaps and escalation actions.'];
pageMeta.documentRequestsView = ['Document Requests', 'Missing statements, board papers and customer documents requiring follow-up.'];

document.querySelectorAll('.kpi-card .kpi-icon').forEach(icon => {
  icon.setAttribute('aria-hidden', 'true');
});

renderAll();
initEvents();
setupEnhancedInteractions();
setupLatestUiFixes();
updateHeaderTime();
