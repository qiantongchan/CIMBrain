# CIMBrain Commercial RM Platform Prototype

Open `index.html` in a browser. This is a front-end only demo. Any username/password works.

Updated login page includes CIMBrain branding, hero section, key features, banking illustration, SSO button, system status, version, security notice, and rotating banking insight.
